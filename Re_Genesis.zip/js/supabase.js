// ============================================================
// REGENESIS — Supabase Client
// File: js/supabase.js
// ============================================================

import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

// ------------------------------------------------------------
// SUPABASE CONFIG
// ------------------------------------------------------------

const SUPABASE_URL = "https://gkxcwgafkxugavlwnlfe.supabase.co";

const SUPABASE_PUBLISHABLE_KEY =
  "sb_publishable_frNxXgEde1Z6jy5EPFfiIw_Xm-L5aHw";

// ------------------------------------------------------------
// APP CONFIG
// ------------------------------------------------------------

const getAppURL = () => {
  return window.location.origin;
};

const getAuthCallbackURL = () => {
  return `${getAppURL()}/auth/callback.html`;
};

const getVerifyURL = () => {
  return `${getAppURL()}/auth/verify.html`;
};

const getResetURL = () => {
  return `${getAppURL()}/auth/reset.html`;
};

// ------------------------------------------------------------
// CREATE SUPABASE CLIENT
// ------------------------------------------------------------

export const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      flowType: "pkce"
    },

    global: {
      headers: {
        "x-client-info": "regenesis-web"
      }
    }
  }
);

// ------------------------------------------------------------
// AUTH — SESSION
// ------------------------------------------------------------

export async function getSession() {
  const { data, error } = await supabase.auth.getSession();

  if (error) {
    console.error("Supabase getSession error:", error);
    return null;
  }

  return data?.session || null;
}

// ------------------------------------------------------------
// AUTH — USER
// ------------------------------------------------------------

export async function getUser() {
  const { data, error } = await supabase.auth.getUser();

  if (error) {
    // No active session is normal for logged-out visitors.
    if (error.message?.toLowerCase().includes("auth session missing")) {
      return null;
    }

    console.error("Supabase getUser error:", error);
    return null;
  }

  return data?.user || null;
}

// ------------------------------------------------------------
// AUTH — STATE CHANGES
// ------------------------------------------------------------

export function onAuthChange(callback) {
  return supabase.auth.onAuthStateChange((event, session) => {
    if (typeof callback === "function") {
      callback(event, session);
    }
  });
}

// ------------------------------------------------------------
// AUTH — SIGN OUT
// ------------------------------------------------------------

export async function signOut() {
  const { error } = await supabase.auth.signOut();

  if (error) {
    console.error("Supabase signOut error:", error);
    throw error;
  }

  return true;
}

// ------------------------------------------------------------
// EMAIL LOGIN
// ------------------------------------------------------------

export async function signInWithEmail(email, password) {
  if (!email || !password) {
    throw new Error("Email and password are required.");
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email: email.trim(),
    password
  });

  if (error) {
    throw error;
  }

  return data;
}

// ------------------------------------------------------------
// EMAIL REGISTER
// ------------------------------------------------------------

export async function registerWithEmail(email, password) {
  if (!email || !password) {
    throw new Error("Email and password are required.");
  }

  const { data, error } = await supabase.auth.signUp({
    email: email.trim(),
    password,

    options: {
      emailRedirectTo: getVerifyURL()
    }
  });

  if (error) {
    throw error;
  }

  return data;
}

// ------------------------------------------------------------
// GOOGLE LOGIN
// ------------------------------------------------------------

export async function signInWithGoogle() {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",

    options: {
      redirectTo: getAuthCallbackURL(),

      queryParams: {
        access_type: "offline",
        prompt: "select_account"
      }
    }
  });

  if (error) {
    throw error;
  }

  return data;
}

// ------------------------------------------------------------
// FACEBOOK LOGIN
// ------------------------------------------------------------

export async function signInWithFacebook() {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "facebook",

    options: {
      redirectTo: getAuthCallbackURL()
    }
  });

  if (error) {
    throw error;
  }

  return data;
}

// ------------------------------------------------------------
// PASSWORD RESET EMAIL
// ------------------------------------------------------------

export async function sendPasswordReset(email) {
  if (!email) {
    throw new Error("Email is required.");
  }

  const { data, error } = await supabase.auth.resetPasswordForEmail(
    email.trim(),
    {
      redirectTo: getResetURL()
    }
  );

  if (error) {
    throw error;
  }

  return data;
}

// ------------------------------------------------------------
// UPDATE PASSWORD
// ------------------------------------------------------------

export async function updatePassword(newPassword) {
  if (!newPassword) {
    throw new Error("New password is required.");
  }

  const { data, error } = await supabase.auth.updateUser({
    password: newPassword
  });

  if (error) {
    throw error;
  }

  return data;
}

// ------------------------------------------------------------
// CURRENT USER ID
// ------------------------------------------------------------

export async function getUserId() {
  const user = await getUser();
  return user?.id || null;
}

// ------------------------------------------------------------
// EXPORT CONFIG
// ------------------------------------------------------------

export {
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY
};