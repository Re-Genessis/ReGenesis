// ============================================================
// REGENESIS — Manga Module
// File: js/manga/manga.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 24;
const MAX_LIMIT = 100;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let currentManga = null;
let mangaList = [];

let loading = false;
let realtimeChannel = null;

const listeners = new Set();

const EVENTS = {
    LOADING: "loading",
    LOADED: "loaded",
    CREATED: "created",
    UPDATED: "updated",
    DELETED: "deleted",
    LIKED: "liked",
    UNLIKED: "unliked",
    CHANGED: "changed",
    ERROR: "error"
};

// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onMangaChange(callback) {
    if (typeof callback !== "function") {
        throw new TypeError("callback must be a function");
    }

    listeners.add(callback);

    return () => {
        listeners.delete(callback);
    };
}

function emit(event, data = null) {
    listeners.forEach(callback => {
        try {
            callback({
                event,
                data
            });
        } catch (error) {
            console.error("Manga listener error:", error);
        }
    });
}

// ------------------------------------------------------------
// Current user
// ------------------------------------------------------------

export async function getCurrentUser() {
    const {
        data,
        error
    } = await supabase.auth.getUser();

    if (error) {
        currentUser = null;
        return null;
    }

    currentUser = data?.user || null;

    return currentUser;
}

// ------------------------------------------------------------
// Load manga
// ------------------------------------------------------------

export async function loadManga({
    search = "",
    genre = "",
    status = "",
    limit = DEFAULT_LIMIT,
    offset = 0
} = {}) {

    loading = true;
    emit(EVENTS.LOADING, true);

    try {
        limit = Math.min(
            Math.max(Number(limit) || DEFAULT_LIMIT, 1),
            MAX_LIMIT
        );

        offset = Math.max(Number(offset) || 0, 0);

        let query = supabase
            .from("manga")
            .select(`
                id,
                title,
                slug,
                description,
                cover_url,
                author,
                artist,
                status,
                genres,
                created_at,
                updated_at
            `, {
                count: "exact"
            })
            .order("created_at", {
                ascending: false
            })
            .range(
                offset,
                offset + limit - 1
            );

        if (search.trim()) {
            query = query.ilike(
                "title",
                `%${search.trim()}%`
            );
        }

        if (genre.trim()) {
            query = query.contains(
                "genres",
                [genre.trim()]
            );
        }

        if (status.trim()) {
            query = query.eq(
                "status",
                status.trim()
            );
        }

        const {
            data,
            error,
            count
        } = await query;

        if (error) {
            throw error;
        }

        mangaList = data || [];

        emit(EVENTS.LOADED, {
            items: mangaList,
            count: count || 0,
            offset,
            limit
        });

        return {
            items: mangaList,
            count: count || 0,
            offset,
            limit
        };

    } catch (error) {

        console.error("Failed to load manga:", error);

        emit(EVENTS.ERROR, error);

        throw error;

    } finally {

        loading = false;
        emit(EVENTS.LOADING, false);
    }
}

// ------------------------------------------------------------
// Get manga by ID
// ------------------------------------------------------------

export async function getMangaById(id) {

    if (!id) {
        throw new Error("Manga ID is required.");
    }

    const {
        data,
        error
    } = await supabase
        .from("manga")
        .select(`
            id,
            title,
            slug,
            description,
            cover_url,
            author,
            artist,
            status,
            genres,
            created_at,
            updated_at
        `)
        .eq("id", id)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    currentManga = data || null;

    return currentManga;
}

// ------------------------------------------------------------
// Get manga by slug
// ------------------------------------------------------------

export async function getMangaBySlug(slug) {

    if (!slug) {
        throw new Error("Manga slug is required.");
    }

    const {
        data,
        error
    } = await supabase
        .from("manga")
        .select(`
            id,
            title,
            slug,
            description,
            cover_url,
            author,
            artist,
            status,
            genres,
            created_at,
            updated_at
        `)
        .eq("slug", slug)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    currentManga = data || null;

    return currentManga;
}

// ------------------------------------------------------------
// Get manga by ID or slug
// ------------------------------------------------------------

export async function getManga(identifier) {

    if (!identifier) {
        throw new Error("Manga identifier is required.");
    }

    // Try ID first.
    const byId = await getMangaById(identifier);

    if (byId) {
        return byId;
    }

    // Then try slug.
    return await getMangaBySlug(identifier);
}

// ------------------------------------------------------------
// Search manga
// ------------------------------------------------------------

export async function searchManga(search, options = {}) {

    return await loadManga({
        ...options,
        search: search || ""
    });
}

// ------------------------------------------------------------
// Get manga by genre
// ------------------------------------------------------------

export async function getMangaByGenre(
    genre,
    options = {}
) {

    return await loadManga({
        ...options,
        genre: genre || ""
    });
}

// ------------------------------------------------------------
// Get manga by status
// ------------------------------------------------------------

export async function getMangaByStatus(
    status,
    options = {}
) {

    return await loadManga({
        ...options,
        status: status || ""
    });
}

// ------------------------------------------------------------
// Get all available genres
// ------------------------------------------------------------

export async function getGenres() {

    const {
        data,
        error
    } = await supabase
        .from("manga")
        .select("genres");

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    const genres = new Set();

    (data || []).forEach(item => {

        if (!Array.isArray(item.genres)) {
            return;
        }

        item.genres.forEach(genre => {

            if (
                typeof genre === "string" &&
                genre.trim()
            ) {
                genres.add(genre.trim());
            }

        });
    });

    return [...genres].sort(
        (a, b) => a.localeCompare(b)
    );
}

// ------------------------------------------------------------
// Get manga count
// ------------------------------------------------------------

export async function getMangaCount({
    search = "",
    genre = "",
    status = ""
} = {}) {

    let query = supabase
        .from("manga")
        .select("id", {
            count: "exact",
            head: true
        });

    if (search.trim()) {
        query = query.ilike(
            "title",
            `%${search.trim()}%`
        );
    }

    if (genre.trim()) {
        query = query.contains(
            "genres",
            [genre.trim()]
        );
    }

    if (status.trim()) {
        query = query.eq(
            "status",
            status.trim()
        );
    }

    const {
        count,
        error
    } = await query;

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    return count || 0;
}

// ------------------------------------------------------------
// Get manga discussions
// ------------------------------------------------------------

export async function getMangaDiscussions(
    mangaId,
    {
        limit = 50,
        offset = 0
    } = {}
) {

    if (!mangaId) {
        throw new Error("Manga ID is required.");
    }

    const safeLimit = Math.min(
        Math.max(Number(limit) || 50, 1),
        100
    );

    const safeOffset = Math.max(
        Number(offset) || 0,
        0
    );

    const {
        data,
        error
    } = await supabase
        .from("manga_discussions")
        .select(`
            id,
            manga_id,
            user_id,
            title,
            content,
            created_at,
            updated_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .eq("manga_id", mangaId)
        .order("created_at", {
            ascending: false
        })
        .range(
            safeOffset,
            safeOffset + safeLimit - 1
        );

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    return data || [];
}

// ------------------------------------------------------------
// Get single discussion
// ------------------------------------------------------------

export async function getDiscussion(
    discussionId
) {

    if (!discussionId) {
        throw new Error("Discussion ID is required.");
    }

    const {
        data,
        error
    } = await supabase
        .from("manga_discussions")
        .select(`
            id,
            manga_id,
            user_id,
            title,
            content,
            created_at,
            updated_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .eq("id", discussionId)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    return data || null;
}

// ------------------------------------------------------------
// Create manga discussion
// ------------------------------------------------------------

export async function createDiscussion({
    mangaId,
    title,
    content
}) {

    const user = currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in to create a discussion."
        );
    }

    if (!mangaId) {
        throw new Error("Manga ID is required.");
    }

    if (!title || !title.trim()) {
        throw new Error("Discussion title is required.");
    }

    if (!content || !content.trim()) {
        throw new Error("Discussion content is required.");
    }

    const {
        data,
        error
    } = await supabase
        .from("manga_discussions")
        .insert({
            manga_id: mangaId,
            user_id: user.id,
            title: title.trim(),
            content: content.trim()
        })
        .select(`
            id,
            manga_id,
            user_id,
            title,
            content,
            created_at,
            updated_at
        `)
        .single();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    emit(EVENTS.CREATED, data);
    emit(EVENTS.CHANGED, data);

    return data;
}

// ------------------------------------------------------------
// Update discussion
// ------------------------------------------------------------

export async function updateDiscussion(
    discussionId,
    {
        title,
        content
    }
) {

    const user = currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in."
        );
    }

    if (!discussionId) {
        throw new Error(
            "Discussion ID is required."
        );
    }

    const updates = {};

    if (typeof title === "string") {
        updates.title = title.trim();
    }

    if (typeof content === "string") {
        updates.content = content.trim();
    }

    if (
        !updates.title &&
        !updates.content
    ) {
        throw new Error(
            "Nothing to update."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("manga_discussions")
        .update(updates)
        .eq("id", discussionId)
        .eq("user_id", user.id)
        .select(`
            id,
            manga_id,
            user_id,
            title,
            content,
            created_at,
            updated_at
        `)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    if (!data) {
        throw new Error(
            "Discussion not found or you do not have permission to edit it."
        );
    }

    emit(EVENTS.UPDATED, data);
    emit(EVENTS.CHANGED, data);

    return data;
}

// ------------------------------------------------------------
// Delete discussion
// ------------------------------------------------------------

export async function deleteDiscussion(
    discussionId
) {

    const user = currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in."
        );
    }

    if (!discussionId) {
        throw new Error(
            "Discussion ID is required."
        );
    }

    const {
        error
    } = await supabase
        .from("manga_discussions")
        .delete()
        .eq("id", discussionId)
        .eq("user_id", user.id);

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    emit(EVENTS.DELETED, {
        id: discussionId
    });

    emit(EVENTS.CHANGED, {
        id: discussionId
    });

    return true;
}

// ------------------------------------------------------------
// Check if user liked discussion
// ------------------------------------------------------------

export async function hasLikedDiscussion(
    discussionId
) {

    const user = currentUser || await getCurrentUser();

    if (!user || !discussionId) {
        return false;
    }

    const {
        data,
        error
    } = await supabase
        .from("manga_discussion_likes")
        .select("id")
        .eq("discussion_id", discussionId)
        .eq("user_id", user.id)
        .maybeSingle();

    if (error) {
        if (error.code === "PGRST116") {
            return false;
        }

        throw error;
    }

    return Boolean(data);
}

// ------------------------------------------------------------
// Get discussion like count
// ------------------------------------------------------------

export async function getDiscussionLikeCount(
    discussionId
) {

    if (!discussionId) {
        return 0;
    }

    const {
        count,
        error
    } = await supabase
        .from("manga_discussion_likes")
        .select("id", {
            count: "exact",
            head: true
        })
        .eq(
            "discussion_id",
            discussionId
        );

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    return count || 0;
}

// ------------------------------------------------------------
// Like discussion
// ------------------------------------------------------------

export async function likeDiscussion(
    discussionId
) {

    const user = currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in to like discussions."
        );
    }

    if (!discussionId) {
        throw new Error(
            "Discussion ID is required."
        );
    }

    const alreadyLiked =
        await hasLikedDiscussion(discussionId);

    if (alreadyLiked) {
        return {
            liked: true,
            alreadyLiked: true
        };
    }

    const {
        data,
        error
    } = await supabase
        .from("manga_discussion_likes")
        .insert({
            discussion_id: discussionId,
            user_id: user.id
        })
        .select()
        .maybeSingle();

    if (error) {

        // Unique constraint means the user
        // already liked it.
        if (error.code === "23505") {
            return {
                liked: true,
                alreadyLiked: true
            };
        }

        emit(EVENTS.ERROR, error);
        throw error;
    }

    emit(EVENTS.LIKED, {
        discussionId,
        like: data
    });

    emit(EVENTS.CHANGED, {
        type: "like",
        discussionId
    });

    return {
        liked: true,
        like: data
    };
}

// ------------------------------------------------------------
// Unlike discussion
// ------------------------------------------------------------

export async function unlikeDiscussion(
    discussionId
) {

    const user = currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in."
        );
    }

    if (!discussionId) {
        throw new Error(
            "Discussion ID is required."
        );
    }

    const {
        error
    } = await supabase
        .from("manga_discussion_likes")
        .delete()
        .eq(
            "discussion_id",
            discussionId
        )
        .eq(
            "user_id",
            user.id
        );

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    emit(EVENTS.UNLIKED, {
        discussionId
    });

    emit(EVENTS.CHANGED, {
        type: "unlike",
        discussionId
    });

    return {
        liked: false
    };
}

// ------------------------------------------------------------
// Toggle like
// ------------------------------------------------------------

export async function toggleDiscussionLike(
    discussionId
) {

    const liked =
        await hasLikedDiscussion(discussionId);

    if (liked) {
        return await unlikeDiscussion(
            discussionId
        );
    }

    return await likeDiscussion(
        discussionId
    );
}

// ------------------------------------------------------------
// Subscribe to manga realtime changes
// ------------------------------------------------------------

export function subscribeToManga(
    mangaId = null
) {

    unsubscribeFromManga();

    const channelName = mangaId
        ? `regenesis-manga-${mangaId}`
        : "regenesis-manga";

    realtimeChannel = supabase
        .channel(channelName);

    realtimeChannel.on(
        "postgres_changes",
        {
            event: "*",
            schema: "public",
            table: "manga",
            ...(mangaId
                ? {
                    filter: `id=eq.${mangaId}`
                }
                : {})
        },
        payload => {

            emit(EVENTS.CHANGED, {
                type: "manga",
                payload
            });

        }
    );

    realtimeChannel.on(
        "postgres_changes",
        {
            event: "*",
            schema: "public",
            table: "manga_discussions",
            ...(mangaId
                ? {
                    filter: `manga_id=eq.${mangaId}`
                }
                : {})
        },
        payload => {

            emit(EVENTS.CHANGED, {
                type: "discussion",
                payload
            });

        }
    );

    realtimeChannel.on(
        "postgres_changes",
        {
            event: "*",
            schema: "public",
            table: "manga_discussion_likes"
        },
        payload => {

            emit(EVENTS.CHANGED, {
                type: "like",
                payload
            });

        }
    );

    realtimeChannel.subscribe(status => {

        if (status === "SUBSCRIBED") {
            console.log(
                "REGENESIS manga realtime connected."
            );
        }

        if (status === "CHANNEL_ERROR") {
            console.error(
                "REGENESIS manga realtime error."
            );
        }
    });

    return realtimeChannel;
}

// ------------------------------------------------------------
// Unsubscribe realtime
// ------------------------------------------------------------

export async function unsubscribeFromManga() {

    if (!realtimeChannel) {
        return;
    }

    await supabase.removeChannel(
        realtimeChannel
    );

    realtimeChannel = null;
}

// ------------------------------------------------------------
// Refresh manga
// ------------------------------------------------------------

export async function refreshManga(
    options = {}
) {

    return await loadManga(options);
}

// ------------------------------------------------------------
// Initialization
// ------------------------------------------------------------

export async function initializeManga(
    options = {}
) {

    await getCurrentUser();

    const result =
        await loadManga(options);

    subscribeToManga();

    return result;
}

// ------------------------------------------------------------
// Destroy module
// ------------------------------------------------------------

export async function destroyManga() {

    await unsubscribeFromManga();

    listeners.clear();

    currentUser = null;
    currentManga = null;
    mangaList = [];
    loading = false;
}

// ------------------------------------------------------------
// State getters
// ------------------------------------------------------------

export function getCurrentManga() {
    return currentManga;
}

export function getMangaList() {
    return [...mangaList];
}

export function isMangaLoading() {
    return loading;
}

export function getCachedUser() {
    return currentUser;
}

export function getRealtimeChannel() {
    return realtimeChannel;
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
    EVENTS,

    onMangaChange,

    getCurrentUser,

    loadManga,
    refreshManga,

    getMangaById,
    getMangaBySlug,
    getManga,

    searchManga,
    getMangaByGenre,
    getMangaByStatus,

    getGenres,
    getMangaCount,

    getMangaDiscussions,
    getDiscussion,

    createDiscussion,
    updateDiscussion,
    deleteDiscussion,

    hasLikedDiscussion,
    getDiscussionLikeCount,
    likeDiscussion,
    unlikeDiscussion,
    toggleDiscussionLike,

    subscribeToManga,
    unsubscribeFromManga,

    initializeManga,
    destroyManga,

    getCurrentManga,
    getMangaList,
    isMangaLoading,
    getCachedUser,
    getRealtimeChannel
};