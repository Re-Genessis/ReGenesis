// js/cosplay/profiles.js
// REGENESIS — Cosplay Profiles
// Real Supabase-powered cosplay profile listing and search

import { supabase } from "../supabase.js";

const PAGE_SIZE = 24;

let profiles = [];
let loading = false;
let currentPage = 1;
let totalProfiles = 0;

const listeners = new Set();

export const PROFILES_EVENTS = {
  LOADING: "profiles:loading",
  LOADED: "profiles:loaded",
  ERROR: "profiles:error",
  CHANGED: "profiles:changed"
};

/* =========================================================
   EVENTS
========================================================= */

function emit(event, detail = {}) {
  listeners.forEach((callback) => {
    try {
      callback(event, detail);
    } catch (error) {
      console.error("Cosplay profiles listener error:", error);
    }
  });

  document.dispatchEvent(
    new CustomEvent(`regenesis:${event}`, {
      detail
    })
  );
}

export function onProfilesChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

/* =========================================================
   CURRENT USER
========================================================= */

export async function getCurrentUser() {
  const {
    data: { user },
    error
  } = await supabase.auth.getUser();

  if (error) {
    console.error("Unable to get current user:", error);
    return null;
  }

  return user || null;
}

/* =========================================================
   LOAD PROFILES
========================================================= */

export async function loadProfiles(options = {}) {
  const {
    search = "",
    character = "",
    page = 1,
    pageSize = PAGE_SIZE,
    orderBy = "created_at",
    ascending = false
  } = options;

  loading = true;
  currentPage = Math.max(1, Number(page) || 1);

  emit(PROFILES_EVENTS.LOADING, {
    page: currentPage
  });

  try {
    let query = supabase
      .from("cosplay_profiles")
      .select(
        `
          id,
          user_id,
          username,
          character_name,
          bio,
          avatar_url,
          banner_url,
          created_at,
          updated_at
        `,
        { count: "exact" }
      );

    const searchValue = String(search || "").trim();
    const characterValue = String(character || "").trim();

    /*
      Search is handled separately so user input is not directly
      inserted into a PostgREST .or() expression.
    */

    if (searchValue) {
      query = query.ilike("username", `%${searchValue}%`);
    }

    if (characterValue) {
      query = query.ilike(
        "character_name",
        `%${characterValue}%`
      );
    }

    const validOrderColumns = [
      "created_at",
      "updated_at",
      "username",
      "character_name"
    ];

    const safeOrderBy = validOrderColumns.includes(orderBy)
      ? orderBy
      : "created_at";

    const safePageSize = Math.min(
      Math.max(Number(pageSize) || PAGE_SIZE, 1),
      100
    );

    const from =
      (currentPage - 1) * safePageSize;

    const to =
      from + safePageSize - 1;

    const {
      data,
      error,
      count
    } = await query
      .order(safeOrderBy, {
        ascending: Boolean(ascending)
      })
      .range(from, to);

    if (error) {
      throw error;
    }

    profiles = data || [];
    totalProfiles = count || 0;

    emit(PROFILES_EVENTS.LOADED, {
      profiles,
      total: totalProfiles,
      page: currentPage,
      pageSize: safePageSize
    });

    return {
      profiles,
      total: totalProfiles,
      page: currentPage,
      pageSize: safePageSize,
      totalPages: Math.ceil(
        totalProfiles / safePageSize
      )
    };
  } catch (error) {
    console.error("Failed to load cosplay profiles:", error);

    profiles = [];
    totalProfiles = 0;

    emit(PROFILES_EVENTS.ERROR, {
      error
    });

    throw error;
  } finally {
    loading = false;
  }
}

/* =========================================================
   LOAD ALL PROFILES
========================================================= */

export async function loadAllProfiles(options = {}) {
  const {
    search = "",
    character = "",
    orderBy = "created_at",
    ascending = false
  } = options;

  try {
    let query = supabase
      .from("cosplay_profiles")
      .select(
        `
          id,
          user_id,
          username,
          character_name,
          bio,
          avatar_url,
          banner_url,
          created_at,
          updated_at
        `
      );

    const searchValue = String(search || "").trim();
    const characterValue = String(character || "").trim();

    if (searchValue) {
      query = query.ilike(
        "username",
        `%${searchValue}%`
      );
    }

    if (characterValue) {
      query = query.ilike(
        "character_name",
        `%${characterValue}%`
      );
    }

    const validOrderColumns = [
      "created_at",
      "updated_at",
      "username",
      "character_name"
    ];

    const safeOrderBy = validOrderColumns.includes(orderBy)
      ? orderBy
      : "created_at";

    const { data, error } = await query.order(
      safeOrderBy,
      {
        ascending: Boolean(ascending)
      }
    );

    if (error) {
      throw error;
    }

    return data || [];
  } catch (error) {
    console.error(
      "Failed to load all cosplay profiles:",
      error
    );

    throw error;
  }
}

/* =========================================================
   GET PROFILE BY ID
========================================================= */

export async function getProfileById(profileId) {
  if (!profileId) {
    return null;
  }

  try {
    const { data, error } = await supabase
      .from("cosplay_profiles")
      .select(
        `
          id,
          user_id,
          username,
          character_name,
          bio,
          avatar_url,
          banner_url,
          created_at,
          updated_at
        `
      )
      .eq("id", profileId)
      .maybeSingle();

    if (error) {
      throw error;
    }

    return data || null;
  } catch (error) {
    console.error(
      "Failed to get cosplay profile:",
      error
    );

    throw error;
  }
}

/* =========================================================
   GET PROFILE BY USER ID
========================================================= */

export async function getProfileByUserId(userId) {
  if (!userId) {
    return null;
  }

  try {
    const { data, error } = await supabase
      .from("cosplay_profiles")
      .select(
        `
          id,
          user_id,
          username,
          character_name,
          bio,
          avatar_url,
          banner_url,
          created_at,
          updated_at
        `
      )
      .eq("user_id", userId)
      .maybeSingle();

    if (error) {
      throw error;
    }

    return data || null;
  } catch (error) {
    console.error(
      "Failed to get user's cosplay profile:",
      error
    );

    throw error;
  }
}

/* =========================================================
   GET PROFILE BY USERNAME
========================================================= */

export async function getProfileByUsername(username) {
  const value = String(username || "").trim();

  if (!value) {
    return null;
  }

  try {
    const { data, error } = await supabase
      .from("cosplay_profiles")
      .select(
        `
          id,
          user_id,
          username,
          character_name,
          bio,
          avatar_url,
          banner_url,
          created_at,
          updated_at
        `
      )
      .ilike("username", value)
      .maybeSingle();

    if (error) {
      throw error;
    }

    return data || null;
  } catch (error) {
    console.error(
      "Failed to find cosplay username:",
      error
    );

    throw error;
  }
}

/* =========================================================
   SEARCH BY CHARACTER
========================================================= */

export async function searchByCharacter(
  characterName,
  options = {}
) {
  const character = String(characterName || "").trim();

  if (!character) {
    return [];
  }

  const {
    limit = 24,
    ascending = true
  } = options;

  const safeLimit = Math.min(
    Math.max(Number(limit) || 24, 1),
    100
  );

  try {
    const { data, error } = await supabase
      .from("cosplay_profiles")
      .select(
        `
          id,
          user_id,
          username,
          character_name,
          bio,
          avatar_url,
          banner_url,
          created_at,
          updated_at
        `
      )
      .ilike(
        "character_name",
        `%${character}%`
      )
      .order("character_name", {
        ascending
      })
      .limit(safeLimit);

    if (error) {
      throw error;
    }

    return data || [];
  } catch (error) {
    console.error(
      "Failed to search cosplay characters:",
      error
    );

    throw error;
  }
}

/* =========================================================
   SEARCH BY USERNAME
========================================================= */

export async function searchByUsername(
  username,
  options = {}
) {
  const value = String(username || "").trim();

  if (!value) {
    return [];
  }

  const {
    limit = 24
  } = options;

  const safeLimit = Math.min(
    Math.max(Number(limit) || 24, 1),
    100
  );

  try {
    const { data, error } = await supabase
      .from("cosplay_profiles")
      .select(
        `
          id,
          user_id,
          username,
          character_name,
          bio,
          avatar_url,
          banner_url,
          created_at,
          updated_at
        `
      )
      .ilike(
        "username",
        `%${value}%`
      )
      .order("username", {
        ascending: true
      })
      .limit(safeLimit);

    if (error) {
      throw error;
    }

    return data || [];
  } catch (error) {
    console.error(
      "Failed to search cosplay usernames:",
      error
    );

    throw error;
  }
}

/* =========================================================
   CHECK USERNAME
========================================================= */

export async function isUsernameAvailable(username) {
  const value = String(username || "").trim();

  if (!value) {
    return false;
  }

  try {
    const { data, error } = await supabase
      .from("cosplay_profiles")
      .select("id")
      .ilike("username", value)
      .limit(1);

    if (error) {
      throw error;
    }

    return !data || data.length === 0;
  } catch (error) {
    console.error(
      "Failed to check cosplay username:",
      error
    );

    throw error;
  }
}

/* =========================================================
   GET MY PROFILE
========================================================= */

export async function getMyProfile() {
  const user = await getCurrentUser();

  if (!user) {
    return null;
  }

  return getProfileByUserId(user.id);
}

/* =========================================================
   PROFILE EXISTENCE
========================================================= */

export async function hasProfile(userId = null) {
  let id = userId;

  if (!id) {
    const user = await getCurrentUser();

    if (!user) {
      return false;
    }

    id = user.id;
  }

  try {
    const { count, error } = await supabase
      .from("cosplay_profiles")
      .select("id", {
        count: "exact",
        head: true
      })
      .eq("user_id", id);

    if (error) {
      throw error;
    }

    return Number(count || 0) > 0;
  } catch (error) {
    console.error(
      "Failed to check cosplay profile:",
      error
    );

    throw error;
  }
}

/* =========================================================
   PROFILE URL
========================================================= */

export function getProfileURL(profile) {
  if (!profile?.id) {
    return "./profile.html";
  }

  return `./profile.html?id=${encodeURIComponent(
    profile.id
  )}`;
}

/* =========================================================
   USERNAME URL
========================================================= */

export function getUsernameURL(username) {
  if (!username) {
    return "./profile.html";
  }

  return `./profile.html?username=${encodeURIComponent(
    username
  )}`;
}

/* =========================================================
   PAGINATION
========================================================= */

export function getPaginationInfo(
  page = currentPage,
  pageSize = PAGE_SIZE
) {
  const safePage = Math.max(
    1,
    Number(page) || 1
  );

  const safePageSize = Math.max(
    1,
    Number(pageSize) || PAGE_SIZE
  );

  const totalPages = Math.max(
    1,
    Math.ceil(totalProfiles / safePageSize)
  );

  return {
    page: safePage,
    pageSize: safePageSize,
    total: totalProfiles,
    totalPages,
    hasPrevious: safePage > 1,
    hasNext: safePage < totalPages
  };
}

/* =========================================================
   REFRESH
========================================================= */

export async function refreshProfiles(options = {}) {
  return loadProfiles({
    ...options,
    page: options.page || currentPage
  });
}

/* =========================================================
   REALTIME
========================================================= */

let realtimeChannel = null;

export function subscribeToProfiles() {
  if (realtimeChannel) {
    return realtimeChannel;
  }

  realtimeChannel = supabase
    .channel("regenesis-cosplay-profiles")
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "cosplay_profiles"
      },
      async (payload) => {
        emit(PROFILES_EVENTS.CHANGED, {
          payload
        });

        try {
          await refreshProfiles();
        } catch (error) {
          console.error(
            "Realtime cosplay profile refresh failed:",
            error
          );
        }
      }
    )
    .subscribe((status) => {
      console.log(
        "Cosplay profiles realtime:",
        status
      );
    });

  return realtimeChannel;
}

export async function unsubscribeFromProfiles() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "Failed to unsubscribe from cosplay profiles:",
      error
    );
  }

  realtimeChannel = null;
}

/* =========================================================
   STATE
========================================================= */

export function getProfiles() {
  return [...profiles];
}

export function getProfileCount() {
  return totalProfiles;
}

export function isLoading() {
  return loading;
}

export function getCurrentPage() {
  return currentPage;
}

/* =========================================================
   INITIALIZE
========================================================= */

export async function initializeProfiles(
  options = {}
) {
  subscribeToProfiles();

  return loadProfiles(options);
}

/* =========================================================
   DESTROY
========================================================= */

export async function destroyProfiles() {
  await unsubscribeFromProfiles();

  profiles = [];
  totalProfiles = 0;
  currentPage = 1;

  listeners.clear();
}

/* =========================================================
   DEFAULT EXPORT
========================================================= */

export default {
  PROFILES_EVENTS,

  onProfilesChange,

  getCurrentUser,

  loadProfiles,
  loadAllProfiles,
  refreshProfiles,

  getProfileById,
  getProfileByUserId,
  getProfileByUsername,

  searchByCharacter,
  searchByUsername,

  isUsernameAvailable,
  hasProfile,
  getMyProfile,

  getProfileURL,
  getUsernameURL,

  getPaginationInfo,

  subscribeToProfiles,
  unsubscribeFromProfiles,

  initializeProfiles,
  destroyProfiles,

  getProfiles,
  getProfileCount,
  getCurrentPage,
  isLoading
};