// ============================================================
// REGENESIS — COSPLAY SYSTEM
// File: js/cosplay/cosplay.js
// ============================================================

import { supabase } from "../supabase.js";


// ============================================================
// STATE
// ============================================================

let currentUser = null;
let currentProfile = null;
let cosplayProfiles = [];

const listeners = new Set();

let realtimeChannel = null;


// ============================================================
// EVENTS
// ============================================================

export const COSPLAY_EVENTS = {

  INITIALIZED: "cosplay:initialized",

  PROFILE_CREATED: "cosplay:profile-created",

  PROFILE_UPDATED: "cosplay:profile-updated",

  PROFILE_DELETED: "cosplay:profile-deleted",

  PROFILES_UPDATED: "cosplay:profiles-updated",

  ERROR: "cosplay:error"

};


// ============================================================
// EVENT LISTENER
// ============================================================

export function onCosplayChange(callback) {

  if (typeof callback !== "function") {

    throw new Error(
      "onCosplayChange requires a callback."
    );

  }

  listeners.add(callback);

  return () => {

    listeners.delete(callback);

  };

}


// ============================================================
// NOTIFY
// ============================================================

function notify(
  event,
  data = null
) {

  listeners.forEach(
    callback => {

      try {

        callback({

          event,

          data,

          user:
            currentUser,

          profile:
            currentProfile,

          profiles:
            cosplayProfiles

        });

      } catch (error) {

        console.error(
          "[REGENESIS Cosplay] Listener error:",
          error
        );

      }

    }
  );

}


// ============================================================
// CURRENT USER
// ============================================================

export async function getCurrentUser() {

  try {

    const {
      data,
      error
    } = await supabase.auth.getUser();

    if (error) {

      throw error;

    }

    currentUser =
      data?.user || null;

    return currentUser;

  } catch (error) {

    console.error(
      "[REGENESIS Cosplay] Failed to get user:",
      error
    );

    currentUser = null;

    return null;

  }

}


// ============================================================
// GET CURRENT COSPLAY PROFILE
// ============================================================

export async function getMyCosplayProfile(
  userId = currentUser?.id
) {

  if (!userId) {

    currentProfile = null;

    return null;

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_profiles")
    .select("*")
    .eq(
      "user_id",
      userId
    )
    .maybeSingle();


  if (error) {

    console.error(
      "[REGENESIS Cosplay] Profile lookup failed:",
      error
    );

    throw error;

  }


  currentProfile =
    data || null;


  return currentProfile;

}


// ============================================================
// CHECK IF USER HAS COSPLAY PROFILE
// ============================================================

export async function hasCosplayProfile(
  userId = currentUser?.id
) {

  const profile =
    await getMyCosplayProfile(
      userId
    );


  return !!profile;

}


// ============================================================
// GET PROFILE BY ID
// ============================================================

export async function getCosplayProfile(
  profileId
) {

  if (!profileId) {

    throw new Error(
      "Cosplay profile ID is required."
    );

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_profiles")
    .select("*")
    .eq(
      "id",
      profileId
    )
    .maybeSingle();


  if (error) {

    throw error;

  }


  return data;

}


// ============================================================
// GET PROFILE BY USERNAME
// ============================================================

export async function getCosplayProfileByUsername(
  username
) {

  const value =
    String(username ?? "")
      .trim();


  if (!value) {

    throw new Error(
      "Username is required."
    );

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_profiles")
    .select("*")
    .ilike(
      "username",
      value
    )
    .maybeSingle();


  if (error) {

    throw error;

  }


  return data;

}


// ============================================================
// LOAD ALL COSPLAY PROFILES
// ============================================================

export async function loadCosplayProfiles({

  search = "",

  limit = 50,

  offset = 0

} = {}) {

  const safeLimit =
    Math.min(
      Math.max(
        Number(limit) || 50,
        1
      ),
      100
    );


  const safeOffset =
    Math.max(
      Number(offset) || 0,
      0
    );


  let query =
    supabase
      .from("cosplay_profiles")
      .select(`
        id,
        user_id,
        username,
        character_name,
        bio,
        avatar_url,
        banner_url,
        created_at,
        updated_at
      `)
      .order(
        "created_at",
        {
          ascending: false
        }
      )
      .range(
        safeOffset,
        safeOffset +
          safeLimit -
          1
      );


  const searchValue =
    String(search ?? "")
      .trim();


  if (searchValue) {

    /*
      Search real profile information.
    */

    query =
      query.or(
        `username.ilike.%${searchValue}%,character_name.ilike.%${searchValue}%`
      );

  }


  const {
    data,
    error
  } = await query;


  if (error) {

    notify(
      COSPLAY_EVENTS.ERROR,
      error
    );

    throw error;

  }


  cosplayProfiles =
    data || [];


  notify(
    COSPLAY_EVENTS.PROFILES_UPDATED,
    cosplayProfiles
  );


  return cosplayProfiles;

}


// ============================================================
// SEARCH COSPLAYERS
// ============================================================

export async function searchCosplayers(
  searchTerm
) {

  return loadCosplayProfiles({

    search:
      searchTerm,

    limit:
      50,

    offset:
      0

  });

}


// ============================================================
// CREATE COSPLAY PROFILE
// ============================================================

export async function createCosplayProfile({

  username,

  characterName,

  bio = "",

  avatarUrl = null,

  bannerUrl = null

} = {}) {

  if (!currentUser) {

    await getCurrentUser();

  }


  if (!currentUser) {

    throw new Error(
      "You must be logged in to create a cosplay profile."
    );

  }


  /*
    A REGENESIS account can have only
    ONE cosplay profile.

    This is checked here for UX.

    A UNIQUE constraint on user_id must
    also exist in Supabase.
  */

  const existing =
    await getMyCosplayProfile(
      currentUser.id
    );


  if (existing) {

    throw new Error(
      "You already have a cosplay profile."
    );

  }


  const cleanUsername =
    String(username ?? "")
      .trim();


  const cleanCharacter =
    String(characterName ?? "")
      .trim();


  const cleanBio =
    String(bio ?? "")
      .trim();


  if (!cleanUsername) {

    throw new Error(
      "Cosplay username is required."
    );

  }


  if (
    cleanUsername.length <
    3
  ) {

    throw new Error(
      "Username must contain at least 3 characters."
    );

  }


  if (
    cleanUsername.length >
    30
  ) {

    throw new Error(
      "Username cannot be longer than 30 characters."
    );

  }


  if (!/^[a-zA-Z0-9_]+$/.test(
    cleanUsername
  )) {

    throw new Error(
      "Username can only contain letters, numbers and underscores."
    );

  }


  if (!cleanCharacter) {

    throw new Error(
      "Enter the character you cosplay."
    );

  }


  if (
    cleanCharacter.length >
    100
  ) {

    throw new Error(
      "Character name is too long."
    );

  }


  if (
    cleanBio.length >
    1000
  ) {

    throw new Error(
      "Bio cannot be longer than 1000 characters."
    );

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_profiles")
    .insert({

      user_id:
        currentUser.id,

      username:
        cleanUsername,

      character_name:
        cleanCharacter,

      bio:
        cleanBio || null,

      avatar_url:
        avatarUrl || null,

      banner_url:
        bannerUrl || null

    })
    .select("*")
    .single();


  if (error) {

    if (
      error.code === "23505"
    ) {

      throw new Error(
        "That username is already being used, or you already have a cosplay profile."
      );

    }

    throw error;

  }


  currentProfile =
    data;


  cosplayProfiles = [
    data,
    ...cosplayProfiles
  ];


  notify(
    COSPLAY_EVENTS.PROFILE_CREATED,
    data
  );


  return data;

}


// ============================================================
// UPDATE COSPLAY PROFILE
// ============================================================

export async function updateCosplayProfile({

  profileId =
    currentProfile?.id,

  username,

  characterName,

  bio,

  avatarUrl,

  bannerUrl

} = {}) {

  if (!currentUser) {

    await getCurrentUser();

  }


  if (!currentUser) {

    throw new Error(
      "You must be logged in."
    );

  }


  if (!profileId) {

    throw new Error(
      "Cosplay profile ID is required."
    );

  }


  const cleanUsername =
    String(username ?? "")
      .trim();


  const cleanCharacter =
    String(characterName ?? "")
      .trim();


  const cleanBio =
    String(bio ?? "")
      .trim();


  if (!cleanUsername) {

    throw new Error(
      "Cosplay username is required."
    );

  }


  if (
    !/^[a-zA-Z0-9_]{3,30}$/
      .test(cleanUsername)
  ) {

    throw new Error(
      "Username must be 3–30 characters and contain only letters, numbers and underscores."
    );

  }


  if (!cleanCharacter) {

    throw new Error(
      "Character name is required."
    );

  }


  if (
    cleanCharacter.length >
    100
  ) {

    throw new Error(
      "Character name is too long."
    );

  }


  if (
    cleanBio.length >
    1000
  ) {

    throw new Error(
      "Bio cannot be longer than 1000 characters."
    );

  }


  const updates = {

    username:
      cleanUsername,

    character_name:
      cleanCharacter,

    bio:
      cleanBio || null,

    avatar_url:
      avatarUrl || null,

    banner_url:
      bannerUrl || null,

    updated_at:
      new Date().toISOString()

  };


  /*
    RLS must ensure the current authenticated
    user owns this cosplay profile.
  */

  const {
    data,
    error
  } = await supabase
    .from("cosplay_profiles")
    .update(updates)
    .eq(
      "id",
      profileId
    )
    .eq(
      "user_id",
      currentUser.id
    )
    .select("*")
    .single();


  if (error) {

    if (
      error.code === "23505"
    ) {

      throw new Error(
        "That username is already being used."
      );

    }

    throw error;

  }


  currentProfile =
    data;


  cosplayProfiles =
    cosplayProfiles.map(
      profile =>
        profile.id === profileId
          ? data
          : profile
    );


  notify(
    COSPLAY_EVENTS.PROFILE_UPDATED,
    data
  );


  return data;

}


// ============================================================
// DELETE COSPLAY PROFILE
// ============================================================

export async function deleteCosplayProfile(
  profileId =
    currentProfile?.id
) {

  if (!currentUser) {

    await getCurrentUser();

  }


  if (!currentUser) {

    throw new Error(
      "You must be logged in."
    );

  }


  if (!profileId) {

    throw new Error(
      "Cosplay profile ID is required."
    );

  }


  /*
    RLS must ensure that users can only
    delete their own cosplay profile.
  */

  const {
    error
  } = await supabase
    .from("cosplay_profiles")
    .delete()
    .eq(
      "id",
      profileId
    )
    .eq(
      "user_id",
      currentUser.id
    );


  if (error) {

    throw error;

  }


  cosplayProfiles =
    cosplayProfiles.filter(
      profile =>
        profile.id !== profileId
    );


  if (
    currentProfile?.id ===
    profileId
  ) {

    currentProfile =
      null;

  }


  notify(
    COSPLAY_EVENTS.PROFILE_DELETED,
    {
      id:
        profileId
    }
  );


  return true;

}


// ============================================================
// CHECK USERNAME AVAILABILITY
// ============================================================

export async function isUsernameAvailable(
  username,
  excludeProfileId = null
) {

  const value =
    String(username ?? "")
      .trim();


  if (!value) {

    return false;

  }


  let query =
    supabase
      .from("cosplay_profiles")
      .select(
        "id",
        {
          count: "exact",
          head: true
        }
      )
      .ilike(
        "username",
        value
      );


  if (
    excludeProfileId
  ) {

    query =
      query.neq(
        "id",
        excludeProfileId
      );

  }


  const {
    count,
    error
  } = await query;


  if (error) {

    throw error;

  }


  return (
    (count || 0) === 0
  );

}


// ============================================================
// CHECK CHARACTER NAME
// ============================================================

export function validateCharacterName(
  characterName
) {

  const value =
    String(characterName ?? "")
      .trim();


  if (!value) {

    return {

      valid: false,

      message:
        "Character name is required."

    };

  }


  if (
    value.length >
    100
  ) {

    return {

      valid: false,

      message:
        "Character name cannot exceed 100 characters."

    };

  }


  return {

    valid: true,

    message: ""

  };

}


// ============================================================
// CHECK USERNAME
// ============================================================

export function validateCosplayUsername(
  username
) {

  const value =
    String(username ?? "")
      .trim();


  if (!value) {

    return {

      valid: false,

      message:
        "Username is required."

    };

  }


  if (
    !/^[a-zA-Z0-9_]{3,30}$/
      .test(value)
  ) {

    return {

      valid: false,

      message:
        "Username must be 3–30 characters and use only letters, numbers and underscores."

    };

  }


  return {

    valid: true,

    message: ""

  };

}


// ============================================================
// GET PROFILE URL
// ============================================================

export function getCosplayProfileURL(
  profileId
) {

  if (!profileId) {

    return null;

  }


  return (
    `../cosplay/profile.html?id=${encodeURIComponent(
      profileId
    )}`
  );

}


// ============================================================
// GET USER PROFILE URL
// ============================================================

export function getMyProfileURL(
  userId =
    currentUser?.id
) {

  if (!userId) {

    return null;

  }


  return (
    `../cosplay/profile.html?user=${encodeURIComponent(
      userId
    )}`
  );

}


// ============================================================
// REALTIME
// ============================================================

export function subscribeToCosplay() {

  if (realtimeChannel) {

    supabase.removeChannel(
      realtimeChannel
    );

  }


  realtimeChannel =
    supabase
      .channel(
        "regenesis-cosplay-profiles"
      )

      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "cosplay_profiles"
        },
        async payload => {

          if (
            payload.eventType ===
            "INSERT"
          ) {

            const profile =
              payload.new;


            const exists =
              cosplayProfiles.some(
                item =>
                  item.id ===
                  profile.id
              );


            if (!exists) {

              cosplayProfiles = [
                profile,
                ...cosplayProfiles
              ];

            }

          }


          if (
            payload.eventType ===
            "UPDATE"
          ) {

            cosplayProfiles =
              cosplayProfiles.map(
                profile =>
                  profile.id ===
                  payload.new.id
                    ? payload.new
                    : profile
              );


            if (
              currentProfile?.id ===
              payload.new.id
            ) {

              currentProfile =
                payload.new;

            }

          }


          if (
            payload.eventType ===
            "DELETE"
          ) {

            cosplayProfiles =
              cosplayProfiles.filter(
                profile =>
                  profile.id !==
                  payload.old.id
              );


            if (
              currentProfile?.id ===
              payload.old.id
            ) {

              currentProfile =
                null;

            }

          }


          notify(
            COSPLAY_EVENTS.PROFILES_UPDATED,
            payload
          );

        }
      )

      .subscribe(
        status => {

          if (
            status ===
            "SUBSCRIBED"
          ) {

            console.log(
              "[REGENESIS Cosplay] Realtime connected."
            );

          }

          if (
            status ===
            "CHANNEL_ERROR"
          ) {

            console.error(
              "[REGENESIS Cosplay] Realtime channel error."
            );

          }

          if (
            status ===
            "TIMED_OUT"
          ) {

            console.error(
              "[REGENESIS Cosplay] Realtime connection timed out."
            );

          }

        }
      );


  return realtimeChannel;

}


// ============================================================
// STOP REALTIME
// ============================================================

export async function unsubscribeFromCosplay() {

  if (!realtimeChannel) {

    return;

  }


  try {

    await supabase.removeChannel(
      realtimeChannel
    );

  } catch (error) {

    console.error(
      "[REGENESIS Cosplay] Failed to stop realtime:",
      error
    );

  }


  realtimeChannel =
    null;

}


// ============================================================
// INITIALIZE
// ============================================================

export async function initializeCosplay() {

  await getCurrentUser();


  if (currentUser) {

    await getMyCosplayProfile(
      currentUser.id
    );

  }


  await loadCosplayProfiles();


  subscribeToCosplay();


  notify(
    COSPLAY_EVENTS.INITIALIZED,
    {
      user:
        currentUser,

      profile:
        currentProfile,

      profiles:
        cosplayProfiles
    }
  );


  return {

    user:
      currentUser,

    profile:
      currentProfile,

    profiles:
      cosplayProfiles

  };

}


// ============================================================
// CURRENT STATE
// ============================================================

export function getCurrentProfile() {

  return currentProfile;

}


export function getProfiles() {

  return [
    ...cosplayProfiles
  ];

}


export function getUser() {

  return currentUser;

}


// ============================================================
// CLEANUP
// ============================================================

export async function destroyCosplay() {

  await unsubscribeFromCosplay();


  currentUser =
    null;

  currentProfile =
    null;

  cosplayProfiles =
    [];

}


// ============================================================
// DEFAULT EXPORT
// ============================================================

export default {

  getCurrentUser,

  getMyCosplayProfile,

  hasCosplayProfile,

  getCosplayProfile,

  getCosplayProfileByUsername,

  loadCosplayProfiles,

  searchCosplayers,

  createCosplayProfile,

  updateCosplayProfile,

  deleteCosplayProfile,

  isUsernameAvailable,

  validateCharacterName,

  validateCosplayUsername,

  getCosplayProfileURL,

  getMyProfileURL,

  subscribeToCosplay,

  unsubscribeFromCosplay,

  initializeCosplay,

  getCurrentProfile,

  getProfiles,

  getUser,

  onCosplayChange,

  destroyCosplay,

  COSPLAY_EVENTS

};