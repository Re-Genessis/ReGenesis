// ============================================================
// REGENESIS — COSPLAY COMPETITIONS
// File: js/cosplay/competition.js
// ============================================================

import { supabase } from "../supabase.js";


// ============================================================
// STATE
// ============================================================

let currentUser = null;
let currentCompetition = null;
let currentEntries = [];

let competitionListeners = new Set();


// ============================================================
// EVENTS
// ============================================================

export const COMPETITION_EVENTS = {
  LOADED: "competition:loaded",
  UPDATED: "competition:updated",
  ENTRIES_UPDATED: "competition:entries-updated",
  VOTE_UPDATED: "competition:vote-updated",
  ERROR: "competition:error"
};


// ============================================================
// EVENT LISTENER
// ============================================================

export function onCompetitionChange(callback) {

  if (typeof callback !== "function") {
    throw new Error(
      "onCompetitionChange requires a callback."
    );
  }

  competitionListeners.add(callback);

  return () => {
    competitionListeners.delete(callback);
  };

}


// ============================================================
// NOTIFY
// ============================================================

function notify(event, data = null) {

  competitionListeners.forEach(callback => {

    try {

      callback({
        event,
        data,
        competition: currentCompetition,
        entries: currentEntries,
        user: currentUser
      });

    } catch (error) {

      console.error(
        "[REGENESIS Competition] Listener error:",
        error
      );

    }

  });

}


// ============================================================
// GET CURRENT USER
// ============================================================

export async function loadCurrentUser() {

  try {

    const {
      data,
      error
    } = await supabase.auth.getUser();

    if (error) {
      throw error;
    }

    currentUser =
      data?.user || null;

    return currentUser;

  } catch (error) {

    console.error(
      "[REGENESIS Competition] User loading failed:",
      error
    );

    currentUser = null;

    return null;

  }

}


// ============================================================
// GET COMPETITION ID
// ============================================================

export function getCompetitionId(
  source = window.location.href
) {

  try {

    const url = new URL(source);

    return (
      url.searchParams.get("id") ||
      url.searchParams.get("competition")
    );

  } catch {

    return null;

  }

}


// ============================================================
// LOAD COMPETITION
// ============================================================

export async function loadCompetition(
  competitionId
) {

  if (!competitionId) {

    const error = new Error(
      "Competition ID is required."
    );

    notify(
      COMPETITION_EVENTS.ERROR,
      error
    );

    throw error;

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_competitions")
    .select("*")
    .eq("id", competitionId)
    .maybeSingle();


  if (error) {

    notify(
      COMPETITION_EVENTS.ERROR,
      error
    );

    throw error;

  }


  if (!data) {

    const notFound =
      new Error(
        "Cosplay competition not found."
      );

    notify(
      COMPETITION_EVENTS.ERROR,
      notFound
    );

    throw notFound;

  }


  currentCompetition =
    data;


  notify(
    COMPETITION_EVENTS.LOADED,
    data
  );


  return data;

}


// ============================================================
// REFRESH COMPETITION
// ============================================================

export async function refreshCompetition() {

  if (
    !currentCompetition?.id
  ) {

    return null;

  }


  return loadCompetition(
    currentCompetition.id
  );

}


// ============================================================
// LOAD COMPETITION ENTRIES
// ============================================================

export async function loadEntries(
  competitionId = currentCompetition?.id
) {

  if (!competitionId) {

    throw new Error(
      "Competition ID is required."
    );

  }


  /*
    Expected table:

    cosplay_entries

    id
    competition_id
    cosplay_profile_id
    user_id
    created_at
  */


  const {
    data,
    error
  } = await supabase
    .from("cosplay_entries")
    .select(`
      id,
      competition_id,
      cosplay_profile_id,
      user_id,
      created_at,
      cosplay_profiles (
        id,
        user_id,
        username,
        character_name,
        avatar_url,
        banner_url
      )
    `)
    .eq(
      "competition_id",
      competitionId
    )
    .order(
      "created_at",
      {
        ascending: true
      }
    );


  if (error) {

    notify(
      COMPETITION_EVENTS.ERROR,
      error
    );

    throw error;

  }


  currentEntries =
    data || [];


  notify(
    COMPETITION_EVENTS.ENTRIES_UPDATED,
    currentEntries
  );


  return currentEntries;

}


// ============================================================
// GET ENTRY
// ============================================================

export async function getEntry(
  entryId
) {

  if (!entryId) {

    throw new Error(
      "Entry ID is required."
    );

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_entries")
    .select(`
      id,
      competition_id,
      cosplay_profile_id,
      user_id,
      created_at,
      cosplay_profiles (
        id,
        user_id,
        username,
        character_name,
        avatar_url,
        banner_url
      )
    `)
    .eq(
      "id",
      entryId
    )
    .maybeSingle();


  if (error) {
    throw error;
  }


  return data;

}


// ============================================================
// CHECK WHETHER USER ENTERED
// ============================================================

export function getUserEntry(
  userId = currentUser?.id
) {

  if (!userId) {
    return null;
  }


  return (
    currentEntries.find(
      entry =>
        entry.user_id ===
        userId
    ) || null
  );

}


// ============================================================
// CHECK WHETHER VOTING IS OPEN
// ============================================================

export function isVotingOpen(
  competition = currentCompetition
) {

  if (!competition) {
    return false;
  }


  if (
    competition.status ===
    "cancelled"
  ) {

    return false;

  }


  if (
    competition.status ===
    "past"
  ) {

    return false;

  }


  const now =
    Date.now();


  if (
    competition.voting_starts_at
  ) {

    const start =
      new Date(
        competition.voting_starts_at
      ).getTime();

    if (
      now < start
    ) {

      return false;

    }

  }


  if (
    competition.voting_ends_at
  ) {

    const end =
      new Date(
        competition.voting_ends_at
      ).getTime();

    if (
      now > end
    ) {

      return false;

    }

  }


  return true;

}


// ============================================================
// CHECK WHETHER USER CAN VOTE
// ============================================================

export function canVote() {

  return (
    !!currentUser &&
    !!currentCompetition &&
    isVotingOpen()
  );

}


// ============================================================
// GET EXISTING VOTE
// ============================================================

export async function getUserVote(
  entryId,
  userId = currentUser?.id
) {

  if (
    !entryId ||
    !userId
  ) {

    return null;

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_votes")
    .select(
      "id, competition_id, entry_id, user_id, created_at"
    )
    .eq(
      "entry_id",
      entryId
    )
    .eq(
      "user_id",
      userId
    )
    .maybeSingle();


  if (error) {

    /*
      A missing row should normally return
      null. Other errors are returned.
    */

    if (
      error.code === "PGRST116"
    ) {

      return null;

    }

    throw error;

  }


  return data;

}


// ============================================================
// GET ALL USER VOTES FOR COMPETITION
// ============================================================

export async function getUserVotes(
  competitionId = currentCompetition?.id,
  userId = currentUser?.id
) {

  if (
    !competitionId ||
    !userId
  ) {

    return [];

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_votes")
    .select(
      "id, competition_id, entry_id, user_id, created_at"
    )
    .eq(
      "competition_id",
      competitionId
    )
    .eq(
      "user_id",
      userId
    );


  if (error) {
    throw error;
  }


  return data || [];

}


// ============================================================
// CAST VOTE
// ============================================================

export async function voteForEntry(
  entryId
) {

  if (!currentUser) {

    throw new Error(
      "You must be logged in to vote."
    );

  }


  if (!currentCompetition) {

    throw new Error(
      "No competition is currently loaded."
    );

  }


  if (!isVotingOpen()) {

    throw new Error(
      "Voting is currently closed."
    );

  }


  if (!entryId) {

    throw new Error(
      "Entry ID is required."
    );

  }


  const entry =
    currentEntries.find(
      item =>
        item.id ===
        entryId
    );


  if (
    !entry
  ) {

    throw new Error(
      "This competition entry does not exist."
    );

  }


  /*
    The database should enforce:
    - one vote per user per competition
    - valid competition/entry relationship
    - authenticated voting
  */


  const {
    data,
    error
  } = await supabase
    .from("cosplay_votes")
    .insert({
      competition_id:
        currentCompetition.id,

      entry_id:
        entryId,

      user_id:
        currentUser.id
    })
    .select(
      "id, competition_id, entry_id, user_id, created_at"
    )
    .single();


  if (error) {

    if (
      error.code === "23505"
    ) {

      throw new Error(
        "You have already voted in this competition."
      );

    }


    throw error;

  }


  notify(
    COMPETITION_EVENTS.VOTE_UPDATED,
    {
      action: "vote",
      vote: data
    }
  );


  return data;

}


// ============================================================
// REMOVE VOTE
// ============================================================

export async function removeVote(
  entryId
) {

  if (!currentUser) {

    throw new Error(
      "You must be logged in."
    );

  }


  if (!currentCompetition) {

    throw new Error(
      "No competition is currently loaded."
    );

  }


  const {
    error
  } = await supabase
    .from("cosplay_votes")
    .delete()
    .eq(
      "competition_id",
      currentCompetition.id
    )
    .eq(
      "entry_id",
      entryId
    )
    .eq(
      "user_id",
      currentUser.id
    );


  if (error) {
    throw error;
  }


  notify(
    COMPETITION_EVENTS.VOTE_UPDATED,
    {
      action: "remove",
      entryId
    }
  );


  return true;

}


// ============================================================
// GET VOTE COUNTS
// ============================================================

export async function getVoteCounts(
  competitionId = currentCompetition?.id
) {

  if (!competitionId) {

    throw new Error(
      "Competition ID is required."
    );

  }


  const {
    data,
    error
  } = await supabase
    .from("cosplay_votes")
    .select(
      "entry_id"
    )
    .eq(
      "competition_id",
      competitionId
    );


  if (error) {
    throw error;
  }


  const counts = {};


  (data || []).forEach(
    vote => {

      if (
        !vote.entry_id
      ) {

        return;

      }


      counts[vote.entry_id] =
        (
          counts[vote.entry_id] ||
          0
        ) + 1;

    }
  );


  return counts;

}


// ============================================================
// GET LEADERBOARD
// ============================================================

export async function getLeaderboard(
  competitionId = currentCompetition?.id
) {

  const entries =
    await loadEntries(
      competitionId
    );


  const voteCounts =
    await getVoteCounts(
      competitionId
    );


  return entries
    .map(entry => ({

      ...entry,

      votes:
        voteCounts[entry.id] ||
        0

    }))
    .sort(
      (a, b) =>
        b.votes -
        a.votes
    );

}


// ============================================================
// JOIN COMPETITION
// ============================================================

export async function enterCompetition(
  cosplayProfileId
) {

  if (!currentUser) {

    throw new Error(
      "You must be logged in."
    );

  }


  if (!currentCompetition) {

    throw new Error(
      "No competition is currently loaded."
    );

  }


  if (
    currentCompetition.status ===
    "past"
  ) {

    throw new Error(
      "This competition has ended."
    );

  }


  if (
    currentCompetition.status ===
    "cancelled"
  ) {

    throw new Error(
      "This competition has been cancelled."
    );

  }


  if (!cosplayProfileId) {

    throw new Error(
      "Cosplay profile ID is required."
    );

  }


  /*
    Server-side RLS should verify that
    the authenticated user owns this
    cosplay profile.
  */


  const {
    data,
    error
  } = await supabase
    .from("cosplay_entries")
    .insert({
      competition_id:
        currentCompetition.id,

      cosplay_profile_id:
        cosplayProfileId,

      user_id:
        currentUser.id
    })
    .select(`
      id,
      competition_id,
      cosplay_profile_id,
      user_id,
      created_at,
      cosplay_profiles (
        id,
        user_id,
        username,
        character_name,
        avatar_url,
        banner_url
      )
    `)
    .single();


  if (error) {

    if (
      error.code === "23505"
    ) {

      throw new Error(
        "This cosplay profile is already entered."
      );

    }


    throw error;

  }


  currentEntries.push(
    data
  );


  notify(
    COMPETITION_EVENTS.ENTRIES_UPDATED,
    currentEntries
  );


  return data;

}


// ============================================================
// LEAVE COMPETITION
// ============================================================

export async function leaveCompetition(
  entryId
) {

  if (!currentUser) {

    throw new Error(
      "You must be logged in."
    );

  }


  if (!entryId) {

    throw new Error(
      "Entry ID is required."
    );

  }


  const {
    error
  } = await supabase
    .from("cosplay_entries")
    .delete()
    .eq(
      "id",
      entryId
    )
    .eq(
      "user_id",
      currentUser.id
    );


  if (error) {
    throw error;
  }


  currentEntries =
    currentEntries.filter(
      entry =>
        entry.id !==
        entryId
    );


  notify(
    COMPETITION_EVENTS.ENTRIES_UPDATED,
    currentEntries
  );


  return true;

}


// ============================================================
// REALTIME SUBSCRIPTION
// ============================================================

let realtimeChannel = null;


export function subscribeToCompetition(
  competitionId = currentCompetition?.id
) {

  if (!competitionId) {

    throw new Error(
      "Competition ID is required."
    );

  }


  if (realtimeChannel) {

    supabase.removeChannel(
      realtimeChannel
    );

  }


  realtimeChannel =
    supabase
      .channel(
        `cosplay-competition-${competitionId}`
      )

      // Competition changes

      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "cosplay_competitions",
          filter:
            `id=eq.${competitionId}`
        },
        async payload => {

          currentCompetition =
            payload.new ||
            currentCompetition;


          notify(
            COMPETITION_EVENTS.UPDATED,
            payload
          );

        }
      )

      // Entry changes

      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "cosplay_entries",
          filter:
            `competition_id=eq.${competitionId}`
        },
        async payload => {

          try {

            await loadEntries(
              competitionId
            );

          } catch (error) {

            console.error(
              "[REGENESIS Competition] Entry refresh failed:",
              error
            );

          }

        }
      )

      // Vote changes

      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "cosplay_votes",
          filter:
            `competition_id=eq.${competitionId}`
        },
        payload => {

          notify(
            COMPETITION_EVENTS.VOTE_UPDATED,
            payload
          );

        }
      )

      .subscribe(
        status => {

          if (
            status ===
            "SUBSCRIBED"
          ) {

            console.log(
              "[REGENESIS Competition] Realtime connected."
            );

          }

          if (
            status ===
            "CHANNEL_ERROR"
          ) {

            console.error(
              "[REGENESIS Competition] Realtime channel error."
            );

          }

        }
      );


  return realtimeChannel;

}


// ============================================================
// STOP REALTIME
// ============================================================

export async function unsubscribeFromCompetition() {

  if (!realtimeChannel) {
    return;
  }


  try {

    await supabase.removeChannel(
      realtimeChannel
    );

  } catch (error) {

    console.error(
      "[REGENESIS Competition] Failed to remove realtime channel:",
      error
    );

  }


  realtimeChannel =
    null;

}


// ============================================================
// INITIALIZE COMPETITION
// ============================================================

export async function initializeCompetition(
  competitionId =
    getCompetitionId()
) {

  await loadCurrentUser();

  const competition =
    await loadCompetition(
      competitionId
    );

  await loadEntries(
    competition.id
  );

  subscribeToCompetition(
    competition.id
  );


  return {

    competition,

    entries:
      currentEntries,

    user:
      currentUser

  };

}


// ============================================================
// GET CURRENT DATA
// ============================================================

export function getCurrentCompetition() {

  return currentCompetition;

}


export function getCurrentEntries() {

  return [
    ...currentEntries
  ];

}


export function getCurrentUser() {

  return currentUser;

}


// ============================================================
// CLEANUP
// ============================================================

export async function destroyCompetition() {

  await unsubscribeFromCompetition();

  currentCompetition =
    null;

  currentEntries =
    [];

  currentUser =
    null;

}


// ============================================================
// DEFAULT EXPORT
// ============================================================

export default {

  loadCurrentUser,

  getCompetitionId,

  loadCompetition,

  refreshCompetition,

  loadEntries,

  getEntry,

  getUserEntry,

  isVotingOpen,

  canVote,

  getUserVote,

  getUserVotes,

  voteForEntry,

  removeVote,

  getVoteCounts,

  getLeaderboard,

  enterCompetition,

  leaveCompetition,

  subscribeToCompetition,

  unsubscribeFromCompetition,

  initializeCompetition,

  getCurrentCompetition,

  getCurrentEntries,

  getCurrentUser,

  onCompetitionChange,

  destroyCompetition,

  COMPETITION_EVENTS

};