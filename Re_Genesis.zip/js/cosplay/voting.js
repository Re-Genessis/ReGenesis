// js/cosplay/voting.js
// REGENESIS — Cosplay Voting System
// Real Supabase-powered voting

import { supabase } from "../supabase.js";

/* =========================================================
   STATE
========================================================= */

let currentUser = null;
let currentCompetition = null;
let currentEntries = [];
let currentVotes = new Map();
let realtimeChannel = null;

const listeners = new Set();

export const VOTING_EVENTS = {
  LOADING: "voting:loading",
  LOADED: "voting:loaded",
  VOTE_CAST: "voting:vote-cast",
  VOTE_REMOVED: "voting:vote-removed",
  UPDATED: "voting:updated",
  ERROR: "voting:error"
};

/* =========================================================
   EVENTS
========================================================= */

function emit(event, detail = {}) {
  listeners.forEach((callback) => {
    try {
      callback(event, detail);
    } catch (error) {
      console.error(
        "Voting listener error:",
        error
      );
    }
  });

  if (typeof document !== "undefined") {
    document.dispatchEvent(
      new CustomEvent(`regenesis:${event}`, {
        detail
      })
    );
  }
}

export function onVotingChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

/* =========================================================
   CURRENT USER
========================================================= */

export async function getCurrentUser() {
  const {
    data: { user },
    error
  } = await supabase.auth.getUser();

  if (error) {
    console.error(
      "Failed to get current user:",
      error
    );

    return null;
  }

  currentUser = user || null;

  return currentUser;
}

/* =========================================================
   COMPETITION
========================================================= */

export async function getCompetition(
  competitionId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  const { data, error } = await supabase
    .from("cosplay_competitions")
    .select(`
      id,
      title,
      description,
      status,
      starts_at,
      ends_at,
      voting_starts_at,
      voting_ends_at,
      created_at
    `)
    .eq("id", competitionId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  currentCompetition = data || null;

  return currentCompetition;
}

/* =========================================================
   VOTING STATUS
========================================================= */

export function isVotingOpen(
  competition = currentCompetition
) {
  if (!competition) {
    return false;
  }

  if (
    competition.status === "cancelled" ||
    competition.status === "closed"
  ) {
    return false;
  }

  const now = Date.now();

  if (competition.voting_starts_at) {
    const starts = new Date(
      competition.voting_starts_at
    ).getTime();

    if (now < starts) {
      return false;
    }
  }

  if (competition.voting_ends_at) {
    const ends = new Date(
      competition.voting_ends_at
    ).getTime();

    if (now > ends) {
      return false;
    }
  }

  return true;
}

/* =========================================================
   VOTING STATUS TEXT
========================================================= */

export function getVotingStatus(
  competition = currentCompetition
) {
  if (!competition) {
    return "unavailable";
  }

  if (
    competition.status === "cancelled"
  ) {
    return "cancelled";
  }

  const now = Date.now();

  if (
    competition.voting_starts_at &&
    now <
      new Date(
        competition.voting_starts_at
      ).getTime()
  ) {
    return "not-started";
  }

  if (
    competition.voting_ends_at &&
    now >
      new Date(
        competition.voting_ends_at
      ).getTime()
  ) {
    return "ended";
  }

  return "open";
}

/* =========================================================
   LOAD ENTRIES
========================================================= */

export async function loadEntries(
  competitionId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  emit(VOTING_EVENTS.LOADING, {
    competitionId
  });

  const { data, error } = await supabase
    .from("cosplay_entries")
    .select(`
      id,
      competition_id,
      cosplay_profile_id,
      user_id,
      created_at,
      cosplay_profiles (
        id,
        username,
        character_name,
        bio,
        avatar_url,
        banner_url
      )
    `)
    .eq(
      "competition_id",
      competitionId
    )
    .order("created_at", {
      ascending: true
    });

  if (error) {
    emit(VOTING_EVENTS.ERROR, {
      error
    });

    throw error;
  }

  currentEntries = data || [];

  emit(VOTING_EVENTS.LOADED, {
    entries: currentEntries
  });

  return currentEntries;
}

/* =========================================================
   LOAD VOTE COUNTS
========================================================= */

export async function getVoteCounts(
  competitionId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  const { data, error } = await supabase
    .from("cosplay_votes")
    .select("entry_id")
    .eq(
      "competition_id",
      competitionId
    );

  if (error) {
    throw error;
  }

  const counts = new Map();

  for (const vote of data || []) {
    const entryId = vote.entry_id;

    counts.set(
      entryId,
      (counts.get(entryId) || 0) + 1
    );
  }

  currentVotes = counts;

  return counts;
}

/* =========================================================
   GET SINGLE VOTE COUNT
========================================================= */

export async function getVoteCount(
  entryId,
  competitionId = null
) {
  if (!entryId) {
    return 0;
  }

  let query = supabase
    .from("cosplay_votes")
    .select("id", {
      count: "exact",
      head: true
    })
    .eq("entry_id", entryId);

  if (competitionId) {
    query = query.eq(
      "competition_id",
      competitionId
    );
  }

  const {
    count,
    error
  } = await query;

  if (error) {
    throw error;
  }

  return Number(count || 0);
}

/* =========================================================
   GET USER'S VOTE
========================================================= */

export async function getMyVote(
  competitionId
) {
  const user = currentUser ||
    await getCurrentUser();

  if (!user || !competitionId) {
    return null;
  }

  const { data, error } = await supabase
    .from("cosplay_votes")
    .select(`
      id,
      competition_id,
      entry_id,
      user_id,
      created_at
    `)
    .eq(
      "competition_id",
      competitionId
    )
    .eq(
      "user_id",
      user.id
    )
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data || null;
}

/* =========================================================
   HAS USER VOTED
========================================================= */

export async function hasVoted(
  competitionId
) {
  const vote = await getMyVote(
    competitionId
  );

  return Boolean(vote);
}

/* =========================================================
   CAN VOTE
========================================================= */

export async function canVote(
  competitionId = null
) {
  const competition =
    competitionId
      ? await getCompetition(
          competitionId
        )
      : currentCompetition;

  if (!competition) {
    return {
      allowed: false,
      reason: "competition-not-found"
    };
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    return {
      allowed: false,
      reason: "login-required"
    };
  }

  if (!isVotingOpen(competition)) {
    return {
      allowed: false,
      reason: getVotingStatus(
        competition
      )
    };
  }

  const vote = await getMyVote(
    competition.id
  );

  if (vote) {
    return {
      allowed: false,
      reason: "already-voted",
      vote
    };
  }

  return {
    allowed: true,
    reason: null
  };
}

/* =========================================================
   CAST VOTE
========================================================= */

export async function vote(
  competitionId,
  entryId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  if (!entryId) {
    throw new Error(
      "Entry ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to vote."
    );
  }

  const competition =
    currentCompetition?.id ===
    competitionId
      ? currentCompetition
      : await getCompetition(
          competitionId
        );

  if (!isVotingOpen(competition)) {
    throw new Error(
      "Voting is currently closed."
    );
  }

  /*
    Verify that the entry actually belongs
    to this competition.
  */

  const { data: entry, error: entryError } =
    await supabase
      .from("cosplay_entries")
      .select(`
        id,
        competition_id
      `)
      .eq("id", entryId)
      .eq(
        "competition_id",
        competitionId
      )
      .maybeSingle();

  if (entryError) {
    throw entryError;
  }

  if (!entry) {
    throw new Error(
      "This competition entry does not exist."
    );
  }

  /*
    Check existing vote before inserting.
  */

  const existingVote =
    await getMyVote(
      competitionId
    );

  if (existingVote) {
    throw new Error(
      "You have already voted in this competition."
    );
  }

  const { data, error } = await supabase
    .from("cosplay_votes")
    .insert({
      competition_id: competitionId,
      entry_id: entryId,
      user_id: user.id
    })
    .select(`
      id,
      competition_id,
      entry_id,
      user_id,
      created_at
    `)
    .single();

  if (error) {
    /*
      PostgreSQL unique constraint errors
      should also be treated as "already voted".
    */

    if (
      error.code === "23505"
    ) {
      throw new Error(
        "You have already voted in this competition."
      );
    }

    throw error;
  }

  emit(VOTING_EVENTS.VOTE_CAST, {
    vote: data,
    entryId,
    competitionId
  });

  await getVoteCounts(
    competitionId
  );

  emit(VOTING_EVENTS.UPDATED, {
    competitionId
  });

  return data;
}

/* =========================================================
   REMOVE VOTE
========================================================= */

export async function removeVote(
  competitionId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const existingVote =
    await getMyVote(
      competitionId
    );

  if (!existingVote) {
    return {
      success: false,
      message: "No vote found."
    };
  }

  /*
    Whether users are allowed to remove their
    vote should ALSO be enforced by RLS.
  */

  const { error } = await supabase
    .from("cosplay_votes")
    .delete()
    .eq(
      "id",
      existingVote.id
    )
    .eq(
      "user_id",
      user.id
    );

  if (error) {
    throw error;
  }

  emit(VOTING_EVENTS.VOTE_REMOVED, {
    vote: existingVote,
    competitionId
  });

  await getVoteCounts(
    competitionId
  );

  emit(VOTING_EVENTS.UPDATED, {
    competitionId
  });

  return {
    success: true
  };
}

/* =========================================================
   LEADERBOARD
========================================================= */

export async function getLeaderboard(
  competitionId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  const entries =
    currentEntries.length &&
    currentEntries[0]?.competition_id ===
      competitionId
      ? currentEntries
      : await loadEntries(
          competitionId
        );

  const counts =
    await getVoteCounts(
      competitionId
    );

  const leaderboard =
    entries.map((entry) => ({
      ...entry,

      vote_count:
        counts.get(entry.id) || 0
    }));

  leaderboard.sort(
    (a, b) =>
      b.vote_count -
      a.vote_count
  );

  return leaderboard.map(
    (entry, index) => ({
      ...entry,
      rank: index + 1
    })
  );
}

/* =========================================================
   GET ENTRY RANK
========================================================= */

export async function getEntryRank(
  competitionId,
  entryId
) {
  const leaderboard =
    await getLeaderboard(
      competitionId
    );

  const position =
    leaderboard.findIndex(
      (entry) =>
        entry.id === entryId
    );

  if (position === -1) {
    return null;
  }

  return {
    rank: position + 1,
    entry:
      leaderboard[position]
  };
}

/* =========================================================
   INITIALIZE VOTING
========================================================= */

export async function initializeVoting(
  competitionId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  await getCurrentUser();

  await getCompetition(
    competitionId
  );

  await loadEntries(
    competitionId
  );

  await getVoteCounts(
    competitionId
  );

  subscribeToVoting(
    competitionId
  );

  return {
    competition:
      currentCompetition,

    entries:
      currentEntries,

    voteCounts:
      currentVotes,

    votingOpen:
      isVotingOpen(
        currentCompetition
      )
  };
}

/* =========================================================
   REALTIME VOTING
========================================================= */

export function subscribeToVoting(
  competitionId
) {
  if (!competitionId) {
    return null;
  }

  if (realtimeChannel) {
    supabase.removeChannel(
      realtimeChannel
    );

    realtimeChannel = null;
  }

  realtimeChannel = supabase
    .channel(
      `cosplay-voting-${competitionId}`
    )
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "cosplay_votes",
        filter:
          `competition_id=eq.${competitionId}`
      },
      async () => {
        try {
          await getVoteCounts(
            competitionId
          );

          emit(
            VOTING_EVENTS.UPDATED,
            {
              competitionId
            }
          );
        } catch (error) {
          console.error(
            "Failed to refresh vote counts:",
            error
          );
        }
      }
    )
    .subscribe((status) => {
      console.log(
        "Cosplay voting realtime:",
        status
      );
    });

  return realtimeChannel;
}

/* =========================================================
   UNSUBSCRIBE
========================================================= */

export async function unsubscribeFromVoting() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "Failed to remove voting channel:",
      error
    );
  }

  realtimeChannel = null;
}

/* =========================================================
   REFRESH
========================================================= */

export async function refreshVoting(
  competitionId
) {
  if (!competitionId) {
    throw new Error(
      "Competition ID is required."
    );
  }

  await getCompetition(
    competitionId
  );

  await loadEntries(
    competitionId
  );

  await getVoteCounts(
    competitionId
  );

  return {
    competition:
      currentCompetition,

    entries:
      currentEntries,

    voteCounts:
      currentVotes
  };
}

/* =========================================================
   STATE GETTERS
========================================================= */

export function getCurrentCompetition() {
  return currentCompetition;
}

export function getCurrentEntries() {
  return [...currentEntries];
}

export function getCurrentVoteCounts() {
  return new Map(currentVotes);
}

export function getVoteCountFromState(
  entryId
) {
  return currentVotes.get(
    entryId
  ) || 0;
}

export function getCurrentUser() {
  return currentUser;
}

/* =========================================================
   CLEANUP
========================================================= */

export async function destroyVoting() {
  await unsubscribeFromVoting();

  currentUser = null;
  currentCompetition = null;
  currentEntries = [];
  currentVotes.clear();

  listeners.clear();
}

/* =========================================================
   DEFAULT EXPORT
========================================================= */

export default {
  VOTING_EVENTS,

  onVotingChange,

  getCurrentUser,
  getCompetition,

  isVotingOpen,
  getVotingStatus,

  loadEntries,
  getVoteCounts,
  getVoteCount,

  getMyVote,
  hasVoted,
  canVote,

  vote,
  removeVote,

  getLeaderboard,
  getEntryRank,

  initializeVoting,
  refreshVoting,

  subscribeToVoting,
  unsubscribeFromVoting,

  getCurrentCompetition,
  getCurrentEntries,
  getCurrentVoteCounts,
  getVoteCountFromState,

  destroyVoting
};