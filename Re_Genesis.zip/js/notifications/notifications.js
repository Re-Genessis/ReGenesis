// ============================================================
// REGENESIS — Notifications Module
// File: js/notifications/notifications.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 30;
const MAX_LIMIT = 100;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let notifications = [];

let loading = false;
let realtimeChannel = null;

const listeners = new Set();

const EVENTS = {
    LOADING: "loading",
    LOADED: "loaded",
    CREATED: "created",
    READ: "read",
    UNREAD: "unread",
    DELETED: "deleted",
    ALL_READ: "all_read",
    ALL_DELETED: "all_deleted",
    UPDATED: "updated",
    CHANGED: "changed",
    ERROR: "error"
};

// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onNotificationsChange(callback) {
    if (typeof callback !== "function") {
        throw new TypeError("callback must be a function");
    }

    listeners.add(callback);

    return () => {
        listeners.delete(callback);
    };
}

function emit(event, data = null) {
    listeners.forEach(callback => {
        try {
            callback({
                event,
                data
            });
        } catch (error) {
            console.error(
                "Notification listener error:",
                error
            );
        }
    });
}

// ------------------------------------------------------------
// Current user
// ------------------------------------------------------------

export async function getCurrentUser() {
    const {
        data,
        error
    } = await supabase.auth.getUser();

    if (error) {
        currentUser = null;
        return null;
    }

    currentUser = data?.user || null;

    return currentUser;
}

// ------------------------------------------------------------
// Authentication helper
// ------------------------------------------------------------

async function requireUser() {
    const user =
        currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in to view notifications."
        );
    }

    return user;
}

// ------------------------------------------------------------
// Load notifications
// ------------------------------------------------------------

export async function loadNotifications({
    unreadOnly = false,
    type = "",
    limit = DEFAULT_LIMIT,
    offset = 0
} = {}) {

    const user = await requireUser();

    loading = true;
    emit(EVENTS.LOADING, true);

    try {

        const safeLimit = Math.min(
            Math.max(
                Number(limit) || DEFAULT_LIMIT,
                1
            ),
            MAX_LIMIT
        );

        const safeOffset = Math.max(
            Number(offset) || 0,
            0
        );

        let query = supabase
            .from("notifications")
            .select(`
                id,
                user_id,
                actor_id,
                type,
                title,
                message,
                link,
                entity_type,
                entity_id,
                is_read,
                created_at,
                read_at,
                actor:profiles!notifications_actor_id_fkey (
                    id,
                    username,
                    avatar_url
                )
            `, {
                count: "exact"
            })
            .eq(
                "user_id",
                user.id
            )
            .order("created_at", {
                ascending: false
            })
            .range(
                safeOffset,
                safeOffset + safeLimit - 1
            );

        if (unreadOnly) {
            query = query.eq(
                "is_read",
                false
            );
        }

        if (type.trim()) {
            query = query.eq(
                "type",
                type.trim()
            );
        }

        const {
            data,
            error,
            count
        } = await query;

        if (error) {
            throw error;
        }

        notifications = data || [];

        emit(EVENTS.LOADED, {
            notifications,
            count: count || 0,
            unreadOnly,
            type,
            limit: safeLimit,
            offset: safeOffset
        });

        return {
            notifications,
            count: count || 0,
            unreadOnly,
            type,
            limit: safeLimit,
            offset: safeOffset
        };

    } catch (error) {

        console.error(
            "Failed to load notifications:",
            error
        );

        emit(EVENTS.ERROR, error);

        throw error;

    } finally {

        loading = false;

        emit(
            EVENTS.LOADING,
            false
        );
    }
}

// ------------------------------------------------------------
// Get one notification
// ------------------------------------------------------------

export async function getNotification(
    notificationId
) {

    const user = await requireUser();

    if (!notificationId) {
        throw new Error(
            "Notification ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("notifications")
        .select(`
            id,
            user_id,
            actor_id,
            type,
            title,
            message,
            link,
            entity_type,
            entity_id,
            is_read,
            created_at,
            read_at,
            actor:profiles!notifications_actor_id_fkey (
                id,
                username,
                avatar_url
            )
        `)
        .eq(
            "id",
            notificationId
        )
        .eq(
            "user_id",
            user.id
        )
        .maybeSingle();

    if (error) {
        throw error;
    }

    return data || null;
}

// ------------------------------------------------------------
// Get unread count
// ------------------------------------------------------------

export async function getUnreadCount() {

    const user = await requireUser();

    const {
        count,
        error
    } = await supabase
        .from("notifications")
        .select("id", {
            count: "exact",
            head: true
        })
        .eq(
            "user_id",
            user.id
        )
        .eq(
            "is_read",
            false
        );

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    return count || 0;
}

// ------------------------------------------------------------
// Get total notification count
// ------------------------------------------------------------

export async function getNotificationCount() {

    const user = await requireUser();

    const {
        count,
        error
    } = await supabase
        .from("notifications")
        .select("id", {
            count: "exact",
            head: true
        })
        .eq(
            "user_id",
            user.id
        );

    if (error) {
        throw error;
    }

    return count || 0;
}

// ------------------------------------------------------------
// Mark notification as read
// ------------------------------------------------------------

export async function markAsRead(
    notificationId
) {

    const user = await requireUser();

    if (!notificationId) {
        throw new Error(
            "Notification ID is required."
        );
    }

    const readAt =
        new Date().toISOString();

    const {
        data,
        error
    } = await supabase
        .from("notifications")
        .update({
            is_read: true,
            read_at: readAt
        })
        .eq(
            "id",
            notificationId
        )
        .eq(
            "user_id",
            user.id
        )
        .select(`
            id,
            user_id,
            is_read,
            read_at
        `)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    if (!data) {
        throw new Error(
            "Notification not found."
        );
    }

    updateCachedNotification(data);

    emit(
        EVENTS.READ,
        data
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "read",
            notification: data
        }
    );

    return data;
}

// ------------------------------------------------------------
// Mark notification as unread
// ------------------------------------------------------------

export async function markAsUnread(
    notificationId
) {

    const user = await requireUser();

    if (!notificationId) {
        throw new Error(
            "Notification ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("notifications")
        .update({
            is_read: false,
            read_at: null
        })
        .eq(
            "id",
            notificationId
        )
        .eq(
            "user_id",
            user.id
        )
        .select(`
            id,
            user_id,
            is_read,
            read_at
        `)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    if (!data) {
        throw new Error(
            "Notification not found."
        );
    }

    updateCachedNotification(data);

    emit(
        EVENTS.UNREAD,
        data
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "unread",
            notification: data
        }
    );

    return data;
}

// ------------------------------------------------------------
// Mark all notifications as read
// ------------------------------------------------------------

export async function markAllAsRead() {

    const user = await requireUser();

    const readAt =
        new Date().toISOString();

    const {
        data,
        error
    } = await supabase
        .from("notifications")
        .update({
            is_read: true,
            read_at: readAt
        })
        .eq(
            "user_id",
            user.id
        )
        .eq(
            "is_read",
            false
        )
        .select(`
            id,
            user_id,
            is_read,
            read_at
        `);

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    notifications =
        notifications.map(notification => ({
            ...notification,
            is_read: true,
            read_at: readAt
        }));

    emit(
        EVENTS.ALL_READ,
        data || []
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "all_read"
        }
    );

    return data || [];
}

// ------------------------------------------------------------
// Delete notification
// ------------------------------------------------------------

export async function deleteNotification(
    notificationId
) {

    const user = await requireUser();

    if (!notificationId) {
        throw new Error(
            "Notification ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("notifications")
        .delete()
        .eq(
            "id",
            notificationId
        )
        .eq(
            "user_id",
            user.id
        )
        .select("id")
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    if (!data) {
        throw new Error(
            "Notification not found."
        );
    }

    notifications =
        notifications.filter(
            notification =>
                notification.id !==
                notificationId
        );

    emit(
        EVENTS.DELETED,
        data
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "delete",
            id: notificationId
        }
    );

    return true;
}

// ------------------------------------------------------------
// Delete all notifications
// ------------------------------------------------------------

export async function deleteAllNotifications() {

    const user = await requireUser();

    const {
        error
    } = await supabase
        .from("notifications")
        .delete()
        .eq(
            "user_id",
            user.id
        );

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    notifications = [];

    emit(
        EVENTS.ALL_DELETED
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "all_deleted"
        }
    );

    return true;
}

// ------------------------------------------------------------
// Delete read notifications only
// ------------------------------------------------------------

export async function deleteReadNotifications() {

    const user = await requireUser();

    const {
        error
    } = await supabase
        .from("notifications")
        .delete()
        .eq(
            "user_id",
            user.id
        )
        .eq(
            "is_read",
            true
        );

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    notifications =
        notifications.filter(
            notification =>
                !notification.is_read
        );

    emit(
        EVENTS.DELETED,
        {
            type: "read_notifications"
        }
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "read_notifications_deleted"
        }
    );

    return true;
}

// ------------------------------------------------------------
// Get notifications by type
// ------------------------------------------------------------

export async function getNotificationsByType(
    type,
    options = {}
) {

    if (!type) {
        throw new Error(
            "Notification type is required."
        );
    }

    return await loadNotifications({
        ...options,
        type
    });
}

// ------------------------------------------------------------
// Get cached notification
// ------------------------------------------------------------

export function getCachedNotification(
    notificationId
) {

    return (
        notifications.find(
            notification =>
                notification.id ===
                notificationId
        ) || null
    );
}

// ------------------------------------------------------------
// Update cached notification
// ------------------------------------------------------------

function updateCachedNotification(
    updated
) {

    if (!updated?.id) {
        return;
    }

    const index =
        notifications.findIndex(
            notification =>
                notification.id ===
                updated.id
        );

    if (index === -1) {
        return;
    }

    notifications[index] = {
        ...notifications[index],
        ...updated
    };
}

// ------------------------------------------------------------
// Add notification to cache
// ------------------------------------------------------------

function addCachedNotification(
    notification
) {

    if (!notification?.id) {
        return;
    }

    const exists =
        notifications.some(
            item =>
                item.id ===
                notification.id
        );

    if (exists) {
        updateCachedNotification(
            notification
        );

        return;
    }

    notifications = [
        notification,
        ...notifications
    ];
}

// ------------------------------------------------------------
// Remove from cache
// ------------------------------------------------------------

function removeCachedNotification(
    notificationId
) {

    notifications =
        notifications.filter(
            notification =>
                notification.id !==
                notificationId
        );
}

// ------------------------------------------------------------
// Subscribe to realtime notifications
// ------------------------------------------------------------

export async function subscribeToNotifications() {

    const user = await requireUser();

    await unsubscribeFromNotifications();

    /*
     * The filter makes this subscription specific
     * to the logged-in user's notifications.
     *
     * RLS MUST still protect the table.
     */

    realtimeChannel = supabase
        .channel(
            `regenesis-notifications-${user.id}`
        )

        .on(
            "postgres_changes",
            {
                event: "INSERT",
                schema: "public",
                table: "notifications",
                filter:
                    `user_id=eq.${user.id}`
            },
            async payload => {

                let notification =
                    payload.new;

                /*
                 * Realtime payloads don't include
                 * joined profile data, so fetch
                 * the complete notification.
                 */

                try {

                    const full =
                        await getNotification(
                            payload.new.id
                        );

                    if (full) {
                        notification = full;
                    }

                } catch (error) {

                    console.warn(
                        "Could not load notification details:",
                        error
                    );
                }

                addCachedNotification(
                    notification
                );

                emit(
                    EVENTS.CREATED,
                    notification
                );

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "insert",
                        notification
                    }
                );
            }
        )

        .on(
            "postgres_changes",
            {
                event: "UPDATE",
                schema: "public",
                table: "notifications",
                filter:
                    `user_id=eq.${user.id}`
            },
            async payload => {

                let notification =
                    payload.new;

                try {

                    const full =
                        await getNotification(
                            payload.new.id
                        );

                    if (full) {
                        notification = full;
                    }

                } catch (error) {

                    console.warn(
                        "Could not refresh notification:",
                        error
                    );
                }

                updateCachedNotification(
                    notification
                );

                emit(
                    EVENTS.UPDATED,
                    notification
                );

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "update",
                        notification
                    }
                );
            }
        )

        .on(
            "postgres_changes",
            {
                event: "DELETE",
                schema: "public",
                table: "notifications"
            },
            payload => {

                const deletedId =
                    payload.old?.id;

                if (deletedId) {
                    removeCachedNotification(
                        deletedId
                    );
                }

                emit(
                    EVENTS.DELETED,
                    {
                        id: deletedId,
                        payload
                    }
                );

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "delete",
                        id: deletedId,
                        payload
                    }
                );
            }
        )

        .subscribe(status => {

            if (status === "SUBSCRIBED") {

                console.log(
                    "REGENESIS notifications realtime connected."
                );
            }

            if (status === "CHANNEL_ERROR") {

                console.error(
                    "REGENESIS notifications realtime error."
                );

                emit(
                    EVENTS.ERROR,
                    new Error(
                        "Notification realtime channel error."
                    )
                );
            }

            if (status === "TIMED_OUT") {

                console.warn(
                    "REGENESIS notification realtime timed out."
                );
            }
        });

    return realtimeChannel;
}

// ------------------------------------------------------------
// Unsubscribe
// ------------------------------------------------------------

export async function unsubscribeFromNotifications() {

    if (!realtimeChannel) {
        return;
    }

    await supabase.removeChannel(
        realtimeChannel
    );

    realtimeChannel = null;
}

// ------------------------------------------------------------
// Refresh notifications
// ------------------------------------------------------------

export async function refreshNotifications(
    options = {}
) {

    return await loadNotifications(
        options
    );
}

// ------------------------------------------------------------
// Initialize notification system
// ------------------------------------------------------------

export async function initializeNotifications(
    options = {}
) {

    await getCurrentUser();

    const result =
        await loadNotifications(
            options
        );

    await subscribeToNotifications();

    return result;
}

// ------------------------------------------------------------
// Clear local cache
// ------------------------------------------------------------

export function clearNotifications() {

    notifications = [];

    emit(
        EVENTS.CHANGED,
        {
            type: "cleared"
        }
    );
}

// ------------------------------------------------------------
// State getters
// ------------------------------------------------------------

export function getNotifications() {
    return [...notifications];
}

export function getCachedUser() {
    return currentUser;
}

export function isNotificationsLoading() {
    return loading;
}

export function getRealtimeChannel() {
    return realtimeChannel;
}

// ------------------------------------------------------------
// Destroy module
// ------------------------------------------------------------

export async function destroyNotifications() {

    await unsubscribeFromNotifications();

    listeners.clear();

    currentUser = null;
    notifications = [];

    loading = false;
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {

    EVENTS,

    onNotificationsChange,

    getCurrentUser,

    loadNotifications,
    refreshNotifications,

    getNotification,

    getUnreadCount,
    getNotificationCount,

    markAsRead,
    markAsUnread,
    markAllAsRead,

    deleteNotification,
    deleteAllNotifications,
    deleteReadNotifications,

    getNotificationsByType,

    getCachedNotification,

    subscribeToNotifications,
    unsubscribeFromNotifications,

    initializeNotifications,
    clearNotifications,

    getNotifications,
    getCachedUser,

    isNotificationsLoading,
    getRealtimeChannel,

    destroyNotifications
};