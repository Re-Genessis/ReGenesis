// ============================================================
// REGENESIS
// js/profile/edit-profile.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const AVATAR_BUCKET = "avatars";

const MAX_AVATAR_SIZE = 5 * 1024 * 1024; // 5 MB

const ALLOWED_AVATAR_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp"
];

const MIN_USERNAME_LENGTH = 3;
const MAX_USERNAME_LENGTH = 30;

const MIN_BIO_LENGTH = 0;
const MAX_BIO_LENGTH = 300;


// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let currentProfile = null;
let loading = false;
let saving = false;
let avatarUploading = false;

const listeners = new Set();


// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const EDIT_PROFILE_EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",
  SAVING: "saving",
  SAVED: "saved",
  AVATAR_UPLOADED: "avatar_uploaded",
  ERROR: "error",
  CHANGED: "changed"
};


// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onEditProfileChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(event, data = null) {
  listeners.forEach((callback) => {
    try {
      callback({
        event,
        data,
        state: getState()
      });
    } catch (error) {
      console.error("REGENESIS edit-profile listener error:", error);
    }
  });
}


// ------------------------------------------------------------
// Helpers
// ------------------------------------------------------------

function getErrorMessage(error) {
  if (!error) return "Something went wrong.";

  return (
    error.message ||
    error.error_description ||
    error.details ||
    error.hint ||
    "Something went wrong."
  );
}

function normalizeUsername(username) {
  return String(username || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "");
}

function normalizeText(value) {
  return String(value || "").trim();
}


// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const {
    data,
    error
  } = await supabase.auth.getUser();

  if (error) {
    throw error;
  }

  currentUser = data?.user || null;

  return currentUser;
}

export function getCachedUser() {
  return currentUser;
}


// ------------------------------------------------------------
// Profile loading
// ------------------------------------------------------------

export async function loadProfile() {
  loading = true;
  emit(EDIT_PROFILE_EVENTS.LOADING);

  try {
    const user = await getCurrentUser();

    if (!user) {
      throw new Error("You must be logged in to edit your profile.");
    }

    const {
      data,
      error
    } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .maybeSingle();

    if (error) {
      throw error;
    }

    if (!data) {
      throw new Error(
        "Your profile could not be found. Please complete your registration first."
      );
    }

    currentProfile = data;

    emit(EDIT_PROFILE_EVENTS.LOADED, data);

    return data;

  } catch (error) {
    emit(EDIT_PROFILE_EVENTS.ERROR, error);
    throw error;

  } finally {
    loading = false;
  }
}

export function getCurrentProfile() {
  return currentProfile;
}


// ------------------------------------------------------------
// Username validation
// ------------------------------------------------------------

export function validateUsername(username) {
  const value = normalizeUsername(username);

  if (!value) {
    return {
      valid: false,
      message: "Username is required."
    };
  }

  if (
    value.length < MIN_USERNAME_LENGTH ||
    value.length > MAX_USERNAME_LENGTH
  ) {
    return {
      valid: false,
      message: `Username must be ${MIN_USERNAME_LENGTH}-${MAX_USERNAME_LENGTH} characters.`
    };
  }

  if (!/^[a-z0-9_.]+$/.test(value)) {
    return {
      valid: false,
      message:
        "Username can only contain lowercase letters, numbers, underscores and dots."
    };
  }

  if (value.startsWith(".") || value.endsWith(".")) {
    return {
      valid: false,
      message: "Username cannot start or end with a dot."
    };
  }

  if (value.includes("..")) {
    return {
      valid: false,
      message: "Username cannot contain consecutive dots."
    };
  }

  return {
    valid: true,
    value
  };
}


// ------------------------------------------------------------
// Check username availability
// ------------------------------------------------------------

export async function isUsernameAvailable(username, userId = null) {
  const validation = validateUsername(username);

  if (!validation.valid) {
    return false;
  }

  const normalized = validation.value;

  let query = supabase
    .from("profiles")
    .select("id")
    .eq("username", normalized)
    .limit(1);

  const {
    data,
    error
  } = await query;

  if (error) {
    throw error;
  }

  if (!data || data.length === 0) {
    return true;
  }

  // Username belongs to the current user.
  if (userId && data[0].id === userId) {
    return true;
  }

  return false;
}


// ------------------------------------------------------------
// Validate bio
// ------------------------------------------------------------

export function validateBio(bio) {
  const value = normalizeText(bio);

  if (value.length < MIN_BIO_LENGTH) {
    return {
      valid: false,
      message: "Invalid bio."
    };
  }

  if (value.length > MAX_BIO_LENGTH) {
    return {
      valid: false,
      message: `Bio cannot be longer than ${MAX_BIO_LENGTH} characters.`
    };
  }

  return {
    valid: true,
    value
  };
}


// ------------------------------------------------------------
// Validate avatar
// ------------------------------------------------------------

export function validateAvatarFile(file) {
  if (!file) {
    return {
      valid: false,
      message: "No image selected."
    };
  }

  if (!ALLOWED_AVATAR_TYPES.includes(file.type)) {
    return {
      valid: false,
      message: "Avatar must be JPG, PNG, or WEBP."
    };
  }

  if (file.size > MAX_AVATAR_SIZE) {
    return {
      valid: false,
      message: "Avatar must be smaller than 5 MB."
    };
  }

  return {
    valid: true
  };
}


// ------------------------------------------------------------
// Upload avatar
// ------------------------------------------------------------

export async function uploadAvatar(file) {
  if (avatarUploading) {
    throw new Error("An avatar upload is already in progress.");
  }

  const user = currentUser || await getCurrentUser();

  if (!user) {
    throw new Error("You must be logged in.");
  }

  const validation = validateAvatarFile(file);

  if (!validation.valid) {
    throw new Error(validation.message);
  }

  avatarUploading = true;

  try {
    const extension = getExtension(file.name);

    const fileName =
      `${Date.now()}-${crypto.randomUUID()}.${extension}`;

    const filePath = `${user.id}/${fileName}`;

    const {
      data,
      error
    } = await supabase
      .storage
      .from(AVATAR_BUCKET)
      .upload(filePath, file, {
        cacheControl: "3600",
        contentType: file.type,
        upsert: false
      });

    if (error) {
      throw error;
    }

    const {
      data: publicData
    } = supabase
      .storage
      .from(AVATAR_BUCKET)
      .getPublicUrl(data.path);

    const avatarUrl = publicData?.publicUrl || null;

    if (!avatarUrl) {
      throw new Error("Could not generate the avatar URL.");
    }

    emit(
      EDIT_PROFILE_EVENTS.AVATAR_UPLOADED,
      {
        path: data.path,
        url: avatarUrl
      }
    );

    return {
      path: data.path,
      url: avatarUrl
    };

  } catch (error) {
    emit(EDIT_PROFILE_EVENTS.ERROR, error);
    throw error;

  } finally {
    avatarUploading = false;
  }
}


// ------------------------------------------------------------
// Delete avatar file
// ------------------------------------------------------------

export async function deleteAvatarFile(filePath) {
  if (!filePath) {
    return true;
  }

  const {
    error
  } = await supabase
    .storage
    .from(AVATAR_BUCKET)
    .remove([filePath]);

  if (error) {
    throw error;
  }

  return true;
}


// ------------------------------------------------------------
// Extract storage path from avatar URL
// ------------------------------------------------------------

export function getAvatarStoragePath(url) {
  if (!url) return null;

  try {
    const parsed = new URL(url);

    const marker = `/storage/v1/object/public/${AVATAR_BUCKET}/`;

    const index = parsed.pathname.indexOf(marker);

    if (index === -1) {
      return null;
    }

    return decodeURIComponent(
      parsed.pathname.substring(index + marker.length)
    );

  } catch {
    return null;
  }
}


// ------------------------------------------------------------
// Update profile
// ------------------------------------------------------------

export async function updateProfile({
  username,
  displayName,
  bio,
  avatarUrl
} = {}) {
  if (saving) {
    throw new Error("A profile update is already in progress.");
  }

  const user = currentUser || await getCurrentUser();

  if (!user) {
    throw new Error("You must be logged in.");
  }

  saving = true;

  emit(EDIT_PROFILE_EVENTS.SAVING);

  try {
    const normalizedUsername = normalizeUsername(
      username ?? currentProfile?.username
    );

    const usernameValidation =
      validateUsername(normalizedUsername);

    if (!usernameValidation.valid) {
      throw new Error(usernameValidation.message);
    }

    const bioValidation =
      validateBio(bio ?? currentProfile?.bio ?? "");

    if (!bioValidation.valid) {
      throw new Error(bioValidation.message);
    }

    const usernameAvailable =
      await isUsernameAvailable(
        normalizedUsername,
        user.id
      );

    if (!usernameAvailable) {
      throw new Error("That username is already taken.");
    }

    const updates = {
      username: normalizedUsername,
      display_name: normalizeText(
        displayName ?? currentProfile?.display_name ?? ""
      ) || null,
      bio: bioValidation.value || null
    };

    if (avatarUrl !== undefined) {
      updates.avatar_url = avatarUrl || null;
    }

    const {
      data,
      error
    } = await supabase
      .from("profiles")
      .update(updates)
      .eq("id", user.id)
      .select("*")
      .single();

    if (error) {
      throw error;
    }

    currentProfile = data;

    emit(EDIT_PROFILE_EVENTS.SAVED, data);
    emit(EDIT_PROFILE_EVENTS.CHANGED, data);

    return data;

  } catch (error) {
    emit(EDIT_PROFILE_EVENTS.ERROR, error);
    throw error;

  } finally {
    saving = false;
  }
}


// ------------------------------------------------------------
// Update only username
// ------------------------------------------------------------

export async function updateUsername(username) {
  const profile = currentProfile || await loadProfile();

  return updateProfile({
    username,
    displayName: profile.display_name,
    bio: profile.bio,
    avatarUrl: profile.avatar_url
  });
}


// ------------------------------------------------------------
// Update only bio
// ------------------------------------------------------------

export async function updateBio(bio) {
  const profile = currentProfile || await loadProfile();

  return updateProfile({
    username: profile.username,
    displayName: profile.display_name,
    bio,
    avatarUrl: profile.avatar_url
  });
}


// ------------------------------------------------------------
// Update only display name
// ------------------------------------------------------------

export async function updateDisplayName(displayName) {
  const profile = currentProfile || await loadProfile();

  return updateProfile({
    username: profile.username,
    displayName,
    bio: profile.bio,
    avatarUrl: profile.avatar_url
  });
}


// ------------------------------------------------------------
// Upload avatar + save profile
// ------------------------------------------------------------

export async function updateAvatar(file) {
  const profile = currentProfile || await loadProfile();

  const oldAvatarUrl = profile.avatar_url;

  const uploaded = await uploadAvatar(file);

  try {
    const updatedProfile = await updateProfile({
      username: profile.username,
      displayName: profile.display_name,
      bio: profile.bio,
      avatarUrl: uploaded.url
    });

    // Remove old avatar only after the database update succeeds.
    const oldPath = getAvatarStoragePath(oldAvatarUrl);

    if (
      oldPath &&
      oldPath !== uploaded.path
    ) {
      try {
        await deleteAvatarFile(oldPath);
      } catch (deleteError) {
        console.warn(
          "Old avatar could not be removed:",
          deleteError
        );
      }
    }

    return updatedProfile;

  } catch (error) {
    // If database update fails, remove the newly uploaded file.
    try {
      await deleteAvatarFile(uploaded.path);
    } catch (cleanupError) {
      console.warn(
        "New avatar cleanup failed:",
        cleanupError
      );
    }

    throw error;
  }
}


// ------------------------------------------------------------
// Remove current avatar
// ------------------------------------------------------------

export async function removeAvatar() {
  const profile = currentProfile || await loadProfile();

  if (!profile.avatar_url) {
    return profile;
  }

  const oldPath =
    getAvatarStoragePath(profile.avatar_url);

  const updatedProfile = await updateProfile({
    username: profile.username,
    displayName: profile.display_name,
    bio: profile.bio,
    avatarUrl: null
  });

  if (oldPath) {
    try {
      await deleteAvatarFile(oldPath);
    } catch (error) {
      console.warn(
        "Avatar was removed from the profile, but the storage file could not be deleted:",
        error
      );
    }
  }

  return updatedProfile;
}


// ------------------------------------------------------------
// Update Supabase Auth metadata
// ------------------------------------------------------------

export async function updateAuthMetadata(metadata = {}) {
  const user = currentUser || await getCurrentUser();

  if (!user) {
    throw new Error("You must be logged in.");
  }

  const {
    data,
    error
  } = await supabase.auth.updateUser({
    data: metadata
  });

  if (error) {
    throw error;
  }

  currentUser = data?.user || currentUser;

  return currentUser;
}


// ------------------------------------------------------------
// Get profile URL
// ------------------------------------------------------------

export function getProfileURL(username) {
  if (!username) {
    return "../pages/profile.html";
  }

  return `../pages/profile.html?username=${encodeURIComponent(username)}`;
}


// ------------------------------------------------------------
// Get extension
// ------------------------------------------------------------

function getExtension(fileName) {
  const name = String(fileName || "");

  const parts = name.split(".");

  if (parts.length < 2) {
    return "jpg";
  }

  const extension = parts.pop().toLowerCase();

  if (extension === "jpeg") {
    return "jpg";
  }

  if (!["jpg", "png", "webp"].includes(extension)) {
    return "jpg";
  }

  return extension;
}


// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

export async function initializeEditProfile() {
  return loadProfile();
}


// ------------------------------------------------------------
// Refresh
// ------------------------------------------------------------

export async function refreshProfile() {
  return loadProfile();
}


// ------------------------------------------------------------
// State
// ------------------------------------------------------------

export function getState() {
  return {
    currentUser,
    currentProfile,
    loading,
    saving,
    avatarUploading
  };
}

export function isLoading() {
  return loading;
}

export function isSaving() {
  return saving;
}

export function isUploadingAvatar() {
  return avatarUploading;
}


// ------------------------------------------------------------
// Cleanup
// ------------------------------------------------------------

export function destroyEditProfile() {
  listeners.clear();

  currentUser = null;
  currentProfile = null;
  loading = false;
  saving = false;
  avatarUploading = false;
}


// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  loadProfile,
  refreshProfile,

  getCurrentUser,
  getCachedUser,

  getCurrentProfile,

  validateUsername,
  isUsernameAvailable,
  validateBio,
  validateAvatarFile,

  uploadAvatar,
  deleteAvatarFile,
  getAvatarStoragePath,

  updateProfile,
  updateUsername,
  updateBio,
  updateDisplayName,
  updateAvatar,
  removeAvatar,

  updateAuthMetadata,

  getProfileURL,

  initializeEditProfile,
  onEditProfileChange,

  getState,
  isLoading,
  isSaving,
  isUploadingAvatar,

  destroyEditProfile
};