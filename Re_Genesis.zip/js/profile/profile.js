// ============================================================
// REGENESIS
// js/profile/profile.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const PROFILE_TABLE = "profiles";
const FOLLOWERS_TABLE = "followers";
const POSTS_TABLE = "posts";

const DEFAULT_POST_LIMIT = 12;
const MAX_POST_LIMIT = 50;


// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let currentProfile = null;

let profilePosts = [];
let followerCount = 0;
let followingCount = 0;
let postCount = 0;

let isFollowing = false;
let loading = false;

let realtimeChannel = null;

const listeners = new Set();


// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const PROFILE_EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",
  POSTS_LOADED: "posts_loaded",

  FOLLOWED: "followed",
  UNFOLLOWED: "unfollowed",

  STATS_UPDATED: "stats_updated",
  UPDATED: "updated",

  REALTIME_UPDATE: "realtime_update",

  ERROR: "error",
  CHANGED: "changed"
};


// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onProfileChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(event, data = null) {
  listeners.forEach((callback) => {
    try {
      callback({
        event,
        data,
        state: getState()
      });
    } catch (error) {
      console.error(
        "REGENESIS profile listener error:",
        error
      );
    }
  });
}


// ------------------------------------------------------------
// Error helper
// ------------------------------------------------------------

function getErrorMessage(error) {
  if (!error) {
    return "Something went wrong.";
  }

  return (
    error.message ||
    error.error_description ||
    error.details ||
    error.hint ||
    "Something went wrong."
  );
}


// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const {
    data,
    error
  } = await supabase.auth.getUser();

  if (error) {
    throw error;
  }

  currentUser = data?.user || null;

  return currentUser;
}

export function getCachedUser() {
  return currentUser;
}


// ------------------------------------------------------------
// Profile selectors
// ------------------------------------------------------------

const PROFILE_COLUMNS = `
  id,
  username,
  display_name,
  bio,
  avatar_url,
  banner_url,
  created_at,
  updated_at
`;


// ------------------------------------------------------------
// Get profile by user ID
// ------------------------------------------------------------

export async function getProfileByUserId(userId) {
  if (!userId) {
    throw new Error("A user ID is required.");
  }

  const {
    data,
    error
  } = await supabase
    .from(PROFILE_TABLE)
    .select(PROFILE_COLUMNS)
    .eq("id", userId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data || null;
}


// ------------------------------------------------------------
// Get profile by username
// ------------------------------------------------------------

export async function getProfileByUsername(username) {
  const value = String(username || "").trim();

  if (!value) {
    throw new Error("Username is required.");
  }

  const {
    data,
    error
  } = await supabase
    .from(PROFILE_TABLE)
    .select(PROFILE_COLUMNS)
    .eq("username", value.toLowerCase())
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data || null;
}


// ------------------------------------------------------------
// Get profile by ID OR username
// ------------------------------------------------------------

export async function getProfile(identifier) {
  if (!identifier) {
    throw new Error("A profile identifier is required.");
  }

  const value = String(identifier).trim();

  // UUID check before querying id.
  // This prevents sending arbitrary usernames into a UUID column.
  const uuidRegex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

  if (uuidRegex.test(value)) {
    const byId = await getProfileByUserId(value);

    if (byId) {
      return byId;
    }
  }

  return getProfileByUsername(value);
}


// ------------------------------------------------------------
// Load profile
// ------------------------------------------------------------

export async function loadProfile(identifier = null) {
  loading = true;

  emit(PROFILE_EVENTS.LOADING);

  try {
    let profile;

    if (identifier) {
      profile = await getProfile(identifier);
    } else {
      const user = currentUser || await getCurrentUser();

      if (!user) {
        throw new Error("You must be logged in.");
      }

      profile = await getProfileByUserId(user.id);
    }

    if (!profile) {
      throw new Error("Profile not found.");
    }

    currentProfile = profile;

    // Load stats independently.
    await loadProfileStats(profile.id);

    // Load posts independently.
    await loadProfilePosts(profile.id);

    // Check follow state.
    if (currentUser && currentUser.id !== profile.id) {
      isFollowing = await checkFollowing(
        currentUser.id,
        profile.id
      );
    } else {
      isFollowing = false;
    }

    emit(
      PROFILE_EVENTS.LOADED,
      currentProfile
    );

    return currentProfile;

  } catch (error) {
    emit(
      PROFILE_EVENTS.ERROR,
      error
    );

    throw error;

  } finally {
    loading = false;
  }
}


// ------------------------------------------------------------
// Profile statistics
// ------------------------------------------------------------

export async function loadProfileStats(userId) {
  if (!userId) {
    throw new Error("User ID is required.");
  }

  let followers = 0;
  let following = 0;
  let posts = 0;

  // ----------------------------------------------------------
  // Followers
  // ----------------------------------------------------------

  try {
    const result = await supabase
      .from(FOLLOWERS_TABLE)
      .select("id", {
        count: "exact",
        head: true
      })
      .eq("following_id", userId);

    if (!result.error) {
      followers = result.count || 0;
    }
  } catch (error) {
    console.warn(
      "Could not load follower count:",
      error
    );
  }


  // ----------------------------------------------------------
  // Following
  // ----------------------------------------------------------

  try {
    const result = await supabase
      .from(FOLLOWERS_TABLE)
      .select("id", {
        count: "exact",
        head: true
      })
      .eq("follower_id", userId);

    if (!result.error) {
      following = result.count || 0;
    }
  } catch (error) {
    console.warn(
      "Could not load following count:",
      error
    );
  }


  // ----------------------------------------------------------
  // Posts
  // ----------------------------------------------------------

  try {
    const result = await supabase
      .from(POSTS_TABLE)
      .select("id", {
        count: "exact",
        head: true
      })
      .eq("user_id", userId);

    if (!result.error) {
      posts = result.count || 0;
    }
  } catch (error) {
    console.warn(
      "Could not load post count:",
      error
    );
  }


  followerCount = followers;
  followingCount = following;
  postCount = posts;

  const stats = {
    followers: followerCount,
    following: followingCount,
    posts: postCount
  };

  emit(
    PROFILE_EVENTS.STATS_UPDATED,
    stats
  );

  return stats;
}


// ------------------------------------------------------------
// Load user's posts
// ------------------------------------------------------------

export async function loadProfilePosts(
  userId,
  {
    limit = DEFAULT_POST_LIMIT,
    offset = 0
  } = {}
) {
  if (!userId) {
    throw new Error("User ID is required.");
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_POST_LIMIT, 1),
    MAX_POST_LIMIT
  );

  offset = Math.max(
    Number(offset) || 0,
    0
  );

  try {
    const {
      data,
      error
    } = await supabase
      .from(POSTS_TABLE)
      .select(`
        id,
        user_id,
        content,
        image_url,
        created_at,
        updated_at
      `)
      .eq("user_id", userId)
      .order("created_at", {
        ascending: false
      })
      .range(
        offset,
        offset + limit - 1
      );

    if (error) {
      // Posts may not be created yet.
      // Return an empty real result instead of fake data.
      if (
        error.code === "42P01" ||
        error.code === "PGRST205"
      ) {
        profilePosts = [];

        emit(
          PROFILE_EVENTS.POSTS_LOADED,
          profilePosts
        );

        return [];
      }

      throw error;
    }

    profilePosts = data || [];

    emit(
      PROFILE_EVENTS.POSTS_LOADED,
      profilePosts
    );

    return profilePosts;

  } catch (error) {
    emit(
      PROFILE_EVENTS.ERROR,
      error
    );

    throw error;
  }
}


// ------------------------------------------------------------
// Check if current user follows profile
// ------------------------------------------------------------

export async function checkFollowing(
  followerId,
  followingId
) {
  if (!followerId || !followingId) {
    return false;
  }

  if (followerId === followingId) {
    return false;
  }

  const {
    data,
    error
  } = await supabase
    .from(FOLLOWERS_TABLE)
    .select("id")
    .eq("follower_id", followerId)
    .eq("following_id", followingId)
    .maybeSingle();

  if (error) {
    // If the followers table does not exist yet,
    // don't invent a follow state.
    if (
      error.code === "42P01" ||
      error.code === "PGRST205"
    ) {
      return false;
    }

    throw error;
  }

  return Boolean(data);
}


// ------------------------------------------------------------
// Follow user
// ------------------------------------------------------------

export async function followUser(userId) {
  const user = currentUser || await getCurrentUser();

  if (!user) {
    throw new Error("You must be logged in to follow people.");
  }

  if (!userId) {
    throw new Error("User ID is required.");
  }

  if (user.id === userId) {
    throw new Error("You cannot follow yourself.");
  }

  const alreadyFollowing =
    await checkFollowing(
      user.id,
      userId
    );

  if (alreadyFollowing) {
    isFollowing = true;

    return true;
  }

  const {
    error
  } = await supabase
    .from(FOLLOWERS_TABLE)
    .insert({
      follower_id: user.id,
      following_id: userId
    });

  if (error) {
    // Unique constraint means another request
    // already created the follow.
    if (error.code === "23505") {
      isFollowing = true;
      return true;
    }

    throw error;
  }

  isFollowing = true;

  followerCount += 1;

  emit(
    PROFILE_EVENTS.FOLLOWED,
    {
      userId,
      followerCount
    }
  );

  emit(
    PROFILE_EVENTS.CHANGED,
    currentProfile
  );

  return true;
}


// ------------------------------------------------------------
// Unfollow user
// ------------------------------------------------------------

export async function unfollowUser(userId) {
  const user = currentUser || await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to unfollow people."
    );
  }

  if (!userId) {
    throw new Error("User ID is required.");
  }

  const {
    error
  } = await supabase
    .from(FOLLOWERS_TABLE)
    .delete()
    .eq("follower_id", user.id)
    .eq("following_id", userId);

  if (error) {
    throw error;
  }

  isFollowing = false;

  followerCount = Math.max(
    followerCount - 1,
    0
  );

  emit(
    PROFILE_EVENTS.UNFOLLOWED,
    {
      userId,
      followerCount
    }
  );

  emit(
    PROFILE_EVENTS.CHANGED,
    currentProfile
  );

  return true;
}


// ------------------------------------------------------------
// Toggle follow
// ------------------------------------------------------------

export async function toggleFollow(userId) {
  if (isFollowing) {
    await unfollowUser(userId);
    return false;
  }

  await followUser(userId);
  return true;
}


// ------------------------------------------------------------
// Get followers
// ------------------------------------------------------------

export async function getFollowers(
  userId,
  {
    limit = 24,
    offset = 0
  } = {}
) {
  if (!userId) {
    throw new Error("User ID is required.");
  }

  limit = Math.min(
    Math.max(Number(limit) || 24, 1),
    100
  );

  offset = Math.max(
    Number(offset) || 0,
    0
  );

  const {
    data,
    error
  } = await supabase
    .from(FOLLOWERS_TABLE)
    .select(`
      id,
      follower_id,
      created_at,
      profile:profiles!followers_follower_id_fkey (
        id,
        username,
        display_name,
        avatar_url
      )
    `)
    .eq("following_id", userId)
    .order("created_at", {
      ascending: false
    })
    .range(
      offset,
      offset + limit - 1
    );

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Get following
// ------------------------------------------------------------

export async function getFollowing(
  userId,
  {
    limit = 24,
    offset = 0
  } = {}
) {
  if (!userId) {
    throw new Error("User ID is required.");
  }

  limit = Math.min(
    Math.max(Number(limit) || 24, 1),
    100
  );

  offset = Math.max(
    Number(offset) || 0,
    0
  );

  const {
    data,
    error
  } = await supabase
    .from(FOLLOWERS_TABLE)
    .select(`
      id,
      following_id,
      created_at,
      profile:profiles!followers_following_id_fkey (
        id,
        username,
        display_name,
        avatar_url
      )
    `)
    .eq("follower_id", userId)
    .order("created_at", {
      ascending: false
    })
    .range(
      offset,
      offset + limit - 1
    );

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Refresh profile
// ------------------------------------------------------------

export async function refreshProfile() {
  if (!currentProfile) {
    return null;
  }

  return loadProfile(
    currentProfile.id
  );
}


// ------------------------------------------------------------
// Refresh stats
// ------------------------------------------------------------

export async function refreshProfileStats() {
  if (!currentProfile) {
    return null;
  }

  return loadProfileStats(
    currentProfile.id
  );
}


// ------------------------------------------------------------
// Refresh posts
// ------------------------------------------------------------

export async function refreshProfilePosts(
  options = {}
) {
  if (!currentProfile) {
    return [];
  }

  return loadProfilePosts(
    currentProfile.id,
    options
  );
}


// ------------------------------------------------------------
// Subscribe to profile changes
// ------------------------------------------------------------

export function subscribeToProfile(
  profileId = null
) {
  unsubscribeFromProfile();

  const id =
    profileId ||
    currentProfile?.id;

  if (!id) {
    return null;
  }

  realtimeChannel = supabase
    .channel(`profile-${id}-${Date.now()}`)

    // Profile changes
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: PROFILE_TABLE,
        filter: `id=eq.${id}`
      },
      async (payload) => {
        try {
          if (
            payload.eventType === "DELETE"
          ) {
            currentProfile = null;

            emit(
              PROFILE_EVENTS.REALTIME_UPDATE,
              payload
            );

            return;
          }

          if (payload.new) {
            currentProfile = {
              ...currentProfile,
              ...payload.new
            };

            emit(
              PROFILE_EVENTS.REALTIME_UPDATE,
              currentProfile
            );
          }
        } catch (error) {
          emit(
            PROFILE_EVENTS.ERROR,
            error
          );
        }
      }
    )

    // Followers changes
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: FOLLOWERS_TABLE,
        filter: `following_id=eq.${id}`
      },
      async () => {
        try {
          await loadProfileStats(id);

          if (currentUser) {
            isFollowing =
              await checkFollowing(
                currentUser.id,
                id
              );
          }

          emit(
            PROFILE_EVENTS.REALTIME_UPDATE,
            {
              type: "followers"
            }
          );

        } catch (error) {
          console.warn(
            "Profile follower realtime refresh failed:",
            error
          );
        }
      }
    )

    // Posts changes
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: POSTS_TABLE,
        filter: `user_id=eq.${id}`
      },
      async () => {
        try {
          await loadProfilePosts(id);

          await loadProfileStats(id);

          emit(
            PROFILE_EVENTS.REALTIME_UPDATE,
            {
              type: "posts"
            }
          );

        } catch (error) {
          console.warn(
            "Profile post realtime refresh failed:",
            error
          );
        }
      }
    )

    .subscribe((status) => {
      if (status === "SUBSCRIBED") {
        console.log(
          "REGENESIS profile realtime connected."
        );
      }

      if (status === "CHANNEL_ERROR") {
        console.warn(
          "REGENESIS profile realtime channel error."
        );
      }

      if (status === "TIMED_OUT") {
        console.warn(
          "REGENESIS profile realtime timed out."
        );
      }
    });

  return realtimeChannel;
}


// ------------------------------------------------------------
// Unsubscribe
// ------------------------------------------------------------

export async function unsubscribeFromProfile() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.warn(
      "Could not remove profile realtime channel:",
      error
    );
  }

  realtimeChannel = null;
}


// ------------------------------------------------------------
// Profile URL
// ------------------------------------------------------------

export function getProfileURL(
  username,
  {
    relative = true
  } = {}
) {
  if (!username) {
    return relative
      ? "./profile.html"
      : "/pages/profile.html";
  }

  const query =
    `?username=${encodeURIComponent(
      username
    )}`;

  return relative
    ? `./profile.html${query}`
    : `/pages/profile.html${query}`;
}


// ------------------------------------------------------------
// Edit profile URL
// ------------------------------------------------------------

export function getEditProfileURL() {
  return "./edit-profile.html";
}


// ------------------------------------------------------------
// Is this my profile?
// ------------------------------------------------------------

export function isMyProfile(
  profile = currentProfile
) {
  if (!profile || !currentUser) {
    return false;
  }

  return profile.id === currentUser.id;
}


// ------------------------------------------------------------
// Get display name
// ------------------------------------------------------------

export function getDisplayName(
  profile = currentProfile
) {
  if (!profile) {
    return "REGENESIS Member";
  }

  return (
    profile.display_name ||
    profile.username ||
    "REGENESIS Member"
  );
}


// ------------------------------------------------------------
// Get username
// ------------------------------------------------------------

export function getUsername(
  profile = currentProfile
) {
  if (!profile) {
    return "";
  }

  return profile.username || "";
}


// ------------------------------------------------------------
// Get avatar
// ------------------------------------------------------------

export function getAvatar(
  profile = currentProfile
) {
  if (!profile) {
    return null;
  }

  return profile.avatar_url || null;
}


// ------------------------------------------------------------
// Get banner
// ------------------------------------------------------------

export function getBanner(
  profile = currentProfile
) {
  if (!profile) {
    return null;
  }

  return profile.banner_url || null;
}


// ------------------------------------------------------------
// Get bio
// ------------------------------------------------------------

export function getBio(
  profile = currentProfile
) {
  if (!profile) {
    return "";
  }

  return profile.bio || "";
}


// ------------------------------------------------------------
// Get account age
// ------------------------------------------------------------

export function getJoinedDate(
  profile = currentProfile
) {
  if (!profile?.created_at) {
    return null;
  }

  return new Date(
    profile.created_at
  );
}


// ------------------------------------------------------------
// Get state
// ------------------------------------------------------------

export function getState() {
  return {
    currentUser,
    currentProfile,

    profilePosts: [
      ...profilePosts
    ],

    followerCount,
    followingCount,
    postCount,

    isFollowing,

    loading,

    realtimeConnected:
      Boolean(realtimeChannel)
  };
}


// ------------------------------------------------------------
// Getters
// ------------------------------------------------------------

export function getCurrentProfile() {
  return currentProfile;
}

export function getProfilePosts() {
  return [
    ...profilePosts
  ];
}

export function getFollowerCount() {
  return followerCount;
}

export function getFollowingCount() {
  return followingCount;
}

export function getPostCount() {
  return postCount;
}

export function getIsFollowing() {
  return isFollowing;
}

export function isLoading() {
  return loading;
}


// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

export async function initializeProfile(
  identifier = null,
  {
    realtime = true
  } = {}
) {
  const profile =
    await loadProfile(identifier);

  if (realtime) {
    subscribeToProfile(
      profile.id
    );
  }

  return profile;
}


// ------------------------------------------------------------
// Cleanup
// ------------------------------------------------------------

export async function destroyProfile() {
  await unsubscribeFromProfile();

  currentUser = null;
  currentProfile = null;

  profilePosts = [];

  followerCount = 0;
  followingCount = 0;
  postCount = 0;

  isFollowing = false;
  loading = false;

  listeners.clear();
}


// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  // Loading
  loadProfile,
  refreshProfile,
  initializeProfile,
  destroyProfile,

  // Profile
  getProfile,
  getProfileByUserId,
  getProfileByUsername,
  getCurrentProfile,

  // Authentication
  getCurrentUser,
  getCachedUser,

  // Stats
  loadProfileStats,
  refreshProfileStats,
  getFollowerCount,
  getFollowingCount,
  getPostCount,

  // Posts
  loadProfilePosts,
  refreshProfilePosts,
  getProfilePosts,

  // Follow system
  checkFollowing,
  followUser,
  unfollowUser,
  toggleFollow,
  getFollowers,
  getFollowing,
  getIsFollowing,

  // Profile information
  getDisplayName,
  getUsername,
  getAvatar,
  getBanner,
  getBio,
  getJoinedDate,
  isMyProfile,

  // URLs
  getProfileURL,
  getEditProfileURL,

  // Realtime
  subscribeToProfile,
  unsubscribeFromProfile,

  // Events
  onProfileChange,

  // State
  getState,
  isLoading
};