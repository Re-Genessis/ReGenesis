// ============================================================
// REGENESIS — Messaging Inbox Module
// File: js/messaging/inbox.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 30;
const MAX_LIMIT = 100;
const MESSAGE_MAX_LENGTH = 5000;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let conversations = [];
let currentConversation = null;

let loading = false;
let realtimeChannel = null;

const listeners = new Set();

const EVENTS = {
    LOADING: "loading",
    LOADED: "loaded",
    CONVERSATION_LOADED: "conversation_loaded",
    MESSAGE_SENT: "message_sent",
    MESSAGE_DELETED: "message_deleted",
    READ: "read",
    UPDATED: "updated",
    CHANGED: "changed",
    ERROR: "error"
};

// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onInboxChange(callback) {
    if (typeof callback !== "function") {
        throw new TypeError("callback must be a function");
    }

    listeners.add(callback);

    return () => {
        listeners.delete(callback);
    };
}

function emit(event, data = null) {
    listeners.forEach(callback => {
        try {
            callback({
                event,
                data
            });
        } catch (error) {
            console.error(
                "Inbox listener error:",
                error
            );
        }
    });
}

// ------------------------------------------------------------
// Current user
// ------------------------------------------------------------

export async function getCurrentUser() {

    const {
        data,
        error
    } = await supabase.auth.getUser();

    if (error) {
        currentUser = null;
        return null;
    }

    currentUser = data?.user || null;

    return currentUser;
}

// ------------------------------------------------------------
// Require authentication
// ------------------------------------------------------------

async function requireUser() {

    const user =
        currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in to use messaging."
        );
    }

    return user;
}

// ------------------------------------------------------------
// Load inbox conversations
// ------------------------------------------------------------

export async function loadInbox({
    limit = DEFAULT_LIMIT,
    offset = 0
} = {}) {

    const user = await requireUser();

    loading = true;
    emit(EVENTS.LOADING, true);

    try {

        limit = Math.min(
            Math.max(Number(limit) || DEFAULT_LIMIT, 1),
            MAX_LIMIT
        );

        offset = Math.max(
            Number(offset) || 0,
            0
        );

        /*
         * Expected table:
         *
         * conversations
         * ├── id
         * ├── created_at
         * └── updated_at
         *
         * conversation_members
         * ├── id
         * ├── conversation_id
         * ├── user_id
         * ├── last_read_at
         * └── created_at
         */

        const {
            data: memberships,
            error: membershipError
        } = await supabase
            .from("conversation_members")
            .select(`
                id,
                conversation_id,
                user_id,
                last_read_at,
                created_at,
                conversations (
                    id,
                    created_at,
                    updated_at
                )
            `)
            .eq("user_id", user.id)
            .order("created_at", {
                ascending: false
            })
            .range(
                offset,
                offset + limit - 1
            );

        if (membershipError) {
            throw membershipError;
        }

        const result = [];

        for (const membership of memberships || []) {

            const conversation =
                membership.conversations;

            if (!conversation) {
                continue;
            }

            const members =
                await getConversationMembers(
                    conversation.id
                );

            const otherMembers =
                members.filter(
                    member =>
                        member.user_id !== user.id
                );

            const latestMessage =
                await getLatestMessage(
                    conversation.id
                );

            const unreadCount =
                await getUnreadCount(
                    conversation.id,
                    user.id,
                    membership.last_read_at
                );

            result.push({
                ...conversation,

                membership_id: membership.id,

                last_read_at:
                    membership.last_read_at,

                members,

                other_members:
                    otherMembers,

                latest_message:
                    latestMessage,

                unread_count:
                    unreadCount
            });
        }

        conversations = result;

        emit(EVENTS.LOADED, conversations);

        return conversations;

    } catch (error) {

        console.error(
            "Failed to load inbox:",
            error
        );

        emit(EVENTS.ERROR, error);

        throw error;

    } finally {

        loading = false;

        emit(EVENTS.LOADING, false);
    }
}

// ------------------------------------------------------------
// Get conversation members
// ------------------------------------------------------------

export async function getConversationMembers(
    conversationId
) {

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("conversation_members")
        .select(`
            id,
            conversation_id,
            user_id,
            last_read_at,
            created_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .eq(
            "conversation_id",
            conversationId
        );

    if (error) {
        throw error;
    }

    return data || [];
}

// ------------------------------------------------------------
// Get latest message
// ------------------------------------------------------------

export async function getLatestMessage(
    conversationId
) {

    if (!conversationId) {
        return null;
    }

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .select(`
            id,
            conversation_id,
            sender_id,
            content,
            created_at,
            updated_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .eq(
            "conversation_id",
            conversationId
        )
        .order("created_at", {
            ascending: false
        })
        .limit(1)
        .maybeSingle();

    if (error) {
        throw error;
    }

    return data || null;
}

// ------------------------------------------------------------
// Get unread message count
// ------------------------------------------------------------

export async function getUnreadCount(
    conversationId,
    userId = null,
    lastReadAt = null
) {

    const user =
        userId
            ? { id: userId }
            : await requireUser();

    if (!conversationId) {
        return 0;
    }

    let query = supabase
        .from("messages")
        .select("id", {
            count: "exact",
            head: true
        })
        .eq(
            "conversation_id",
            conversationId
        )
        .neq(
            "sender_id",
            user.id
        );

    if (lastReadAt) {
        query = query.gt(
            "created_at",
            lastReadAt
        );
    }

    const {
        count,
        error
    } = await query;

    if (error) {
        throw error;
    }

    return count || 0;
}

// ------------------------------------------------------------
// Get total unread messages
// ------------------------------------------------------------

export async function getTotalUnreadCount() {

    const user = await requireUser();

    const memberships =
        await supabase
            .from("conversation_members")
            .select(
                "conversation_id,last_read_at"
            )
            .eq(
                "user_id",
                user.id
            );

    if (memberships.error) {
        throw memberships.error;
    }

    let total = 0;

    for (
        const membership
        of memberships.data || []
    ) {

        total += await getUnreadCount(
            membership.conversation_id,
            user.id,
            membership.last_read_at
        );
    }

    return total;
}

// ------------------------------------------------------------
// Get conversation
// ------------------------------------------------------------

export async function getConversation(
    conversationId
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("conversation_members")
        .select(`
            id,
            conversation_id,
            user_id,
            last_read_at,
            conversations (
                id,
                created_at,
                updated_at
            )
        `)
        .eq(
            "conversation_id",
            conversationId
        )
        .eq(
            "user_id",
            user.id
        )
        .maybeSingle();

    if (error) {
        throw error;
    }

    if (!data?.conversations) {
        throw new Error(
            "Conversation not found or you do not have access."
        );
    }

    const members =
        await getConversationMembers(
            conversationId
        );

    currentConversation = {
        ...data.conversations,
        membership_id: data.id,
        last_read_at: data.last_read_at,
        members
    };

    return currentConversation;
}

// ------------------------------------------------------------
// Load messages
// ------------------------------------------------------------

export async function loadMessages(
    conversationId,
    {
        limit = 50,
        before = null
    } = {}
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    // Verify membership before loading messages.
    await getConversation(conversationId);

    const safeLimit = Math.min(
        Math.max(Number(limit) || 50, 1),
        MAX_LIMIT
    );

    let query = supabase
        .from("messages")
        .select(`
            id,
            conversation_id,
            sender_id,
            content,
            created_at,
            updated_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .eq(
            "conversation_id",
            conversationId
        )
        .order("created_at", {
            ascending: false
        })
        .limit(safeLimit);

    if (before) {
        query = query.lt(
            "created_at",
            before
        );
    }

    const {
        data,
        error
    } = await query;

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    const messages =
        (data || []).reverse();

    emit(
        EVENTS.CONVERSATION_LOADED,
        {
            conversationId,
            messages
        }
    );

    return messages;
}

// ------------------------------------------------------------
// Send message
// ------------------------------------------------------------

export async function sendMessage(
    conversationId,
    content
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    if (
        typeof content !== "string" ||
        !content.trim()
    ) {
        throw new Error(
            "Message cannot be empty."
        );
    }

    const message =
        content.trim();

    if (
        message.length >
        MESSAGE_MAX_LENGTH
    ) {
        throw new Error(
            `Message cannot exceed ${MESSAGE_MAX_LENGTH} characters.`
        );
    }

    // Membership check.
    await getConversation(
        conversationId
    );

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .insert({
            conversation_id:
                conversationId,

            sender_id:
                user.id,

            content:
                message
        })
        .select(`
            id,
            conversation_id,
            sender_id,
            content,
            created_at,
            updated_at
        `)
        .single();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    emit(
        EVENTS.MESSAGE_SENT,
        data
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "message_sent",
            message: data
        }
    );

    return data;
}

// ------------------------------------------------------------
// Delete own message
// ------------------------------------------------------------

export async function deleteMessage(
    messageId
) {

    const user = await requireUser();

    if (!messageId) {
        throw new Error(
            "Message ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .delete()
        .eq(
            "id",
            messageId
        )
        .eq(
            "sender_id",
            user.id
        )
        .select("id")
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    if (!data) {
        throw new Error(
            "Message not found or you do not have permission to delete it."
        );
    }

    emit(
        EVENTS.MESSAGE_DELETED,
        {
            id: messageId
        }
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "message_deleted",
            id: messageId
        }
    );

    return true;
}

// ------------------------------------------------------------
// Mark conversation as read
// ------------------------------------------------------------

export async function markConversationRead(
    conversationId
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    /*
     * We use the current server/database time by
     * taking the newest message timestamp.
     */

    const latestMessage =
        await getLatestMessage(
            conversationId
        );

    const readAt =
        latestMessage?.created_at ||
        new Date().toISOString();

    const {
        data,
        error
    } = await supabase
        .from("conversation_members")
        .update({
            last_read_at: readAt
        })
        .eq(
            "conversation_id",
            conversationId
        )
        .eq(
            "user_id",
            user.id
        )
        .select(`
            id,
            conversation_id,
            user_id,
            last_read_at
        `)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    emit(
        EVENTS.READ,
        {
            conversationId,
            last_read_at:
                data?.last_read_at ||
                readAt
        }
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "read",
            conversationId
        }
    );

    return data;
}

// ------------------------------------------------------------
// Find existing direct conversation
// ------------------------------------------------------------

export async function findDirectConversation(
    otherUserId
) {

    const user = await requireUser();

    if (!otherUserId) {
        throw new Error(
            "Other user ID is required."
        );
    }

    if (otherUserId === user.id) {
        throw new Error(
            "You cannot start a conversation with yourself."
        );
    }

    const {
        data: myMemberships,
        error: myError
    } = await supabase
        .from("conversation_members")
        .select("conversation_id")
        .eq(
            "user_id",
            user.id
        );

    if (myError) {
        throw myError;
    }

    if (!myMemberships?.length) {
        return null;
    }

    for (
        const membership
        of myMemberships
    ) {

        const {
            data: otherMembership,
            error
        } = await supabase
            .from("conversation_members")
            .select("id")
            .eq(
                "conversation_id",
                membership.conversation_id
            )
            .eq(
                "user_id",
                otherUserId
            )
            .maybeSingle();

        if (error) {
            throw error;
        }

        if (otherMembership) {

            const members =
                await getConversationMembers(
                    membership.conversation_id
                );

            /*
             * A direct conversation should contain
             * exactly two members.
             */
            if (members.length === 2) {
                return membership.conversation_id;
            }
        }
    }

    return null;
}

// ------------------------------------------------------------
// Create direct conversation
// ------------------------------------------------------------

export async function createDirectConversation(
    otherUserId
) {

    const user = await requireUser();

    if (!otherUserId) {
        throw new Error(
            "Other user ID is required."
        );
    }

    if (otherUserId === user.id) {
        throw new Error(
            "You cannot message yourself."
        );
    }

    // Reuse an existing direct conversation.
    const existing =
        await findDirectConversation(
            otherUserId
        );

    if (existing) {
        return await getConversation(
            existing
        );
    }

    /*
     * Create the conversation.
     *
     * RLS should only allow authenticated
     * users to create conversations.
     */

    const {
        data: conversation,
        error:
            conversationError
    } = await supabase
        .from("conversations")
        .insert({})
        .select(`
            id,
            created_at,
            updated_at
        `)
        .single();

    if (conversationError) {
        emit(
            EVENTS.ERROR,
            conversationError
        );

        throw conversationError;
    }

    const {
        error: memberError
    } = await supabase
        .from("conversation_members")
        .insert([
            {
                conversation_id:
                    conversation.id,

                user_id:
                    user.id
            },
            {
                conversation_id:
                    conversation.id,

                user_id:
                    otherUserId
            }
        ]);

    if (memberError) {

        // Best-effort cleanup.
        await supabase
            .from("conversations")
            .delete()
            .eq(
                "id",
                conversation.id
            );

        emit(
            EVENTS.ERROR,
            memberError
        );

        throw memberError;
    }

    emit(
        EVENTS.CHANGED,
        {
            type: "conversation_created",
            conversation
        }
    );

    return await getConversation(
        conversation.id
    );
}

// ------------------------------------------------------------
// Start or get direct conversation
// ------------------------------------------------------------

export async function openDirectConversation(
    otherUserId
) {

    return await createDirectConversation(
        otherUserId
    );
}

// ------------------------------------------------------------
// Search users to message
// ------------------------------------------------------------

export async function searchUsers(
    search,
    {
        limit = 20
    } = {}
) {

    await requireUser();

    const text =
        String(search || "").trim();

    if (!text) {
        return [];
    }

    const safeLimit = Math.min(
        Math.max(Number(limit) || 20, 1),
        50
    );

    const {
        data,
        error
    } = await supabase
        .from("profiles")
        .select(`
            id,
            username,
            avatar_url
        `)
        .ilike(
            "username",
            `%${text}%`
        )
        .limit(safeLimit);

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    return (data || []).filter(
        profile =>
            profile.id !== currentUser?.id
    );
}

// ------------------------------------------------------------
// Search conversations
// ------------------------------------------------------------

export async function searchConversations(
    search
) {

    const user = await requireUser();

    const text =
        String(search || "")
            .trim()
            .toLowerCase();

    if (!text) {
        return conversations;
    }

    const result = [];

    for (
        const conversation
        of conversations
    ) {

        const matches =
            (conversation.other_members || [])
                .some(member => {

                    const username =
                        member.profiles
                            ?.username
                            ?.toLowerCase() || "";

                    return username.includes(text);
                });

        if (matches) {
            result.push(
                conversation
            );
        }
    }

    return result;
}

// ------------------------------------------------------------
// Get other participant in direct chat
// ------------------------------------------------------------

export function getOtherParticipant(
    conversation
) {

    if (!conversation) {
        return null;
    }

    const members =
        conversation.other_members ||
        conversation.members ||
        [];

    return members[0] || null;
}

// ------------------------------------------------------------
// Subscribe to inbox realtime
// ------------------------------------------------------------

export async function subscribeToInbox() {

    const user = await requireUser();

    await unsubscribeFromInbox();

    /*
     * We listen to messages where the current user
     * can receive updates through conversations.
     *
     * IMPORTANT:
     * RLS must prevent unauthorized rows from
     * being exposed. Realtime is not the security
     * boundary.
     */

    realtimeChannel = supabase
        .channel(
            `regenesis-inbox-${user.id}`
        )

        .on(
            "postgres_changes",
            {
                event: "INSERT",
                schema: "public",
                table: "messages"
            },
            payload => {

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "message_insert",
                        payload
                    }
                );

                // Refresh the inbox so latest message
                // and unread count are accurate.
                loadInbox().catch(
                    error =>
                        console.error(
                            "Inbox refresh failed:",
                            error
                        )
                );
            }
        )

        .on(
            "postgres_changes",
            {
                event: "UPDATE",
                schema: "public",
                table: "messages"
            },
            payload => {

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "message_update",
                        payload
                    }
                );
            }
        )

        .on(
            "postgres_changes",
            {
                event: "DELETE",
                schema: "public",
                table: "messages"
            },
            payload => {

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "message_delete",
                        payload
                    }
                );

                loadInbox().catch(
                    error =>
                        console.error(
                            "Inbox refresh failed:",
                            error
                        )
                );
            }
        )

        .on(
            "postgres_changes",
            {
                event: "*",
                schema: "public",
                table: "conversation_members",
                filter:
                    `user_id=eq.${user.id}`
            },
            payload => {

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "membership",
                        payload
                    }
                );

                loadInbox().catch(
                    error =>
                        console.error(
                            "Inbox refresh failed:",
                            error
                        )
                );
            }
        )

        .subscribe(status => {

            if (status === "SUBSCRIBED") {
                console.log(
                    "REGENESIS messaging realtime connected."
                );
            }

            if (status === "CHANNEL_ERROR") {
                console.error(
                    "REGENESIS messaging realtime error."
                );
            }
        });

    return realtimeChannel;
}

// ------------------------------------------------------------
// Subscribe specifically to a conversation
// ------------------------------------------------------------

export async function subscribeToConversation(
    conversationId
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    await getConversation(
        conversationId
    );

    const channelName =
        `regenesis-conversation-${conversationId}-${user.id}`;

    const channel =
        supabase.channel(channelName);

    channel.on(
        "postgres_changes",
        {
            event: "*",
            schema: "public",
            table: "messages",
            filter:
                `conversation_id=eq.${conversationId}`
        },
        payload => {

            emit(
                EVENTS.CHANGED,
                {
                    type: "conversation_message",
                    conversationId,
                    payload
                }
            );
        }
    );

    channel.subscribe(status => {

        if (status === "SUBSCRIBED") {
            console.log(
                "Conversation realtime connected."
            );
        }
    });

    return channel;
}

// ------------------------------------------------------------
// Unsubscribe inbox
// ------------------------------------------------------------

export async function unsubscribeFromInbox() {

    if (!realtimeChannel) {
        return;
    }

    await supabase.removeChannel(
        realtimeChannel
    );

    realtimeChannel = null;
}

// ------------------------------------------------------------
// Refresh inbox
// ------------------------------------------------------------

export async function refreshInbox(
    options = {}
) {

    return await loadInbox(
        options
    );
}

// ------------------------------------------------------------
// Initialize messaging
// ------------------------------------------------------------

export async function initializeInbox(
    options = {}
) {

    await getCurrentUser();

    const result =
        await loadInbox(options);

    await subscribeToInbox();

    return result;
}

// ------------------------------------------------------------
// Destroy module
// ------------------------------------------------------------

export async function destroyInbox() {

    await unsubscribeFromInbox();

    listeners.clear();

    currentUser = null;
    conversations = [];
    currentConversation = null;

    loading = false;
}

// ------------------------------------------------------------
// State getters
// ------------------------------------------------------------

export function getConversations() {
    return [...conversations];
}

export function getCurrentConversation() {
    return currentConversation;
}

export function getCachedUser() {
    return currentUser;
}

export function isInboxLoading() {
    return loading;
}

export function getRealtimeChannel() {
    return realtimeChannel;
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {

    EVENTS,

    onInboxChange,

    getCurrentUser,

    loadInbox,
    refreshInbox,

    getConversation,
    getConversationMembers,

    loadMessages,
    getLatestMessage,

    getUnreadCount,
    getTotalUnreadCount,

    sendMessage,
    deleteMessage,

    markConversationRead,

    findDirectConversation,
    createDirectConversation,
    openDirectConversation,

    searchUsers,
    searchConversations,

    getOtherParticipant,

    subscribeToInbox,
    subscribeToConversation,
    unsubscribeFromInbox,

    initializeInbox,
    destroyInbox,

    getConversations,
    getCurrentConversation,
    getCachedUser,
    isInboxLoading,
    getRealtimeChannel
};