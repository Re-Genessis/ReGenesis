// ============================================================
// REGENESIS — Messages Module
// File: js/messaging/messages.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;
const MAX_MESSAGE_LENGTH = 5000;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let currentConversationId = null;
let messages = [];

let loading = false;
let sending = false;

let realtimeChannel = null;

const listeners = new Set();

const EVENTS = {
    LOADING: "loading",
    SENDING: "sending",
    LOADED: "loaded",
    MESSAGE_SENT: "message_sent",
    MESSAGE_UPDATED: "message_updated",
    MESSAGE_DELETED: "message_deleted",
    READ: "read",
    CHANGED: "changed",
    ERROR: "error"
};

// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onMessagesChange(callback) {
    if (typeof callback !== "function") {
        throw new TypeError("callback must be a function");
    }

    listeners.add(callback);

    return () => {
        listeners.delete(callback);
    };
}

function emit(event, data = null) {
    listeners.forEach(callback => {
        try {
            callback({
                event,
                data
            });
        } catch (error) {
            console.error(
                "Messages listener error:",
                error
            );
        }
    });
}

// ------------------------------------------------------------
// Current user
// ------------------------------------------------------------

export async function getCurrentUser() {
    const {
        data,
        error
    } = await supabase.auth.getUser();

    if (error) {
        currentUser = null;
        return null;
    }

    currentUser = data?.user || null;

    return currentUser;
}

// ------------------------------------------------------------
// Require authentication
// ------------------------------------------------------------

async function requireUser() {
    const user =
        currentUser || await getCurrentUser();

    if (!user) {
        throw new Error(
            "You must be logged in to use messages."
        );
    }

    return user;
}

// ------------------------------------------------------------
// Validate message
// ------------------------------------------------------------

export function validateMessage(content) {
    if (
        typeof content !== "string" ||
        !content.trim()
    ) {
        return {
            valid: false,
            error: "Message cannot be empty."
        };
    }

    const text = content.trim();

    if (text.length > MAX_MESSAGE_LENGTH) {
        return {
            valid: false,
            error:
                `Message cannot exceed ${MAX_MESSAGE_LENGTH} characters.`
        };
    }

    return {
        valid: true,
        value: text
    };
}

// ------------------------------------------------------------
// Verify conversation membership
// ------------------------------------------------------------

export async function isConversationMember(
    conversationId
) {
    const user = await requireUser();

    if (!conversationId) {
        return false;
    }

    const {
        data,
        error
    } = await supabase
        .from("conversation_members")
        .select("id")
        .eq(
            "conversation_id",
            conversationId
        )
        .eq(
            "user_id",
            user.id
        )
        .maybeSingle();

    if (error) {
        throw error;
    }

    return Boolean(data);
}

// ------------------------------------------------------------
// Set active conversation
// ------------------------------------------------------------

export async function setConversation(
    conversationId
) {
    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const member =
        await isConversationMember(
            conversationId
        );

    if (!member) {
        throw new Error(
            "You do not have access to this conversation."
        );
    }

    currentConversationId =
        conversationId;

    messages = [];

    return currentConversationId;
}

// ------------------------------------------------------------
// Get active conversation
// ------------------------------------------------------------

export function getConversationId() {
    return currentConversationId;
}

// ------------------------------------------------------------
// Load messages
// ------------------------------------------------------------

export async function loadMessages({
    conversationId = currentConversationId,
    limit = DEFAULT_LIMIT,
    before = null,
    after = null
} = {}) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    loading = true;

    emit(EVENTS.LOADING, true);

    try {

        const member =
            await isConversationMember(
                conversationId
            );

        if (!member) {
            throw new Error(
                "You do not have access to this conversation."
            );
        }

        const safeLimit = Math.min(
            Math.max(
                Number(limit) || DEFAULT_LIMIT,
                1
            ),
            MAX_LIMIT
        );

        let query = supabase
            .from("messages")
            .select(`
                id,
                conversation_id,
                sender_id,
                content,
                created_at,
                updated_at,
                profiles (
                    id,
                    username,
                    avatar_url
                )
            `)
            .eq(
                "conversation_id",
                conversationId
            )
            .order("created_at", {
                ascending: false
            })
            .limit(safeLimit);

        if (before) {
            query = query.lt(
                "created_at",
                before
            );
        }

        if (after) {
            query = query.gt(
                "created_at",
                after
            );
        }

        const {
            data,
            error
        } = await query;

        if (error) {
            throw error;
        }

        const loaded =
            (data || []).reverse();

        if (
            conversationId ===
            currentConversationId
        ) {

            if (before) {

                messages = [
                    ...loaded,
                    ...messages
                ];

            } else if (after) {

                messages = [
                    ...messages,
                    ...loaded
                ];

            } else {

                messages = loaded;
            }

            messages =
                deduplicateMessages(
                    messages
                );
        }

        emit(EVENTS.LOADED, {
            conversationId,
            messages: loaded,
            totalLoaded: messages.length,
            hasMore:
                loaded.length >= safeLimit
        });

        return loaded;

    } catch (error) {

        console.error(
            "Failed to load messages:",
            error
        );

        emit(EVENTS.ERROR, error);

        throw error;

    } finally {

        loading = false;

        emit(EVENTS.LOADING, false);
    }
}

// ------------------------------------------------------------
// Load older messages
// ------------------------------------------------------------

export async function loadOlderMessages(
    conversationId = currentConversationId
) {

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const oldest =
        messages.length
            ? messages[0]
            : null;

    return await loadMessages({
        conversationId,
        before:
            oldest?.created_at || null
    });
}

// ------------------------------------------------------------
// Load newer messages
// ------------------------------------------------------------

export async function loadNewerMessages(
    conversationId = currentConversationId
) {

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const newest =
        messages.length
            ? messages[messages.length - 1]
            : null;

    return await loadMessages({
        conversationId,
        after:
            newest?.created_at || null
    });
}

// ------------------------------------------------------------
// Get a single message
// ------------------------------------------------------------

export async function getMessage(
    messageId
) {

    await requireUser();

    if (!messageId) {
        throw new Error(
            "Message ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .select(`
            id,
            conversation_id,
            sender_id,
            content,
            created_at,
            updated_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .eq(
            "id",
            messageId
        )
        .maybeSingle();

    if (error) {
        throw error;
    }

    return data || null;
}

// ------------------------------------------------------------
// Send message
// ------------------------------------------------------------

export async function sendMessage(
    content,
    conversationId = currentConversationId
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const validation =
        validateMessage(content);

    if (!validation.valid) {
        throw new Error(
            validation.error
        );
    }

    const member =
        await isConversationMember(
            conversationId
        );

    if (!member) {
        throw new Error(
            "You are not a member of this conversation."
        );
    }

    sending = true;

    emit(EVENTS.SENDING, true);

    try {

        const {
            data,
            error
        } = await supabase
            .from("messages")
            .insert({
                conversation_id:
                    conversationId,

                sender_id:
                    user.id,

                content:
                    validation.value
            })
            .select(`
                id,
                conversation_id,
                sender_id,
                content,
                created_at,
                updated_at,
                profiles (
                    id,
                    username,
                    avatar_url
                )
            `)
            .single();

        if (error) {
            throw error;
        }

        if (
            conversationId ===
            currentConversationId
        ) {

            messages = deduplicateMessages([
                ...messages,
                data
            ]);
        }

        emit(
            EVENTS.MESSAGE_SENT,
            data
        );

        emit(
            EVENTS.CHANGED,
            {
                type: "insert",
                message: data
            }
        );

        return data;

    } catch (error) {

        emit(EVENTS.ERROR, error);

        throw error;

    } finally {

        sending = false;

        emit(EVENTS.SENDING, false);
    }
}

// ------------------------------------------------------------
// Edit own message
// ------------------------------------------------------------

export async function editMessage(
    messageId,
    content
) {

    const user = await requireUser();

    if (!messageId) {
        throw new Error(
            "Message ID is required."
        );
    }

    const validation =
        validateMessage(content);

    if (!validation.valid) {
        throw new Error(
            validation.error
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .update({
            content:
                validation.value,

            updated_at:
                new Date().toISOString()
        })
        .eq(
            "id",
            messageId
        )
        .eq(
            "sender_id",
            user.id
        )
        .select(`
            id,
            conversation_id,
            sender_id,
            content,
            created_at,
            updated_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    if (!data) {
        throw new Error(
            "Message not found or you do not have permission to edit it."
        );
    }

    updateCachedMessage(data);

    emit(
        EVENTS.MESSAGE_UPDATED,
        data
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "update",
            message: data
        }
    );

    return data;
}

// ------------------------------------------------------------
// Delete own message
// ------------------------------------------------------------

export async function deleteMessage(
    messageId
) {

    const user = await requireUser();

    if (!messageId) {
        throw new Error(
            "Message ID is required."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .delete()
        .eq(
            "id",
            messageId
        )
        .eq(
            "sender_id",
            user.id
        )
        .select("id, conversation_id")
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    if (!data) {
        throw new Error(
            "Message not found or you do not have permission to delete it."
        );
    }

    messages =
        messages.filter(
            message =>
                message.id !== messageId
        );

    emit(
        EVENTS.MESSAGE_DELETED,
        data
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "delete",
            message: data
        }
    );

    return true;
}

// ------------------------------------------------------------
// Mark conversation as read
// ------------------------------------------------------------

export async function markAsRead(
    conversationId = currentConversationId
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const member =
        await isConversationMember(
            conversationId
        );

    if (!member) {
        throw new Error(
            "You do not have access to this conversation."
        );
    }

    const newest =
        messages.length
            ? messages[messages.length - 1]
            : null;

    const readAt =
        newest?.created_at ||
        new Date().toISOString();

    const {
        data,
        error
    } = await supabase
        .from("conversation_members")
        .update({
            last_read_at: readAt
        })
        .eq(
            "conversation_id",
            conversationId
        )
        .eq(
            "user_id",
            user.id
        )
        .select(`
            id,
            conversation_id,
            user_id,
            last_read_at
        `)
        .maybeSingle();

    if (error) {
        emit(EVENTS.ERROR, error);
        throw error;
    }

    emit(
        EVENTS.READ,
        {
            conversationId,
            last_read_at:
                data?.last_read_at ||
                readAt
        }
    );

    emit(
        EVENTS.CHANGED,
        {
            type: "read",
            conversationId
        }
    );

    return data;
}

// ------------------------------------------------------------
// Check unread count
// ------------------------------------------------------------

export async function getUnreadCount(
    conversationId = currentConversationId
) {

    const user = await requireUser();

    if (!conversationId) {
        return 0;
    }

    const {
        data: membership,
        error: memberError
    } = await supabase
        .from("conversation_members")
        .select("last_read_at")
        .eq(
            "conversation_id",
            conversationId
        )
        .eq(
            "user_id",
            user.id
        )
        .maybeSingle();

    if (memberError) {
        throw memberError;
    }

    if (!membership) {
        return 0;
    }

    let query = supabase
        .from("messages")
        .select("id", {
            count: "exact",
            head: true
        })
        .eq(
            "conversation_id",
            conversationId
        )
        .neq(
            "sender_id",
            user.id
        );

    if (membership.last_read_at) {
        query = query.gt(
            "created_at",
            membership.last_read_at
        );
    }

    const {
        count,
        error
    } = await query;

    if (error) {
        throw error;
    }

    return count || 0;
}

// ------------------------------------------------------------
// Get messages sent by current user
// ------------------------------------------------------------

export async function getMyMessages({
    limit = DEFAULT_LIMIT,
    offset = 0
} = {}) {

    const user = await requireUser();

    const safeLimit = Math.min(
        Math.max(
            Number(limit) || DEFAULT_LIMIT,
            1
        ),
        MAX_LIMIT
    );

    const safeOffset = Math.max(
        Number(offset) || 0,
        0
    );

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .select(`
            id,
            conversation_id,
            sender_id,
            content,
            created_at,
            updated_at
        `)
        .eq(
            "sender_id",
            user.id
        )
        .order("created_at", {
            ascending: false
        })
        .range(
            safeOffset,
            safeOffset + safeLimit - 1
        );

    if (error) {
        throw error;
    }

    return data || [];
}

// ------------------------------------------------------------
// Search messages in current conversation
// ------------------------------------------------------------

export async function searchMessages(
    search,
    conversationId = currentConversationId
) {

    await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const text =
        String(search || "").trim();

    if (!text) {
        return [];
    }

    const member =
        await isConversationMember(
            conversationId
        );

    if (!member) {
        throw new Error(
            "You do not have access to this conversation."
        );
    }

    const {
        data,
        error
    } = await supabase
        .from("messages")
        .select(`
            id,
            conversation_id,
            sender_id,
            content,
            created_at,
            updated_at,
            profiles (
                id,
                username,
                avatar_url
            )
        `)
        .eq(
            "conversation_id",
            conversationId
        )
        .ilike(
            "content",
            `%${text}%`
        )
        .order("created_at", {
            ascending: false
        })
        .limit(50);

    if (error) {
        throw error;
    }

    return data || [];
}

// ------------------------------------------------------------
// Subscribe to current conversation
// ------------------------------------------------------------

export async function subscribeToMessages(
    conversationId = currentConversationId
) {

    const user = await requireUser();

    if (!conversationId) {
        throw new Error(
            "Conversation ID is required."
        );
    }

    const member =
        await isConversationMember(
            conversationId
        );

    if (!member) {
        throw new Error(
            "You do not have access to this conversation."
        );
    }

    await unsubscribeFromMessages();

    realtimeChannel = supabase
        .channel(
            `regenesis-messages-${conversationId}-${user.id}`
        )

        .on(
            "postgres_changes",
            {
                event: "INSERT",
                schema: "public",
                table: "messages",
                filter:
                    `conversation_id=eq.${conversationId}`
            },
            async payload => {

                let message =
                    payload.new;

                /*
                 * Realtime payloads do not automatically
                 * include joined profile information, so
                 * fetch the complete message when needed.
                 */

                try {

                    const fullMessage =
                        await getMessage(
                            payload.new.id
                        );

                    if (fullMessage) {
                        message =
                            fullMessage;
                    }

                } catch (error) {

                    console.warn(
                        "Could not load message profile:",
                        error
                    );
                }

                if (
                    message &&
                    message.conversation_id ===
                        currentConversationId
                ) {

                    messages =
                        deduplicateMessages([
                            ...messages,
                            message
                        ]);
                }

                emit(
                    EVENTS.MESSAGE_SENT,
                    message
                );

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "insert",
                        message
                    }
                );
            }
        )

        .on(
            "postgres_changes",
            {
                event: "UPDATE",
                schema: "public",
                table: "messages",
                filter:
                    `conversation_id=eq.${conversationId}`
            },
            async payload => {

                let message =
                    payload.new;

                try {

                    const fullMessage =
                        await getMessage(
                            payload.new.id
                        );

                    if (fullMessage) {
                        message =
                            fullMessage;
                    }

                } catch (error) {

                    console.warn(
                        "Could not refresh updated message:",
                        error
                    );
                }

                updateCachedMessage(
                    message
                );

                emit(
                    EVENTS.MESSAGE_UPDATED,
                    message
                );

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "update",
                        message
                    }
                );
            }
        )

        .on(
            "postgres_changes",
            {
                event: "DELETE",
                schema: "public",
                table: "messages"
            },
            payload => {

                const deletedId =
                    payload.old?.id;

                if (deletedId) {

                    messages =
                        messages.filter(
                            message =>
                                message.id !==
                                deletedId
                        );
                }

                emit(
                    EVENTS.MESSAGE_DELETED,
                    {
                        id: deletedId,
                        payload
                    }
                );

                emit(
                    EVENTS.CHANGED,
                    {
                        type: "delete",
                        id: deletedId,
                        payload
                    }
                );
            }
        )

        .subscribe(status => {

            if (status === "SUBSCRIBED") {

                console.log(
                    "REGENESIS messages realtime connected."
                );
            }

            if (status === "CHANNEL_ERROR") {

                console.error(
                    "REGENESIS messages realtime error."
                );

                emit(
                    EVENTS.ERROR,
                    new Error(
                        "Realtime messaging channel error."
                    )
                );
            }

            if (status === "TIMED_OUT") {

                console.warn(
                    "REGENESIS messages realtime timed out."
                );
            }
        });

    return realtimeChannel;
}

// ------------------------------------------------------------
// Unsubscribe from messages
// ------------------------------------------------------------

export async function unsubscribeFromMessages() {

    if (!realtimeChannel) {
        return;
    }

    await supabase.removeChannel(
        realtimeChannel
    );

    realtimeChannel = null;
}

// ------------------------------------------------------------
// Refresh messages
// ------------------------------------------------------------

export async function refreshMessages(
    conversationId = currentConversationId
) {

    return await loadMessages({
        conversationId
    });
}

// ------------------------------------------------------------
// Initialize message screen
// ------------------------------------------------------------

export async function initializeMessages(
    conversationId
) {

    await getCurrentUser();

    await setConversation(
        conversationId
    );

    const loaded =
        await loadMessages({
            conversationId
        });

    await markAsRead(
        conversationId
    );

    await subscribeToMessages(
        conversationId
    );

    return loaded;
}

// ------------------------------------------------------------
// Clear local messages
// ------------------------------------------------------------

export function clearMessages() {
    messages = [];

    emit(
        EVENTS.CHANGED,
        {
            type: "cleared"
        }
    );
}

// ------------------------------------------------------------
// Update cached message
// ------------------------------------------------------------

function updateCachedMessage(
    updatedMessage
) {

    if (!updatedMessage?.id) {
        return;
    }

    const index =
        messages.findIndex(
            message =>
                message.id ===
                updatedMessage.id
        );

    if (index === -1) {
        messages.push(
            updatedMessage
        );
        return;
    }

    messages[index] = {
        ...messages[index],
        ...updatedMessage
    };
}

// ------------------------------------------------------------
// Remove duplicate messages
// ------------------------------------------------------------

function deduplicateMessages(
    list
) {

    const map = new Map();

    for (const message of list || []) {

        if (!message?.id) {
            continue;
        }

        map.set(
            message.id,
            message
        );
    }

    return [...map.values()]
        .sort(
            (a, b) =>
                new Date(a.created_at) -
                new Date(b.created_at)
        );
}

// ------------------------------------------------------------
// Get cached messages
// ------------------------------------------------------------

export function getMessages() {
    return [...messages];
}

// ------------------------------------------------------------
// Get message by ID from cache
// ------------------------------------------------------------

export function getCachedMessage(
    messageId
) {

    return (
        messages.find(
            message =>
                message.id === messageId
        ) || null
    );
}

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

export function isLoadingMessages() {
    return loading;
}

export function isSendingMessage() {
    return sending;
}

export function getCachedUser() {
    return currentUser;
}

export function getRealtimeChannel() {
    return realtimeChannel;
}

// ------------------------------------------------------------
// Destroy module
// ------------------------------------------------------------

export async function destroyMessages() {

    await unsubscribeFromMessages();

    listeners.clear();

    currentUser = null;
    currentConversationId = null;
    messages = [];

    loading = false;
    sending = false;
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {

    EVENTS,

    onMessagesChange,

    getCurrentUser,

    validateMessage,

    isConversationMember,

    setConversation,
    getConversationId,

    loadMessages,
    loadOlderMessages,
    loadNewerMessages,

    getMessage,

    sendMessage,
    editMessage,
    deleteMessage,

    markAsRead,
    getUnreadCount,

    getMyMessages,
    searchMessages,

    subscribeToMessages,
    unsubscribeFromMessages,

    refreshMessages,
    initializeMessages,

    clearMessages,

    getMessages,
    getCachedMessage,

    isLoadingMessages,
    isSendingMessage,

    getCachedUser,
    getRealtimeChannel,

    destroyMessages
};