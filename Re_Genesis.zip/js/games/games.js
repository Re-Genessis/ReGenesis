// js/games/games.js
// REGENESIS — Gaming System
// Real Supabase-powered game communities

import { supabase } from "../supabase.js";

/* =========================================================
   CONFIG
========================================================= */

const DEFAULT_LIMIT = 50;

/* =========================================================
   STATE
========================================================= */

let currentUser = null;
let currentGame = null;
let games = [];
let loading = false;
let memberCount = 0;
let isMember = false;
let realtimeChannel = null;

const listeners = new Set();

export const GAME_EVENTS = {
  LOADING: "games:loading",
  LOADED: "games:loaded",
  CREATED: "games:created",
  UPDATED: "games:updated",
  DELETED: "games:deleted",
  JOINED: "games:joined",
  LEFT: "games:left",
  MEMBERS_UPDATED: "games:members-updated",
  ERROR: "games:error",
  CHANGED: "games:changed"
};

/* =========================================================
   EVENT SYSTEM
========================================================= */

function emit(event, detail = {}) {
  listeners.forEach((callback) => {
    try {
      callback(event, detail);
    } catch (error) {
      console.error(
        "Games listener error:",
        error
      );
    }
  });

  if (typeof document !== "undefined") {
    document.dispatchEvent(
      new CustomEvent(`regenesis:${event}`, {
        detail
      })
    );
  }
}

export function onGamesChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

/* =========================================================
   CURRENT USER
========================================================= */

export async function getCurrentUser() {
  const {
    data: { user },
    error
  } = await supabase.auth.getUser();

  if (error) {
    console.error(
      "Failed to get current user:",
      error
    );

    return null;
  }

  currentUser = user || null;

  return currentUser;
}

/* =========================================================
   ADMIN CHECK
========================================================= */

export async function isAdmin(userId = null) {
  let id = userId;

  if (!id) {
    const user =
      currentUser ||
      await getCurrentUser();

    if (!user) {
      return false;
    }

    id = user.id;
  }

  const {
    data,
    error
  } = await supabase
    .from("profiles")
    .select("id, is_admin")
    .eq("id", id)
    .maybeSingle();

  if (error) {
    console.error(
      "Failed to check admin:",
      error
    );

    return false;
  }

  return data?.is_admin === true;
}

/* =========================================================
   LOAD GAMES
========================================================= */

export async function loadGames(options = {}) {
  const {
    search = "",
    limit = DEFAULT_LIMIT,
    offset = 0
  } = options;

  loading = true;

  emit(GAME_EVENTS.LOADING, {
    search
  });

  try {
    let query = supabase
      .from("game_communities")
      .select(`
        id,
        name,
        slug,
        description,
        image_url,
        created_at
      `);

    const searchValue =
      String(search || "").trim();

    /*
      Search by name.
      User input is not placed directly
      inside a raw PostgREST expression.
    */

    if (searchValue) {
      query = query.ilike(
        "name",
        `%${searchValue}%`
      );
    }

    const safeLimit = Math.min(
      Math.max(
        Number(limit) || DEFAULT_LIMIT,
        1
      ),
      100
    );

    const safeOffset = Math.max(
      Number(offset) || 0,
      0
    );

    const {
      data,
      error
    } = await query
      .order("name", {
        ascending: true
      })
      .range(
        safeOffset,
        safeOffset + safeLimit - 1
      );

    if (error) {
      throw error;
    }

    games = data || [];

    emit(GAME_EVENTS.LOADED, {
      games
    });

    return games;
  } catch (error) {
    console.error(
      "Failed to load games:",
      error
    );

    emit(GAME_EVENTS.ERROR, {
      error
    });

    throw error;
  } finally {
    loading = false;
  }
}

/* =========================================================
   GET GAME BY ID
========================================================= */

export async function getGameById(
  gameId
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from("game_communities")
    .select(`
      id,
      name,
      slug,
      description,
      image_url,
      created_at
    `)
    .eq("id", gameId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Game community not found."
    );
  }

  currentGame = data;

  return data;
}

/* =========================================================
   GET GAME BY SLUG
========================================================= */

export async function getGameBySlug(
  slug
) {
  const value =
    String(slug || "").trim();

  if (!value) {
    throw new Error(
      "Game slug is required."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from("game_communities")
    .select(`
      id,
      name,
      slug,
      description,
      image_url,
      created_at
    `)
    .eq("slug", value)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Game community not found."
    );
  }

  currentGame = data;

  return data;
}

/* =========================================================
   GET GAME BY ID OR SLUG
========================================================= */

export async function getGame(
  identifier
) {
  if (!identifier) {
    throw new Error(
      "Game identifier is required."
    );
  }

  /*
    Try ID first.
    If it doesn't exist, try slug.

    This avoids putting user-controlled values
    into a raw .or() expression.
  */

  try {
    const byId =
      await getGameById(
        identifier
      );

    if (byId) {
      return byId;
    }
  } catch {
    // Continue to slug lookup.
  }

  return getGameBySlug(
    identifier
  );
}

/* =========================================================
   SEARCH GAMES
========================================================= */

export async function searchGames(
  search,
  options = {}
) {
  return loadGames({
    ...options,
    search
  });
}

/* =========================================================
   MEMBER COUNT
========================================================= */

export async function getMemberCount(
  gameId
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const {
    count,
    error
  } = await supabase
    .from("game_members")
    .select("id", {
      count: "exact",
      head: true
    })
    .eq(
      "game_id",
      gameId
    );

  if (error) {
    throw error;
  }

  memberCount =
    Number(count || 0);

  return memberCount;
}

/* =========================================================
   CHECK MEMBERSHIP
========================================================= */

export async function checkMembership(
  gameId
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user || !gameId) {
    isMember = false;
    return false;
  }

  const {
    data,
    error
  } = await supabase
    .from("game_members")
    .select("id")
    .eq(
      "game_id",
      gameId
    )
    .eq(
      "user_id",
      user.id
    )
    .maybeSingle();

  if (error) {
    throw error;
  }

  isMember = Boolean(data);

  return isMember;
}

/* =========================================================
   JOIN GAME COMMUNITY
========================================================= */

export async function joinGame(
  gameId
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to join this game community."
    );
  }

  const game =
    currentGame?.id === gameId
      ? currentGame
      : await getGameById(
          gameId
        );

  if (!game) {
    throw new Error(
      "Game community not found."
    );
  }

  const alreadyMember =
    await checkMembership(
      gameId
    );

  if (alreadyMember) {
    return {
      success: true,
      alreadyMember: true
    };
  }

  const {
    data,
    error
  } = await supabase
    .from("game_members")
    .insert({
      game_id: gameId,
      user_id: user.id
    })
    .select(`
      id,
      game_id,
      user_id,
      created_at
    `)
    .single();

  if (error) {
    if (
      error.code === "23505"
    ) {
      isMember = true;

      return {
        success: true,
        alreadyMember: true
      };
    }

    throw error;
  }

  isMember = true;

  await getMemberCount(
    gameId
  );

  emit(GAME_EVENTS.JOINED, {
    game,
    membership: data,
    memberCount
  });

  emit(
    GAME_EVENTS.MEMBERS_UPDATED,
    {
      gameId,
      count: memberCount
    }
  );

  return {
    success: true,
    membership: data,
    count: memberCount
  };
}

/* =========================================================
   LEAVE GAME COMMUNITY
========================================================= */

export async function leaveGame(
  gameId
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const {
    error
  } = await supabase
    .from("game_members")
    .delete()
    .eq(
      "game_id",
      gameId
    )
    .eq(
      "user_id",
      user.id
    );

  if (error) {
    throw error;
  }

  isMember = false;

  await getMemberCount(
    gameId
  );

  emit(GAME_EVENTS.LEFT, {
    gameId,
    memberCount
  });

  emit(
    GAME_EVENTS.MEMBERS_UPDATED,
    {
      gameId,
      count: memberCount
    }
  );

  return {
    success: true,
    count: memberCount
  };
}

/* =========================================================
   GET GAME MEMBERS
========================================================= */

export async function getMembers(
  gameId,
  options = {}
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const {
    limit = 100,
    offset = 0
  } = options;

  const safeLimit = Math.min(
    Math.max(
      Number(limit) || 100,
      1
    ),
    100
  );

  const safeOffset = Math.max(
    Number(offset) || 0,
    0
  );

  const {
    data,
    error
  } = await supabase
    .from("game_members")
    .select(`
      id,
      game_id,
      user_id,
      created_at,
      profiles (
        id,
        username,
        avatar_url
      )
    `)
    .eq(
      "game_id",
      gameId
    )
    .order("created_at", {
      ascending: true
    })
    .range(
      safeOffset,
      safeOffset + safeLimit - 1
    );

  if (error) {
    throw error;
  }

  return data || [];
}

/* =========================================================
   GET GAME POSTS
========================================================= */

export async function getGamePosts(
  gameId,
  options = {}
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const {
    limit = 50,
    offset = 0
  } = options;

  const safeLimit = Math.min(
    Math.max(
      Number(limit) || 50,
      1
    ),
    100
  );

  const safeOffset = Math.max(
    Number(offset) || 0,
    0
  );

  const {
    data,
    error
  } = await supabase
    .from("game_posts")
    .select(`
      id,
      game_id,
      user_id,
      content,
      created_at,
      profiles (
        id,
        username,
        avatar_url
      )
    `)
    .eq(
      "game_id",
      gameId
    )
    .order("created_at", {
      ascending: false
    })
    .range(
      safeOffset,
      safeOffset + safeLimit - 1
    );

  if (error) {
    throw error;
  }

  return data || [];
}

/* =========================================================
   CREATE GAME POST
========================================================= */

export async function createGamePost(
  gameId,
  content
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const cleanContent =
    String(
      content || ""
    ).trim();

  if (!cleanContent) {
    throw new Error(
      "Post content cannot be empty."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to post."
    );
  }

  const member =
    await checkMembership(
      gameId
    );

  if (!member) {
    throw new Error(
      "You must join this game community before posting."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from("game_posts")
    .insert({
      game_id: gameId,
      user_id: user.id,
      content: cleanContent
    })
    .select(`
      id,
      game_id,
      user_id,
      content,
      created_at,
      profiles (
        id,
        username,
        avatar_url
      )
    `)
    .single();

  if (error) {
    throw error;
  }

  emit(GAME_EVENTS.CHANGED, {
    type: "post-created",
    post: data
  });

  return data;
}

/* =========================================================
   DELETE GAME POST
========================================================= */

export async function deleteGamePost(
  postId
) {
  if (!postId) {
    throw new Error(
      "Post ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const {
    error
  } = await supabase
    .from("game_posts")
    .delete()
    .eq(
      "id",
      postId
    )
    .eq(
      "user_id",
      user.id
    );

  if (error) {
    throw error;
  }

  emit(GAME_EVENTS.CHANGED, {
    type: "post-deleted",
    postId
  });

  return {
    success: true
  };
}

/* =========================================================
   CREATE GAME COMMUNITY
========================================================= */

export async function createGame(
  gameData
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(
      user.id
    );

  if (!admin) {
    throw new Error(
      "Only administrators can create game communities."
    );
  }

  const name =
    String(
      gameData?.name || ""
    ).trim();

  const description =
    String(
      gameData?.description || ""
    ).trim();

  const slug =
    String(
      gameData?.slug || ""
    ).trim();

  if (!name) {
    throw new Error(
      "Game name is required."
    );
  }

  if (!slug) {
    throw new Error(
      "Game slug is required."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from("game_communities")
    .insert({
      name,
      slug,
      description:
        description || null,
      image_url:
        gameData?.image_url
          ? String(
              gameData.image_url
            ).trim()
          : null
    })
    .select(`
      id,
      name,
      slug,
      description,
      image_url,
      created_at
    `)
    .single();

  if (error) {
    throw error;
  }

  games.push(data);

  emit(GAME_EVENTS.CREATED, {
    game: data
  });

  return data;
}

/* =========================================================
   UPDATE GAME
========================================================= */

export async function updateGame(
  gameId,
  updates = {}
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(
      user.id
    );

  if (!admin) {
    throw new Error(
      "Only administrators can update game communities."
    );
  }

  const allowedFields = [
    "name",
    "slug",
    "description",
    "image_url"
  ];

  const cleanUpdates = {};

  for (
    const field of allowedFields
  ) {
    if (
      Object.prototype.hasOwnProperty.call(
        updates,
        field
      )
    ) {
      cleanUpdates[field] =
        updates[field];
    }
  }

  if (
    cleanUpdates.name !== undefined
  ) {
    cleanUpdates.name =
      String(
        cleanUpdates.name
      ).trim();

    if (!cleanUpdates.name) {
      throw new Error(
        "Game name cannot be empty."
      );
    }
  }

  if (
    cleanUpdates.slug !== undefined
  ) {
    cleanUpdates.slug =
      String(
        cleanUpdates.slug
      ).trim();

    if (!cleanUpdates.slug) {
      throw new Error(
        "Game slug cannot be empty."
      );
    }
  }

  if (
    cleanUpdates.description !==
    undefined
  ) {
    cleanUpdates.description =
      String(
        cleanUpdates.description ||
          ""
      ).trim() || null;
  }

  const {
    data,
    error
  } = await supabase
    .from("game_communities")
    .update(cleanUpdates)
    .eq(
      "id",
      gameId
    )
    .select(`
      id,
      name,
      slug,
      description,
      image_url,
      created_at
    `)
    .single();

  if (error) {
    throw error;
  }

  currentGame = data;

  games =
    games.map(
      (game) =>
        game.id === gameId
          ? data
          : game
    );

  emit(GAME_EVENTS.UPDATED, {
    game: data
  });

  return data;
}

/* =========================================================
   DELETE GAME
========================================================= */

export async function deleteGame(
  gameId
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(
      user.id
    );

  if (!admin) {
    throw new Error(
      "Only administrators can delete game communities."
    );
  }

  const {
    error
  } = await supabase
    .from("game_communities")
    .delete()
    .eq(
      "id",
      gameId
    );

  if (error) {
    throw error;
  }

  games =
    games.filter(
      (game) =>
        game.id !== gameId
    );

  if (
    currentGame?.id === gameId
  ) {
    currentGame = null;
  }

  emit(GAME_EVENTS.DELETED, {
    gameId
  });

  return {
    success: true
  };
}

/* =========================================================
   REALTIME
========================================================= */

export function subscribeToGames(
  gameId = null
) {
  if (realtimeChannel) {
    supabase.removeChannel(
      realtimeChannel
    );

    realtimeChannel = null;
  }

  const channelName =
    gameId
      ? `regenesis-game-${gameId}`
      : "regenesis-games";

  realtimeChannel =
    supabase.channel(
      channelName
    );

  /*
    Game community changes
  */

  realtimeChannel.on(
    "postgres_changes",
    {
      event: "*",
      schema: "public",
      table: "game_communities",
      ...(gameId
        ? {
            filter:
              `id=eq.${gameId}`
          }
        : {})
    },
    (payload) => {
      emit(
        GAME_EVENTS.CHANGED,
        {
          type: "community",
          payload
        }
      );
    }
  );

  /*
    Membership changes
  */

  realtimeChannel.on(
    "postgres_changes",
    {
      event: "*",
      schema: "public",
      table: "game_members",
      ...(gameId
        ? {
            filter:
              `game_id=eq.${gameId}`
          }
        : {})
    },
    async () => {
      if (gameId) {
        try {
          await getMemberCount(
            gameId
          );

          if (currentUser) {
            await checkMembership(
              gameId
            );
          }

          emit(
            GAME_EVENTS.MEMBERS_UPDATED,
            {
              gameId,
              count:
                memberCount,
              isMember
            }
          );
        } catch (error) {
          console.error(
            "Failed to refresh game members:",
            error
          );
        }
      }
    }
  );

  /*
    Game post changes
  */

  realtimeChannel.on(
    "postgres_changes",
    {
      event: "*",
      schema: "public",
      table: "game_posts",
      ...(gameId
        ? {
            filter:
              `game_id=eq.${gameId}`
          }
        : {})
    },
    (payload) => {
      emit(
        GAME_EVENTS.CHANGED,
        {
          type: "post",
          payload
        }
      );
    }
  );

  realtimeChannel.subscribe(
    (status) => {
      console.log(
        "Games realtime:",
        status
      );
    }
  );

  return realtimeChannel;
}

/* =========================================================
   UNSUBSCRIBE
========================================================= */

export async function unsubscribeFromGames() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "Failed to remove games realtime:",
      error
    );
  }

  realtimeChannel = null;
}

/* =========================================================
   REFRESH GAME
========================================================= */

export async function refreshGame(
  gameId
) {
  const game =
    await getGameById(
      gameId
    );

  await getMemberCount(
    gameId
  );

  if (currentUser) {
    await checkMembership(
      gameId
    );
  }

  return {
    game,
    memberCount,
    isMember
  };
}

/* =========================================================
   INITIALIZE GAME
========================================================= */

export async function initializeGame(
  gameId
) {
  if (!gameId) {
    throw new Error(
      "Game ID is required."
    );
  }

  await getCurrentUser();

  const state =
    await refreshGame(
      gameId
    );

  subscribeToGames(
    gameId
  );

  return state;
}

/* =========================================================
   STATE GETTERS
========================================================= */

export function getGames() {
  return [...games];
}

export function getCurrentGame() {
  return currentGame;
}

export function getMemberTotal() {
  return memberCount;
}

export function getMembershipStatus() {
  return isMember;
}

export function getUser() {
  return currentUser;
}

export function isLoading() {
  return loading;
}

/* =========================================================
   CLEANUP
========================================================= */

export async function destroyGames() {
  await unsubscribeFromGames();

  currentUser = null;
  currentGame = null;
  games = [];
  memberCount = 0;
  isMember = false;
  loading = false;

  listeners.clear();
}

/* =========================================================
   DEFAULT EXPORT
========================================================= */

export default {
  GAME_EVENTS,

  onGamesChange,

  getCurrentUser,
  getUser,

  isAdmin,

  loadGames,
  searchGames,

  getGame,
  getGameById,
  getGameBySlug,

  getMemberCount,
  checkMembership,

  joinGame,
  leaveGame,

  getMembers,
  getGamePosts,
  createGamePost,
  deleteGamePost,

  createGame,
  updateGame,
  deleteGame,

  subscribeToGames,
  unsubscribeFromGames,

  refreshGame,
  initializeGame,
  destroyGames,

  getGames,
  getCurrentGame,
  getMemberTotal,
  getMembershipStatus,
  isLoading
};