// js/event/event.js
// REGENESIS — Events System
// Real Supabase-powered event management

import { supabase } from "../supabase.js";

/* =========================================================
   STATE
========================================================= */

let currentUser = null;
let currentEvent = null;
let events = [];
let attendeeCount = 0;
let attending = false;
let realtimeChannel = null;

const listeners = new Set();

export const EVENT_EVENTS = {
  LOADING: "event:loading",
  LOADED: "event:loaded",
  CREATED: "event:created",
  UPDATED: "event:updated",
  DELETED: "event:deleted",
  JOINED: "event:joined",
  LEFT: "event:left",
  ATTENDEES_UPDATED: "event:attendees-updated",
  ERROR: "event:error"
};

/* =========================================================
   EVENT LISTENERS
========================================================= */

function emit(event, detail = {}) {
  listeners.forEach((callback) => {
    try {
      callback(event, detail);
    } catch (error) {
      console.error(
        "Event listener error:",
        error
      );
    }
  });

  if (typeof document !== "undefined") {
    document.dispatchEvent(
      new CustomEvent(`regenesis:${event}`, {
        detail
      })
    );
  }
}

export function onEventChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

/* =========================================================
   CURRENT USER
========================================================= */

export async function getCurrentUser() {
  const {
    data: { user },
    error
  } = await supabase.auth.getUser();

  if (error) {
    console.error(
      "Failed to get current user:",
      error
    );

    return null;
  }

  currentUser = user || null;

  return currentUser;
}

/* =========================================================
   ADMIN CHECK
========================================================= */

export async function isAdmin(userId = null) {
  let id = userId;

  if (!id) {
    const user = currentUser ||
      await getCurrentUser();

    if (!user) {
      return false;
    }

    id = user.id;
  }

  const { data, error } = await supabase
    .from("profiles")
    .select("id, is_admin")
    .eq("id", id)
    .maybeSingle();

  if (error) {
    console.error(
      "Failed to check admin status:",
      error
    );

    return false;
  }

  return data?.is_admin === true;
}

/* =========================================================
   LOAD EVENT BY ID
========================================================= */

export async function getEvent(eventId) {
  if (!eventId) {
    throw new Error(
      "Event ID is required."
    );
  }

  emit(EVENT_EVENTS.LOADING, {
    eventId
  });

  const { data, error } = await supabase
    .from("events")
    .select(`
      id,
      title,
      description,
      location,
      starts_at,
      ends_at,
      image_url,
      status,
      created_by,
      created_at
    `)
    .eq("id", eventId)
    .maybeSingle();

  if (error) {
    emit(EVENT_EVENTS.ERROR, {
      error
    });

    throw error;
  }

  if (!data) {
    currentEvent = null;

    throw new Error(
      "Event not found."
    );
  }

  currentEvent = data;

  emit(EVENT_EVENTS.LOADED, {
    event: data
  });

  return data;
}

/* =========================================================
   LOAD ALL EVENTS
========================================================= */

export async function loadEvents(options = {}) {
  const {
    status = "",
    search = "",
    limit = 50
  } = options;

  emit(EVENT_EVENTS.LOADING, {});

  try {
    let query = supabase
      .from("events")
      .select(`
        id,
        title,
        description,
        location,
        starts_at,
        ends_at,
        image_url,
        status,
        created_by,
        created_at
      `);

    if (status) {
      query = query.eq(
        "status",
        status
      );
    }

    const searchValue =
      String(search || "").trim();

    /*
      Search is performed against one safe
      column to avoid constructing a raw
      PostgREST .or() expression from user input.
    */

    if (searchValue) {
      query = query.ilike(
        "title",
        `%${searchValue}%`
      );
    }

    const safeLimit = Math.min(
      Math.max(
        Number(limit) || 50,
        1
      ),
      100
    );

    const {
      data,
      error
    } = await query
      .order("starts_at", {
        ascending: true
      })
      .limit(safeLimit);

    if (error) {
      throw error;
    }

    events = data || [];

    emit(EVENT_EVENTS.LOADED, {
      events
    });

    return events;
  } catch (error) {
    console.error(
      "Failed to load events:",
      error
    );

    emit(EVENT_EVENTS.ERROR, {
      error
    });

    throw error;
  }
}

/* =========================================================
   GET EVENT ATTENDEE COUNT
========================================================= */

export async function getAttendeeCount(
  eventId
) {
  if (!eventId) {
    return 0;
  }

  const {
    count,
    error
  } = await supabase
    .from("event_attendees")
    .select("id", {
      count: "exact",
      head: true
    })
    .eq(
      "event_id",
      eventId
    );

  if (error) {
    throw error;
  }

  attendeeCount = Number(
    count || 0
  );

  return attendeeCount;
}

/* =========================================================
   CHECK ATTENDANCE
========================================================= */

export async function isAttending(
  eventId
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user || !eventId) {
    attending = false;
    return false;
  }

  const {
    data,
    error
  } = await supabase
    .from("event_attendees")
    .select("id")
    .eq(
      "event_id",
      eventId
    )
    .eq(
      "user_id",
      user.id
    )
    .maybeSingle();

  if (error) {
    throw error;
  }

  attending = Boolean(data);

  return attending;
}

/* =========================================================
   EVENT STATUS
========================================================= */

export function getEventStatus(
  event = currentEvent
) {
  if (!event) {
    return "unknown";
  }

  if (
    event.status === "cancelled"
  ) {
    return "cancelled";
  }

  const now = Date.now();

  const start =
    event.starts_at
      ? new Date(
          event.starts_at
        ).getTime()
      : null;

  const end =
    event.ends_at
      ? new Date(
          event.ends_at
        ).getTime()
      : null;

  if (
    start &&
    now < start
  ) {
    return "upcoming";
  }

  if (
    start &&
    end &&
    now >= start &&
    now <= end
  ) {
    return "ongoing";
  }

  if (
    end &&
    now > end
  ) {
    return "past";
  }

  return event.status || "upcoming";
}

/* =========================================================
   CAN JOIN
========================================================= */

export function canJoinEvent(
  event = currentEvent
) {
  if (!event) {
    return false;
  }

  const status =
    getEventStatus(event);

  return (
    status !== "past" &&
    status !== "cancelled"
  );
}

/* =========================================================
   JOIN EVENT
========================================================= */

export async function joinEvent(
  eventId
) {
  if (!eventId) {
    throw new Error(
      "Event ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to join an event."
    );
  }

  const event =
    currentEvent?.id === eventId
      ? currentEvent
      : await getEvent(eventId);

  if (!canJoinEvent(event)) {
    throw new Error(
      "This event is no longer accepting attendees."
    );
  }

  const alreadyAttending =
    await isAttending(eventId);

  if (alreadyAttending) {
    return {
      success: true,
      alreadyJoined: true
    };
  }

  const {
    data,
    error
  } = await supabase
    .from("event_attendees")
    .insert({
      event_id: eventId,
      user_id: user.id
    })
    .select(`
      id,
      event_id,
      user_id,
      created_at
    `)
    .single();

  if (error) {
    /*
      Unique constraint:
      (event_id, user_id)
    */

    if (
      error.code === "23505"
    ) {
      attending = true;

      return {
        success: true,
        alreadyJoined: true
      };
    }

    throw error;
  }

  attending = true;

  await getAttendeeCount(
    eventId
  );

  emit(EVENT_EVENTS.JOINED, {
    event,
    attendee: data,
    attendeeCount
  });

  emit(
    EVENT_EVENTS.ATTENDEES_UPDATED,
    {
      eventId,
      count: attendeeCount
    }
  );

  return {
    success: true,
    attendee: data,
    count: attendeeCount
  };
}

/* =========================================================
   LEAVE EVENT
========================================================= */

export async function leaveEvent(
  eventId
) {
  if (!eventId) {
    throw new Error(
      "Event ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const {
    error
  } = await supabase
    .from("event_attendees")
    .delete()
    .eq(
      "event_id",
      eventId
    )
    .eq(
      "user_id",
      user.id
    );

  if (error) {
    throw error;
  }

  attending = false;

  await getAttendeeCount(
    eventId
  );

  emit(EVENT_EVENTS.LEFT, {
    eventId,
    attendeeCount
  });

  emit(
    EVENT_EVENTS.ATTENDEES_UPDATED,
    {
      eventId,
      count: attendeeCount
    }
  );

  return {
    success: true,
    count: attendeeCount
  };
}

/* =========================================================
   CREATE EVENT
========================================================= */

export async function createEvent(
  eventData
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(user.id);

  if (!admin) {
    throw new Error(
      "Only administrators can create events."
    );
  }

  if (!eventData?.title) {
    throw new Error(
      "Event title is required."
    );
  }

  if (!eventData?.description) {
    throw new Error(
      "Event description is required."
    );
  }

  if (!eventData?.starts_at) {
    throw new Error(
      "Event start time is required."
    );
  }

  if (!eventData?.ends_at) {
    throw new Error(
      "Event end time is required."
    );
  }

  const start =
    new Date(
      eventData.starts_at
    );

  const end =
    new Date(
      eventData.ends_at
    );

  if (
    Number.isNaN(start.getTime()) ||
    Number.isNaN(end.getTime())
  ) {
    throw new Error(
      "Invalid event date."
    );
  }

  if (
    end <= start
  ) {
    throw new Error(
      "Event end time must be after the start time."
    );
  }

  const allowedStatuses = [
    "upcoming",
    "ongoing",
    "past",
    "cancelled"
  ];

  const status =
    allowedStatuses.includes(
      eventData.status
    )
      ? eventData.status
      : "upcoming";

  const {
    data,
    error
  } = await supabase
    .from("events")
    .insert({
      title:
        String(
          eventData.title
        ).trim(),

      description:
        String(
          eventData.description
        ).trim(),

      location:
        eventData.location
          ? String(
              eventData.location
            ).trim()
          : null,

      starts_at:
        start.toISOString(),

      ends_at:
        end.toISOString(),

      image_url:
        eventData.image_url
          ? String(
              eventData.image_url
            ).trim()
          : null,

      status,

      created_by:
        user.id
    })
    .select(`
      id,
      title,
      description,
      location,
      starts_at,
      ends_at,
      image_url,
      status,
      created_by,
      created_at
    `)
    .single();

  if (error) {
    throw error;
  }

  currentEvent = data;

  events = [
    data,
    ...events.filter(
      (item) =>
        item.id !== data.id
    )
  ];

  emit(EVENT_EVENTS.CREATED, {
    event: data
  });

  return data;
}

/* =========================================================
   UPDATE EVENT
========================================================= */

export async function updateEvent(
  eventId,
  updates
) {
  if (!eventId) {
    throw new Error(
      "Event ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(user.id);

  if (!admin) {
    throw new Error(
      "Only administrators can update events."
    );
  }

  const allowedFields = [
    "title",
    "description",
    "location",
    "starts_at",
    "ends_at",
    "image_url",
    "status"
  ];

  const cleanUpdates = {};

  for (const field of allowedFields) {
    if (
      Object.prototype.hasOwnProperty.call(
        updates || {},
        field
      )
    ) {
      cleanUpdates[field] =
        updates[field];
    }
  }

  if (
    cleanUpdates.starts_at &&
    cleanUpdates.ends_at
  ) {
    const start =
      new Date(
        cleanUpdates.starts_at
      );

    const end =
      new Date(
        cleanUpdates.ends_at
      );

    if (
      end <= start
    ) {
      throw new Error(
        "Event end time must be after the start time."
      );
    }

    cleanUpdates.starts_at =
      start.toISOString();

    cleanUpdates.ends_at =
      end.toISOString();
  }

  const {
    data,
    error
  } = await supabase
    .from("events")
    .update(cleanUpdates)
    .eq(
      "id",
      eventId
    )
    .select(`
      id,
      title,
      description,
      location,
      starts_at,
      ends_at,
      image_url,
      status,
      created_by,
      created_at
    `)
    .single();

  if (error) {
    throw error;
  }

  currentEvent = data;

  events = events.map(
    (event) =>
      event.id === eventId
        ? data
        : event
  );

  emit(EVENT_EVENTS.UPDATED, {
    event: data
  });

  return data;
}

/* =========================================================
   DELETE EVENT
========================================================= */

export async function deleteEvent(
  eventId
) {
  if (!eventId) {
    throw new Error(
      "Event ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(user.id);

  if (!admin) {
    throw new Error(
      "Only administrators can delete events."
    );
  }

  const {
    error
  } = await supabase
    .from("events")
    .delete()
    .eq(
      "id",
      eventId
    );

  if (error) {
    throw error;
  }

  events = events.filter(
    (event) =>
      event.id !== eventId
  );

  if (
    currentEvent?.id === eventId
  ) {
    currentEvent = null;
  }

  emit(EVENT_EVENTS.DELETED, {
    eventId
  });

  return {
    success: true
  };
}

/* =========================================================
   GET ATTENDEES
========================================================= */

export async function getAttendees(
  eventId
) {
  if (!eventId) {
    throw new Error(
      "Event ID is required."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from("event_attendees")
    .select(`
      id,
      event_id,
      user_id,
      created_at,
      profiles (
        id,
        username,
        avatar_url
      )
    `)
    .eq(
      "event_id",
      eventId
    )
    .order(
      "created_at",
      {
        ascending: true
      }
    );

  if (error) {
    throw error;
  }

  return data || [];
}

/* =========================================================
   REALTIME
========================================================= */

export function subscribeToEvent(
  eventId
) {
  if (!eventId) {
    return null;
  }

  if (realtimeChannel) {
    supabase.removeChannel(
      realtimeChannel
    );

    realtimeChannel = null;
  }

  realtimeChannel = supabase
    .channel(
      `regenesis-event-${eventId}`
    )

    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "events",
        filter:
          `id=eq.${eventId}`
      },
      async (payload) => {
        emit(
          EVENT_EVENTS.UPDATED,
          {
            payload
          }
        );

        try {
          if (
            payload.eventType ===
            "DELETE"
          ) {
            currentEvent = null;
            return;
          }

          if (
            payload.new?.id === eventId
          ) {
            currentEvent =
              payload.new;
          }
        } catch (error) {
          console.error(
            "Event realtime update error:",
            error
          );
        }
      }
    )

    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "event_attendees",
        filter:
          `event_id=eq.${eventId}`
      },
      async () => {
        try {
          attendeeCount =
            await getAttendeeCount(
              eventId
            );

          if (currentUser) {
            attending =
              await isAttending(
                eventId
              );
          }

          emit(
            EVENT_EVENTS.ATTENDEES_UPDATED,
            {
              eventId,
              count:
                attendeeCount,
              attending
            }
          );
        } catch (error) {
          console.error(
            "Attendee realtime update error:",
            error
          );
        }
      }
    )

    .subscribe((status) => {
      console.log(
        "Event realtime:",
        status
      );
    });

  return realtimeChannel;
}

/* =========================================================
   UNSUBSCRIBE
========================================================= */

export async function unsubscribeFromEvent() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "Failed to remove event realtime:",
      error
    );
  }

  realtimeChannel = null;
}

/* =========================================================
   REFRESH EVENT
========================================================= */

export async function refreshEvent(
  eventId
) {
  const event =
    await getEvent(eventId);

  await getAttendeeCount(
    eventId
  );

  if (currentUser) {
    await isAttending(
      eventId
    );
  }

  return {
    event,
    attendeeCount,
    attending
  };
}

/* =========================================================
   STATE GETTERS
========================================================= */

export function getCurrentEvent() {
  return currentEvent;
}

export function getEvents() {
  return [...events];
}

export function getCurrentAttendeeCount() {
  return attendeeCount;
}

export function getCurrentAttendance() {
  return attending;
}

export function getUser() {
  return currentUser;
}

/* =========================================================
   INITIALIZE
========================================================= */

export async function initializeEvent(
  eventId
) {
  if (!eventId) {
    throw new Error(
      "Event ID is required."
    );
  }

  await getCurrentUser();

  const state =
    await refreshEvent(
      eventId
    );

  subscribeToEvent(
    eventId
  );

  return state;
}

/* =========================================================
   CLEANUP
========================================================= */

export async function destroyEvent() {
  await unsubscribeFromEvent();

  currentUser = null;
  currentEvent = null;
  attendeeCount = 0;
  attending = false;

  listeners.clear();
}

/* =========================================================
   DEFAULT EXPORT
========================================================= */

export default {
  EVENT_EVENTS,

  onEventChange,

  getCurrentUser,
  isAdmin,

  getEvent,
  loadEvents,

  getAttendeeCount,
  getAttendees,

  isAttending,

  getEventStatus,
  canJoinEvent,

  joinEvent,
  leaveEvent,

  createEvent,
  updateEvent,
  deleteEvent,

  subscribeToEvent,
  unsubscribeFromEvent,

  refreshEvent,
  initializeEvent,
  destroyEvent,

  getCurrentEvent,
  getEvents,
  getCurrentAttendeeCount,
  getCurrentAttendance,
  getUser
};