// ============================================================
// REGENESIS - Social Follows
// File: js/social/follows.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 30;
const MAX_LIMIT = 100;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;

let following = [];
let followers = [];

let followingIds = new Set();
let followerIds = new Set();

let loading = false;
let realtimeChannels = [];

const listeners = new Set();

// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",

  FOLLOWING_LOADED: "following_loaded",
  FOLLOWERS_LOADED: "followers_loaded",

  FOLLOWED: "followed",
  UNFOLLOWED: "unfollowed",

  FOLLOWERS_UPDATED: "followers_updated",
  FOLLOWING_UPDATED: "following_updated",

  CHANGED: "changed",
  ERROR: "error"
};

// ------------------------------------------------------------
// Event listener system
// ------------------------------------------------------------

export function onFollowsChange(callback) {
  if (typeof callback !== "function") {
    throw new TypeError("callback must be a function");
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(type, payload = {}) {
  const event = {
    type,
    ...payload
  };

  listeners.forEach((callback) => {
    try {
      callback(event);
    } catch (error) {
      console.error("REGENESIS follows listener error:", error);
    }
  });
}

// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const { data, error } = await supabase.auth.getUser();

  if (error) {
    currentUser = null;
    return null;
  }

  currentUser = data?.user || null;
  return currentUser;
}

async function requireUser() {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error("You must be logged in to use follows.");
  }

  return user;
}

// ------------------------------------------------------------
// Validation
// ------------------------------------------------------------

function validateUserId(userId) {
  if (!userId || typeof userId !== "string") {
    throw new Error("A valid user ID is required.");
  }

  return userId.trim();
}

function normalizeLimit(limit) {
  const value = Number(limit);

  if (!Number.isFinite(value)) {
    return DEFAULT_LIMIT;
  }

  return Math.min(
    Math.max(Math.floor(value), 1),
    MAX_LIMIT
  );
}

// ------------------------------------------------------------
// Follow status
// ------------------------------------------------------------

/**
 * Check whether the current user follows another user.
 */
export async function isFollowing(userId) {
  const user = await requireUser();
  const targetId = validateUserId(userId);

  if (user.id === targetId) {
    return false;
  }

  if (followingIds.has(targetId)) {
    return true;
  }

  const { data, error } = await supabase
    .from("follows")
    .select("id")
    .eq("follower_id", user.id)
    .eq("following_id", targetId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  const result = Boolean(data);

  if (result) {
    followingIds.add(targetId);
  }

  return result;
}

// ------------------------------------------------------------
// Follow a user
// ------------------------------------------------------------

export async function followUser(userId) {
  const user = await requireUser();
  const targetId = validateUserId(userId);

  if (user.id === targetId) {
    throw new Error("You cannot follow yourself.");
  }

  const alreadyFollowing = await isFollowing(targetId);

  if (alreadyFollowing) {
    return {
      success: true,
      alreadyFollowing: true
    };
  }

  const { data, error } = await supabase
    .from("follows")
    .insert({
      follower_id: user.id,
      following_id: targetId
    })
    .select()
    .single();

  if (error) {
    // PostgreSQL unique violation.
    if (error.code === "23505") {
      followingIds.add(targetId);

      return {
        success: true,
        alreadyFollowing: true
      };
    }

    emit(EVENTS.ERROR, {
      action: "follow",
      error
    });

    throw error;
  }

  followingIds.add(targetId);

  emit(EVENTS.FOLLOWED, {
    userId: targetId,
    follow: data
  });

  emit(EVENTS.CHANGED, {
    action: "followed",
    userId: targetId
  });

  return {
    success: true,
    alreadyFollowing: false,
    data
  };
}

// ------------------------------------------------------------
// Unfollow a user
// ------------------------------------------------------------

export async function unfollowUser(userId) {
  const user = await requireUser();
  const targetId = validateUserId(userId);

  if (user.id === targetId) {
    throw new Error("You cannot unfollow yourself.");
  }

  const { error } = await supabase
    .from("follows")
    .delete()
    .eq("follower_id", user.id)
    .eq("following_id", targetId);

  if (error) {
    emit(EVENTS.ERROR, {
      action: "unfollow",
      error
    });

    throw error;
  }

  followingIds.delete(targetId);

  following = following.filter(
    (item) => item.id !== targetId
  );

  emit(EVENTS.UNFOLLOWED, {
    userId: targetId
  });

  emit(EVENTS.CHANGED, {
    action: "unfollowed",
    userId: targetId
  });

  return {
    success: true,
    userId: targetId
  };
}

// ------------------------------------------------------------
// Toggle follow
// ------------------------------------------------------------

export async function toggleFollow(userId) {
  const targetId = validateUserId(userId);

  const status = await isFollowing(targetId);

  if (status) {
    return unfollowUser(targetId);
  }

  return followUser(targetId);
}

// ------------------------------------------------------------
// Get follower count
// ------------------------------------------------------------

export async function getFollowerCount(userId) {
  const targetId = validateUserId(userId);

  const { count, error } = await supabase
    .from("follows")
    .select("id", {
      count: "exact",
      head: true
    })
    .eq("following_id", targetId);

  if (error) {
    throw error;
  }

  return count || 0;
}

// ------------------------------------------------------------
// Get following count
// ------------------------------------------------------------

export async function getFollowingCount(userId) {
  const targetId = validateUserId(userId);

  const { count, error } = await supabase
    .from("follows")
    .select("id", {
      count: "exact",
      head: true
    })
    .eq("follower_id", targetId);

  if (error) {
    throw error;
  }

  return count || 0;
}

// ------------------------------------------------------------
// Get both counts
// ------------------------------------------------------------

export async function getFollowCounts(userId) {
  const targetId = validateUserId(userId);

  const [followersResult, followingResult] = await Promise.all([
    supabase
      .from("follows")
      .select("id", {
        count: "exact",
        head: true
      })
      .eq("following_id", targetId),

    supabase
      .from("follows")
      .select("id", {
        count: "exact",
        head: true
      })
      .eq("follower_id", targetId)
  ]);

  if (followersResult.error) {
    throw followersResult.error;
  }

  if (followingResult.error) {
    throw followingResult.error;
  }

  return {
    followers: followersResult.count || 0,
    following: followingResult.count || 0
  };
}

// ------------------------------------------------------------
// Load following
// ------------------------------------------------------------

export async function loadFollowing(
  userId = null,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  const user = userId
    ? { id: validateUserId(userId) }
    : await requireUser();

  const safeLimit = normalizeLimit(limit);
  const safeOffset = Math.max(Number(offset) || 0, 0);

  loading = true;

  emit(EVENTS.LOADING, {
    type: "following"
  });

  try {
    const { data, error } = await supabase
      .from("follows")
      .select(`
        id,
        follower_id,
        following_id,
        created_at,
        profile:profiles!follows_following_id_fkey (
          id,
          username,
          display_name,
          avatar_url
        )
      `)
      .eq("follower_id", user.id)
      .order("created_at", {
        ascending: false
      })
      .range(
        safeOffset,
        safeOffset + safeLimit - 1
      );

    if (error) {
      throw error;
    }

    following = data || [];

    if (safeOffset === 0) {
      followingIds = new Set(
        following.map((item) => item.following_id)
      );
    } else {
      following.forEach((item) => {
        followingIds.add(item.following_id);
      });
    }

    emit(EVENTS.FOLLOWING_LOADED, {
      data: following
    });

    emit(EVENTS.LOADED, {
      type: "following",
      data: following
    });

    return following;
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "loadFollowing",
      error
    });

    throw error;
  } finally {
    loading = false;
  }
}

// ------------------------------------------------------------
// Load followers
// ------------------------------------------------------------

export async function loadFollowers(
  userId = null,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  const user = userId
    ? { id: validateUserId(userId) }
    : await requireUser();

  const safeLimit = normalizeLimit(limit);
  const safeOffset = Math.max(Number(offset) || 0, 0);

  loading = true;

  emit(EVENTS.LOADING, {
    type: "followers"
  });

  try {
    const { data, error } = await supabase
      .from("follows")
      .select(`
        id,
        follower_id,
        following_id,
        created_at,
        profile:profiles!follows_follower_id_fkey (
          id,
          username,
          display_name,
          avatar_url
        )
      `)
      .eq("following_id", user.id)
      .order("created_at", {
        ascending: false
      })
      .range(
        safeOffset,
        safeOffset + safeLimit - 1
      );

    if (error) {
      throw error;
    }

    followers = data || [];

    if (safeOffset === 0) {
      followerIds = new Set(
        followers.map((item) => item.follower_id)
      );
    } else {
      followers.forEach((item) => {
        followerIds.add(item.follower_id);
      });
    }

    emit(EVENTS.FOLLOWERS_LOADED, {
      data: followers
    });

    emit(EVENTS.LOADED, {
      type: "followers",
      data: followers
    });

    return followers;
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "loadFollowers",
      error
    });

    throw error;
  } finally {
    loading = false;
  }
}

// ------------------------------------------------------------
// Check if one user follows another
// ------------------------------------------------------------

export async function checkFollowStatus(
  followerId,
  followingId
) {
  const follower = validateUserId(followerId);
  const followingUser = validateUserId(followingId);

  if (follower === followingUser) {
    return false;
  }

  const { data, error } = await supabase
    .from("follows")
    .select("id")
    .eq("follower_id", follower)
    .eq("following_id", followingUser)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return Boolean(data);
}

// ------------------------------------------------------------
// Get users who follow a user
// ------------------------------------------------------------

export async function getFollowers(
  userId,
  options = {}
) {
  return loadFollowers(userId, options);
}

// ------------------------------------------------------------
// Get users a user follows
// ------------------------------------------------------------

export async function getFollowing(
  userId,
  options = {}
) {
  return loadFollowing(userId, options);
}

// ------------------------------------------------------------
// Mutual following
// ------------------------------------------------------------

export async function areMutualFollowers(
  userA,
  userB
) {
  const first = validateUserId(userA);
  const second = validateUserId(userB);

  if (first === second) {
    return false;
  }

  const [aFollowsB, bFollowsA] = await Promise.all([
    checkFollowStatus(first, second),
    checkFollowStatus(second, first)
  ]);

  return aFollowsB && bFollowsA;
}

// ------------------------------------------------------------
// Get people who follow both users
// ------------------------------------------------------------

export async function getMutualFollowers(
  userA,
  userB,
  {
    limit = DEFAULT_LIMIT
  } = {}
) {
  const first = validateUserId(userA);
  const second = validateUserId(userB);

  const safeLimit = normalizeLimit(limit);

  const { data, error } = await supabase
    .from("follows")
    .select(`
      follower_id,
      profile:profiles!follows_follower_id_fkey (
        id,
        username,
        display_name,
        avatar_url
      )
    `)
    .eq("following_id", first)
    .limit(safeLimit);

  if (error) {
    throw error;
  }

  if (!data?.length) {
    return [];
  }

  const candidateIds = data.map(
    (item) => item.follower_id
  );

  const { data: secondData, error: secondError } =
    await supabase
      .from("follows")
      .select("follower_id")
      .eq("following_id", second)
      .in("follower_id", candidateIds);

  if (secondError) {
    throw secondError;
  }

  const mutualIds = new Set(
    (secondData || []).map(
      (item) => item.follower_id
    )
  );

  return data.filter((item) =>
    mutualIds.has(item.follower_id)
  );
}

// ------------------------------------------------------------
// Search followers
// ------------------------------------------------------------

export async function searchFollowers(
  userId,
  search,
  {
    limit = DEFAULT_LIMIT
  } = {}
) {
  const targetId = validateUserId(userId);

  const term = String(search || "").trim();

  if (!term) {
    return getFollowers(targetId, { limit });
  }

  const safeLimit = normalizeLimit(limit);

  // First get follower IDs.
  const { data: followData, error: followError } =
    await supabase
      .from("follows")
      .select("follower_id, created_at")
      .eq("following_id", targetId)
      .order("created_at", {
        ascending: false
      })
      .limit(MAX_LIMIT);

  if (followError) {
    throw followError;
  }

  if (!followData?.length) {
    return [];
  }

  const ids = followData.map(
    (item) => item.follower_id
  );

  const { data: profiles, error: profileError } =
    await supabase
      .from("profiles")
      .select(`
        id,
        username,
        display_name,
        avatar_url
      `)
      .in("id", ids)
      .ilike("username", `%${term}%`)
      .limit(safeLimit);

  if (profileError) {
    throw profileError;
  }

  const profileMap = new Map(
    (profiles || []).map((profile) => [
      profile.id,
      profile
    ])
  );

  return followData
    .filter((item) => profileMap.has(item.follower_id))
    .map((item) => ({
      ...item,
      profile: profileMap.get(item.follower_id)
    }))
    .slice(0, safeLimit);
}

// ------------------------------------------------------------
// Search following
// ------------------------------------------------------------

export async function searchFollowing(
  userId,
  search,
  {
    limit = DEFAULT_LIMIT
  } = {}
) {
  const targetId = validateUserId(userId);

  const term = String(search || "").trim();

  if (!term) {
    return getFollowing(targetId, { limit });
  }

  const safeLimit = normalizeLimit(limit);

  const { data: followData, error: followError } =
    await supabase
      .from("follows")
      .select("following_id, created_at")
      .eq("follower_id", targetId)
      .order("created_at", {
        ascending: false
      })
      .limit(MAX_LIMIT);

  if (followError) {
    throw followError;
  }

  if (!followData?.length) {
    return [];
  }

  const ids = followData.map(
    (item) => item.following_id
  );

  const { data: profiles, error: profileError } =
    await supabase
      .from("profiles")
      .select(`
        id,
        username,
        display_name,
        avatar_url
      `)
      .in("id", ids)
      .ilike("username", `%${term}%`)
      .limit(safeLimit);

  if (profileError) {
    throw profileError;
  }

  const profileMap = new Map(
    (profiles || []).map((profile) => [
      profile.id,
      profile
    ])
  );

  return followData
    .filter((item) => profileMap.has(item.following_id))
    .map((item) => ({
      ...item,
      profile: profileMap.get(item.following_id)
    }))
    .slice(0, safeLimit);
}

// ------------------------------------------------------------
// Realtime
// ------------------------------------------------------------

export function subscribeToFollows() {
  if (realtimeChannels.length) {
    return realtimeChannels;
  }

  const channel = supabase
    .channel("regenesis-follows")
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "follows"
      },
      async (payload) => {
        try {
          const user = currentUser || await getCurrentUser();

          if (!user) {
            return;
          }

          const row =
            payload.new || payload.old || {};

          const affectsCurrentUser =
            row.follower_id === user.id ||
            row.following_id === user.id;

          if (!affectsCurrentUser) {
            return;
          }

          if (payload.eventType === "INSERT") {
            if (row.follower_id === user.id) {
              followingIds.add(row.following_id);
            }

            if (row.following_id === user.id) {
              followerIds.add(row.follower_id);
            }
          }

          if (payload.eventType === "DELETE") {
            if (row.follower_id === user.id) {
              followingIds.delete(row.following_id);
            }

            if (row.following_id === user.id) {
              followerIds.delete(row.follower_id);
            }
          }

          emit(EVENTS.CHANGED, {
            action: payload.eventType?.toLowerCase(),
            data: payload
          });

          emit(EVENTS.FOLLOWING_UPDATED, {
            data: followingIds
          });

          emit(EVENTS.FOLLOWERS_UPDATED, {
            data: followerIds
          });
        } catch (error) {
          emit(EVENTS.ERROR, {
            action: "realtime",
            error
          });
        }
      }
    )
    .subscribe((status, error) => {
      if (status === "CHANNEL_ERROR") {
        emit(EVENTS.ERROR, {
          action: "realtime",
          error
        });
      }
    });

  realtimeChannels.push(channel);

  return realtimeChannels;
}

// ------------------------------------------------------------
// Stop realtime
// ------------------------------------------------------------

export async function unsubscribeFromFollows() {
  for (const channel of realtimeChannels) {
    try {
      await supabase.removeChannel(channel);
    } catch (error) {
      console.error(
        "REGENESIS follows channel removal error:",
        error
      );
    }
  }

  realtimeChannels = [];
}

// ------------------------------------------------------------
// Refresh following
// ------------------------------------------------------------

export async function refreshFollowing(options = {}) {
  return loadFollowing(null, options);
}

// ------------------------------------------------------------
// Refresh followers
// ------------------------------------------------------------

export async function refreshFollowers(options = {}) {
  return loadFollowers(null, options);
}

// ------------------------------------------------------------
// Refresh everything
// ------------------------------------------------------------

export async function refreshFollows(options = {}) {
  const user = await requireUser();

  const [followingData, followersData] =
    await Promise.all([
      loadFollowing(user.id, options),
      loadFollowers(user.id, options)
    ]);

  emit(EVENTS.CHANGED, {
    action: "refresh",
    following: followingData,
    followers: followersData
  });

  return {
    following: followingData,
    followers: followersData
  };
}

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

export async function initializeFollows({
  realtime = true,
  load = false
} = {}) {
  await getCurrentUser();

  if (realtime) {
    subscribeToFollows();
  }

  if (load && currentUser) {
    await refreshFollows();
  }

  return {
    user: currentUser,
    following,
    followers
  };
}

// ------------------------------------------------------------
// Clear cached data
// ------------------------------------------------------------

export function clearFollows() {
  following = [];
  followers = [];

  followingIds.clear();
  followerIds.clear();

  emit(EVENTS.CHANGED, {
    action: "clear"
  });
}

// ------------------------------------------------------------
// Get cached following
// ------------------------------------------------------------

export function getCachedFollowing() {
  return [...following];
}

// ------------------------------------------------------------
// Get cached followers
// ------------------------------------------------------------

export function getCachedFollowers() {
  return [...followers];
}

// ------------------------------------------------------------
// Get cached following IDs
// ------------------------------------------------------------

export function getFollowingIds() {
  return new Set(followingIds);
}

// ------------------------------------------------------------
// Get cached follower IDs
// ------------------------------------------------------------

export function getFollowerIds() {
  return new Set(followerIds);
}

// ------------------------------------------------------------
// Get cached current user
// ------------------------------------------------------------

export function getCachedUser() {
  return currentUser;
}

// ------------------------------------------------------------
// Destroy module
// ------------------------------------------------------------

export async function destroyFollows() {
  await unsubscribeFromFollows();

  clearFollows();

  currentUser = null;

  listeners.clear();
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  EVENTS,

  onFollowsChange,

  getCurrentUser,
  getCachedUser,

  isFollowing,
  followUser,
  unfollowUser,
  toggleFollow,

  checkFollowStatus,

  getFollowerCount,
  getFollowingCount,
  getFollowCounts,

  loadFollowers,
  loadFollowing,

  getFollowers,
  getFollowing,

  areMutualFollowers,
  getMutualFollowers,

  searchFollowers,
  searchFollowing,

  subscribeToFollows,
  unsubscribeFromFollows,

  refreshFollowers,
  refreshFollowing,
  refreshFollows,

  initializeFollows,
  clearFollows,

  getCachedFollowing,
  getCachedFollowers,
  getFollowingIds,
  getFollowerIds,

  destroyFollows
};