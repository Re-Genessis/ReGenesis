// ============================================================
// REGENESIS - Social Sharing
// File: js/social/sharing.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 30;
const MAX_LIMIT = 100;
const MAX_SHARE_MESSAGE_LENGTH = 500;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let loading = false;

const shareCounts = new Map();
const listeners = new Set();

// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",

  SHARED: "shared",
  SHARE_DELETED: "share_deleted",

  COUNT_UPDATED: "count_updated",

  COPIED: "copied",
  NATIVE_SHARED: "native_shared",

  CHANGED: "changed",
  ERROR: "error"
};

// ------------------------------------------------------------
// Event listeners
// ------------------------------------------------------------

export function onSharingChange(callback) {
  if (typeof callback !== "function") {
    throw new TypeError("callback must be a function.");
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(type, payload = {}) {
  const event = {
    type,
    ...payload
  };

  listeners.forEach((callback) => {
    try {
      callback(event);
    } catch (error) {
      console.error(
        "REGENESIS sharing listener error:",
        error
      );
    }
  });
}

// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const { data, error } =
    await supabase.auth.getUser();

  if (error) {
    currentUser = null;
    return null;
  }

  currentUser = data?.user || null;

  return currentUser;
}

export function getCachedUser() {
  return currentUser;
}

async function requireUser() {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to share posts."
    );
  }

  return user;
}

// ------------------------------------------------------------
// Validation
// ------------------------------------------------------------

function validatePostId(postId) {
  if (
    !postId ||
    typeof postId !== "string" ||
    !postId.trim()
  ) {
    throw new Error("A valid post ID is required.");
  }

  return postId.trim();
}

function validateShareId(shareId) {
  if (
    !shareId ||
    typeof shareId !== "string" ||
    !shareId.trim()
  ) {
    throw new Error("A valid share ID is required.");
  }

  return shareId.trim();
}

function validateMessage(message) {
  if (
    message === null ||
    message === undefined
  ) {
    return null;
  }

  if (typeof message !== "string") {
    throw new Error("Invalid share message.");
  }

  const value = message.trim();

  if (!value) {
    return null;
  }

  if (value.length > MAX_SHARE_MESSAGE_LENGTH) {
    throw new Error(
      `Share message cannot exceed ${MAX_SHARE_MESSAGE_LENGTH} characters.`
    );
  }

  return value;
}

function normalizeLimit(limit) {
  const value = Number(limit);

  if (!Number.isFinite(value)) {
    return DEFAULT_LIMIT;
  }

  return Math.min(
    Math.max(Math.floor(value), 1),
    MAX_LIMIT
  );
}

// ------------------------------------------------------------
// Build post URL
// ------------------------------------------------------------

export function getPostURL(postId) {
  const id = validatePostId(postId);

  const url = new URL(
    "../pages/post.html",
    window.location.href
  );

  url.searchParams.set("id", id);

  return url.href;
}

// ------------------------------------------------------------
// Build share URL
// ------------------------------------------------------------

export function getShareURL(postId) {
  return getPostURL(postId);
}

// ------------------------------------------------------------
// Copy post link
// ------------------------------------------------------------

export async function copyPostLink(postId) {
  const id = validatePostId(postId);
  const url = getPostURL(id);

  if (
    !navigator.clipboard ||
    typeof navigator.clipboard.writeText !==
      "function"
  ) {
    throw new Error(
      "Clipboard access is not available in this browser."
    );
  }

  await navigator.clipboard.writeText(url);

  emit(EVENTS.COPIED, {
    postId: id,
    url
  });

  return {
    success: true,
    postId: id,
    url
  };
}

// ------------------------------------------------------------
// Native Web Share
// ------------------------------------------------------------

export async function nativeShare({
  postId,
  title = "REGENESIS",
  text = ""
} = {}) {
  const id = validatePostId(postId);

  const url = getPostURL(id);

  if (
    !navigator.share ||
    typeof navigator.share !== "function"
  ) {
    throw new Error(
      "Native sharing is not supported on this device."
    );
  }

  await navigator.share({
    title,
    text: text || undefined,
    url
  });

  emit(EVENTS.NATIVE_SHARED, {
    postId: id,
    url
  });

  return {
    success: true,
    postId: id,
    url
  };
}

// ------------------------------------------------------------
// Share using native Web Share when available,
// otherwise copy the link.
// ------------------------------------------------------------

export async function sharePost({
  postId,
  title = "REGENESIS",
  text = "",
  message = null,
  saveShare = true
} = {}) {
  const id = validatePostId(postId);

  const safeMessage =
    validateMessage(message);

  let method = "copy";

  if (
    navigator.share &&
    typeof navigator.share === "function"
  ) {
    try {
      await nativeShare({
        postId: id,
        title,
        text
      });

      method = "native";
    } catch (error) {
      // User cancelled native sharing.
      if (
        error?.name ===
        "AbortError"
      ) {
        return {
          success: false,
          cancelled: true,
          postId: id
        };
      }

      // Native sharing failed.
      // Fall back to copying the link.
      await copyPostLink(id);
      method = "copy";
    }
  } else {
    await copyPostLink(id);
  }

  let share = null;

  if (saveShare) {
    try {
      share = await recordShare({
        postId: id,
        message: safeMessage
      });
    } catch (error) {
      // Do not make a successful browser share
      // appear failed just because analytics/storage
      // recording was blocked by RLS.
      console.warn(
        "REGENESIS share record was not saved:",
        error
      );
    }
  }

  return {
    success: true,
    postId: id,
    method,
    share
  };
}

// ------------------------------------------------------------
// Record internal share
// ------------------------------------------------------------

export async function recordShare({
  postId,
  message = null
} = {}) {
  const user = await requireUser();
  const id = validatePostId(postId);

  const safeMessage =
    validateMessage(message);

  const { data, error } = await supabase
    .from("post_shares")
    .insert({
      post_id: id,
      user_id: user.id,
      message: safeMessage
    })
    .select()
    .single();

  if (error) {
    emit(EVENTS.ERROR, {
      action: "recordShare",
      postId: id,
      error
    });

    throw error;
  }

  const previous =
    shareCounts.get(id) || 0;

  shareCounts.set(
    id,
    previous + 1
  );

  emit(EVENTS.SHARED, {
    postId: id,
    share: data,
    count: previous + 1
  });

  emit(EVENTS.COUNT_UPDATED, {
    postId: id,
    count: previous + 1
  });

  emit(EVENTS.CHANGED, {
    action: "shared",
    postId: id,
    share: data
  });

  return data;
}

// ------------------------------------------------------------
// Get share count
// ------------------------------------------------------------

export async function getShareCount(postId) {
  const id = validatePostId(postId);

  if (shareCounts.has(id)) {
    return shareCounts.get(id);
  }

  const { count, error } = await supabase
    .from("post_shares")
    .select("id", {
      count: "exact",
      head: true
    })
    .eq("post_id", id);

  if (error) {
    throw error;
  }

  const total = count || 0;

  shareCounts.set(id, total);

  return total;
}

// ------------------------------------------------------------
// Get share counts for multiple posts
// ------------------------------------------------------------

export async function getShareCounts(postIds) {
  if (!Array.isArray(postIds)) {
    throw new TypeError(
      "postIds must be an array."
    );
  }

  const ids = [
    ...new Set(
      postIds
        .filter(
          (id) =>
            typeof id === "string" &&
            id.trim()
        )
        .map((id) => id.trim())
    )
  ];

  if (!ids.length) {
    return {};
  }

  const { data, error } = await supabase
    .from("post_shares")
    .select("post_id")
    .in("post_id", ids);

  if (error) {
    throw error;
  }

  const counts = {};

  ids.forEach((id) => {
    counts[id] = 0;
  });

  (data || []).forEach((share) => {
    counts[share.post_id] =
      (counts[share.post_id] || 0) + 1;
  });

  ids.forEach((id) => {
    shareCounts.set(
      id,
      counts[id] || 0
    );
  });

  return counts;
}

// ------------------------------------------------------------
// Get user's shares
// ------------------------------------------------------------

export async function getMyShares({
  limit = DEFAULT_LIMIT,
  offset = 0
} = {}) {
  const user = await requireUser();

  const safeLimit =
    normalizeLimit(limit);

  const safeOffset = Math.max(
    Number(offset) || 0,
    0
  );

  const { data, error } = await supabase
    .from("post_shares")
    .select(`
      id,
      post_id,
      user_id,
      message,
      created_at
    `)
    .eq("user_id", user.id)
    .order("created_at", {
      ascending: false
    })
    .range(
      safeOffset,
      safeOffset + safeLimit - 1
    );

  if (error) {
    throw error;
  }

  return data || [];
}

// ------------------------------------------------------------
// Get shares for a post
// ------------------------------------------------------------

export async function getPostShares(
  postId,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  const id = validatePostId(postId);

  const safeLimit =
    normalizeLimit(limit);

  const safeOffset = Math.max(
    Number(offset) || 0,
    0
  );

  const { data, error } = await supabase
    .from("post_shares")
    .select(`
      id,
      post_id,
      user_id,
      message,
      created_at,
      profiles (
        id,
        username,
        display_name,
        avatar_url
      )
    `)
    .eq("post_id", id)
    .order("created_at", {
      ascending: false
    })
    .range(
      safeOffset,
      safeOffset + safeLimit - 1
    );

  if (error) {
    throw error;
  }

  return data || [];
}

// ------------------------------------------------------------
// Delete own share record
// ------------------------------------------------------------

export async function deleteShare(
  shareId
) {
  const user = await requireUser();
  const id = validateShareId(shareId);

  const { data, error } = await supabase
    .from("post_shares")
    .delete()
    .eq("id", id)
    .eq("user_id", user.id)
    .select()
    .maybeSingle();

  if (error) {
    emit(EVENTS.ERROR, {
      action: "deleteShare",
      shareId: id,
      error
    });

    throw error;
  }

  if (data) {
    const postId = data.post_id;

    const previous =
      shareCounts.get(postId) || 0;

    const count = Math.max(
      previous - 1,
      0
    );

    shareCounts.set(
      postId,
      count
    );

    emit(EVENTS.SHARE_DELETED, {
      shareId: id,
      postId,
      count
    });

    emit(EVENTS.COUNT_UPDATED, {
      postId,
      count
    });

    emit(EVENTS.CHANGED, {
      action: "share_deleted",
      shareId: id,
      postId
    });
  }

  return data;
}

// ------------------------------------------------------------
// Check whether current user shared a post
// ------------------------------------------------------------

export async function hasSharedPost(
  postId
) {
  const user = await requireUser();
  const id = validatePostId(postId);

  const { data, error } = await supabase
    .from("post_shares")
    .select("id")
    .eq("post_id", id)
    .eq("user_id", user.id)
    .limit(1);

  if (error) {
    throw error;
  }

  return Boolean(
    data?.length
  );
}

// ------------------------------------------------------------
// Refresh share information
// ------------------------------------------------------------

export async function refreshShare(
  postId
) {
  const id = validatePostId(postId);

  const count =
    await getShareCount(id);

  let shared = false;

  const user =
    currentUser ||
    await getCurrentUser();

  if (user) {
    shared =
      await hasSharedPost(id);
  }

  emit(EVENTS.CHANGED, {
    action: "refresh",
    postId: id,
    count,
    shared
  });

  return {
    postId: id,
    count,
    shared
  };
}

// ------------------------------------------------------------
// Refresh multiple posts
// ------------------------------------------------------------

export async function refreshShares(
  postIds
) {
  const counts =
    await getShareCounts(
      postIds
    );

  emit(EVENTS.CHANGED, {
    action: "refresh_multiple",
    counts
  });

  return counts;
}

// ------------------------------------------------------------
// Realtime
// ------------------------------------------------------------

let realtimeChannel = null;

export function subscribeToSharing() {
  if (realtimeChannel) {
    return realtimeChannel;
  }

  realtimeChannel = supabase
    .channel("regenesis-social-sharing")
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "post_shares"
      },
      (payload) => {
        try {
          const row =
            payload.new ||
            payload.old ||
            {};

          const postId =
            row.post_id;

          if (!postId) {
            return;
          }

          const current =
            shareCounts.get(
              postId
            );

          if (
            payload.eventType ===
            "INSERT"
          ) {
            if (
              typeof current ===
              "number"
            ) {
              shareCounts.set(
                postId,
                current + 1
              );
            }
          }

          if (
            payload.eventType ===
            "DELETE"
          ) {
            if (
              typeof current ===
              "number"
            ) {
              shareCounts.set(
                postId,
                Math.max(
                  current - 1,
                  0
                )
              );
            }
          }

          const count =
            shareCounts.get(
              postId
            );

          emit(EVENTS.CHANGED, {
            action:
              payload.eventType?.toLowerCase(),
            postId,
            count,
            payload
          });

          emit(
            EVENTS.COUNT_UPDATED,
            {
              postId,
              count
            }
          );
        } catch (error) {
          emit(EVENTS.ERROR, {
            action: "realtime",
            error
          });
        }
      }
    )
    .subscribe(
      (status, error) => {
        if (
          status === "CHANNEL_ERROR" ||
          status === "TIMED_OUT"
        ) {
          emit(EVENTS.ERROR, {
            action: "realtime",
            error
          });
        }
      }
    );

  return realtimeChannel;
}

// ------------------------------------------------------------
// Stop realtime
// ------------------------------------------------------------

export async function unsubscribeFromSharing() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "REGENESIS sharing channel removal error:",
      error
    );
  }

  realtimeChannel = null;
}

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

export async function initializeSharing({
  realtime = true
} = {}) {
  await getCurrentUser();

  if (realtime) {
    subscribeToSharing();
  }

  return {
    user: currentUser
  };
}

// ------------------------------------------------------------
// Cache
// ------------------------------------------------------------

export function clearSharingCache() {
  shareCounts.clear();

  emit(EVENTS.CHANGED, {
    action: "clear"
  });
}

export function getCachedShareCount(
  postId
) {
  const id = validatePostId(postId);

  return shareCounts.get(id) ?? null;
}

export function getCachedShareCounts() {
  return new Map(
    shareCounts
  );
}

// ------------------------------------------------------------
// Destroy
// ------------------------------------------------------------

export async function destroySharing() {
  await unsubscribeFromSharing();

  clearSharingCache();

  currentUser = null;

  loading = false;

  listeners.clear();
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  EVENTS,

  onSharingChange,

  getCurrentUser,
  getCachedUser,

  getPostURL,
  getShareURL,

  copyPostLink,
  nativeShare,
  sharePost,

  recordShare,

  getShareCount,
  getShareCounts,

  getMyShares,
  getPostShares,

  deleteShare,
  hasSharedPost,

  refreshShare,
  refreshShares,

  subscribeToSharing,
  unsubscribeFromSharing,

  initializeSharing,

  clearSharingCache,
  getCachedShareCount,
  getCachedShareCounts,

  destroySharing
};