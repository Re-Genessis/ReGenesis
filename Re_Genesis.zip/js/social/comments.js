// ============================================================
// REGENESIS
// js/social/comments.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const COMMENTS_TABLE = "comments";
const COMMENT_LIKES_TABLE = "comment_likes";
const PROFILES_TABLE = "profiles";

const DEFAULT_LIMIT = 30;
const MAX_LIMIT = 100;
const MAX_COMMENT_LENGTH = 3000;


// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;
let currentPostId = null;

let comments = [];
let commentMap = new Map();

let loading = false;
let submitting = false;

let realtimeChannel = null;

const listeners = new Set();


// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const COMMENTS_EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",

  CREATING: "creating",
  CREATED: "created",

  UPDATING: "updating",
  UPDATED: "updated",

  DELETING: "deleting",
  DELETED: "deleted",

  LIKED: "liked",
  UNLIKED: "unliked",

  CHANGED: "changed",
  ERROR: "error"
};


// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onCommentsChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(event, data = null) {
  listeners.forEach((callback) => {
    try {
      callback({
        event,
        data,
        state: getState()
      });
    } catch (error) {
      console.error(
        "REGENESIS comments listener error:",
        error
      );
    }
  });
}


// ------------------------------------------------------------
// Error helper
// ------------------------------------------------------------

function getErrorMessage(error) {
  if (!error) {
    return "Something went wrong.";
  }

  return (
    error.message ||
    error.error_description ||
    error.details ||
    error.hint ||
    "Something went wrong."
  );
}


// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const {
    data,
    error
  } = await supabase.auth.getUser();

  if (error) {
    throw error;
  }

  currentUser = data?.user || null;

  return currentUser;
}

export function getCachedUser() {
  return currentUser;
}

async function requireUser() {
  const user =
    currentUser || await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to do that."
    );
  }

  return user;
}


// ------------------------------------------------------------
// Validation
// ------------------------------------------------------------

export function validateComment(content) {
  const value = String(content || "").trim();

  if (!value) {
    return {
      valid: false,
      message: "Comment cannot be empty."
    };
  }

  if (value.length > MAX_COMMENT_LENGTH) {
    return {
      valid: false,
      message:
        `Comment cannot exceed ${MAX_COMMENT_LENGTH} characters.`
    };
  }

  return {
    valid: true,
    value
  };
}


// ------------------------------------------------------------
// Set current post
// ------------------------------------------------------------

export function setPost(postId) {
  if (!postId) {
    throw new Error("Post ID is required.");
  }

  currentPostId = String(postId);

  clearComments();

  return currentPostId;
}

export function getPostId() {
  return currentPostId;
}


// ------------------------------------------------------------
// Comment select
// ------------------------------------------------------------

const COMMENT_SELECT = `
  id,
  post_id,
  user_id,
  parent_id,
  content,
  created_at,
  updated_at,
  profiles (
    id,
    username,
    display_name,
    avatar_url
  )
`;


// ------------------------------------------------------------
// Load comments
// ------------------------------------------------------------

export async function loadComments(
  postId = currentPostId,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  if (!postId) {
    throw new Error("Post ID is required.");
  }

  currentPostId = String(postId);

  limit = Math.min(
    Math.max(
      Number(limit) || DEFAULT_LIMIT,
      1
    ),
    MAX_LIMIT
  );

  offset = Math.max(
    Number(offset) || 0,
    0
  );

  loading = true;

  emit(
    COMMENTS_EVENTS.LOADING,
    {
      postId: currentPostId
    }
  );

  try {
    const {
      data,
      error
    } = await supabase
      .from(COMMENTS_TABLE)
      .select(COMMENT_SELECT)
      .eq("post_id", currentPostId)
      .order("created_at", {
        ascending: true
      })
      .range(
        offset,
        offset + limit - 1
      );

    if (error) {
      throw error;
    }

    comments = data || [];

    rebuildCommentMap();

    // Load like information separately.
    await loadLikeInformation(
      comments
    );

    emit(
      COMMENTS_EVENTS.LOADED,
      comments
    );

    emit(
      COMMENTS_EVENTS.CHANGED,
      comments
    );

    return comments;

  } catch (error) {
    emit(
      COMMENTS_EVENTS.ERROR,
      error
    );

    throw error;

  } finally {
    loading = false;
  }
}


// ------------------------------------------------------------
// Load one comment
// ------------------------------------------------------------

export async function getComment(
  commentId
) {
  if (!commentId) {
    throw new Error(
      "Comment ID is required."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from(COMMENTS_TABLE)
    .select(COMMENT_SELECT)
    .eq("id", commentId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    return null;
  }

  const likeInfo =
    await getLikeInformation(
      data.id
    );

  return {
    ...data,
    like_count: likeInfo.count,
    liked_by_me: likeInfo.liked
  };
}


// ------------------------------------------------------------
// Create comment
// ------------------------------------------------------------

export async function createComment({
  postId = currentPostId,
  content,
  parentId = null
} = {}) {
  const user =
    await requireUser();

  if (!postId) {
    throw new Error(
      "Post ID is required."
    );
  }

  const validation =
    validateComment(content);

  if (!validation.valid) {
    throw new Error(
      validation.message
    );
  }

  submitting = true;

  emit(
    COMMENTS_EVENTS.CREATING,
    {
      postId,
      parentId
    }
  );

  try {
    // If this is a reply, verify that the
    // parent comment belongs to the same post.
    if (parentId) {
      const {
        data: parent,
        error: parentError
      } = await supabase
        .from(COMMENTS_TABLE)
        .select("id, post_id")
        .eq("id", parentId)
        .maybeSingle();

      if (parentError) {
        throw parentError;
      }

      if (!parent) {
        throw new Error(
          "The parent comment no longer exists."
        );
      }

      if (
        String(parent.post_id) !==
        String(postId)
      ) {
        throw new Error(
          "Invalid reply target."
        );
      }
    }

    const {
      data,
      error
    } = await supabase
      .from(COMMENTS_TABLE)
      .insert({
        post_id: postId,
        user_id: user.id,
        parent_id: parentId || null,
        content: validation.value
      })
      .select(COMMENT_SELECT)
      .single();

    if (error) {
      throw error;
    }

    const newComment = {
      ...data,
      like_count: 0,
      liked_by_me: false
    };

    // Add immediately to local state.
    comments.push(newComment);

    rebuildCommentMap();

    emit(
      COMMENTS_EVENTS.CREATED,
      newComment
    );

    emit(
      COMMENTS_EVENTS.CHANGED,
      comments
    );

    return newComment;

  } catch (error) {
    emit(
      COMMENTS_EVENTS.ERROR,
      error
    );

    throw error;

  } finally {
    submitting = false;
  }
}


// ------------------------------------------------------------
// Reply to comment
// ------------------------------------------------------------

export async function replyToComment(
  parentId,
  content,
  postId = currentPostId
) {
  return createComment({
    postId,
    parentId,
    content
  });
}


// ------------------------------------------------------------
// Update comment
// ------------------------------------------------------------

export async function updateComment(
  commentId,
  content
) {
  const user =
    await requireUser();

  if (!commentId) {
    throw new Error(
      "Comment ID is required."
    );
  }

  const validation =
    validateComment(content);

  if (!validation.valid) {
    throw new Error(
      validation.message
    );
  }

  emit(
    COMMENTS_EVENTS.UPDATING,
    {
      commentId
    }
  );

  try {
    const {
      data,
      error
    } = await supabase
      .from(COMMENTS_TABLE)
      .update({
        content: validation.value,
        updated_at: new Date().toISOString()
      })
      .eq("id", commentId)
      .eq("user_id", user.id)
      .select(COMMENT_SELECT)
      .maybeSingle();

    if (error) {
      throw error;
    }

    if (!data) {
      throw new Error(
        "Comment not found or you do not own this comment."
      );
    }

    const existing =
      commentMap.get(String(commentId));

    const updated = {
      ...data,
      like_count:
        existing?.like_count || 0,
      liked_by_me:
        existing?.liked_by_me || false
    };

    replaceComment(updated);

    emit(
      COMMENTS_EVENTS.UPDATED,
      updated
    );

    emit(
      COMMENTS_EVENTS.CHANGED,
      comments
    );

    return updated;

  } catch (error) {
    emit(
      COMMENTS_EVENTS.ERROR,
      error
    );

    throw error;
  }
}


// ------------------------------------------------------------
// Delete comment
// ------------------------------------------------------------

export async function deleteComment(
  commentId
) {
  const user =
    await requireUser();

  if (!commentId) {
    throw new Error(
      "Comment ID is required."
    );
  }

  emit(
    COMMENTS_EVENTS.DELETING,
    {
      commentId
    }
  );

  try {
    // Only the comment owner can delete.
    const {
      data,
      error
    } = await supabase
      .from(COMMENTS_TABLE)
      .delete()
      .eq("id", commentId)
      .eq("user_id", user.id)
      .select("id")
      .maybeSingle();

    if (error) {
      throw error;
    }

    if (!data) {
      throw new Error(
        "Comment not found or you do not own this comment."
      );
    }

    // Remove the comment and its local replies.
    const deletedIds =
      collectCommentTreeIds(
        commentId
      );

    comments = comments.filter(
      (comment) =>
        !deletedIds.has(
          String(comment.id)
        )
    );

    rebuildCommentMap();

    emit(
      COMMENTS_EVENTS.DELETED,
      {
        id: commentId,
        deletedIds: [
          ...deletedIds
        ]
      }
    );

    emit(
      COMMENTS_EVENTS.CHANGED,
      comments
    );

    return true;

  } catch (error) {
    emit(
      COMMENTS_EVENTS.ERROR,
      error
    );

    throw error;
  }
}


// ------------------------------------------------------------
// Build comment tree
// ------------------------------------------------------------

export function buildCommentTree(
  commentList = comments
) {
  const roots = [];
  const children = new Map();

  commentList.forEach((comment) => {
    const parentId =
      comment.parent_id
        ? String(comment.parent_id)
        : null;

    if (!parentId) {
      roots.push({
        ...comment,
        replies: []
      });

      return;
    }

    if (!children.has(parentId)) {
      children.set(
        parentId,
        []
      );
    }

    children
      .get(parentId)
      .push({
        ...comment,
        replies: []
      });
  });

  function attachReplies(nodes) {
    nodes.forEach((node) => {
      const childNodes =
        children.get(
          String(node.id)
        ) || [];

      node.replies =
        childNodes;

      attachReplies(
        node.replies
      );
    });

    return nodes;
  }

  return attachReplies(roots);
}


// ------------------------------------------------------------
// Get replies
// ------------------------------------------------------------

export function getReplies(
  commentId
) {
  if (!commentId) {
    return [];
  }

  return comments.filter(
    (comment) =>
      String(comment.parent_id) ===
      String(commentId)
  );
}


// ------------------------------------------------------------
// Get root comments
// ------------------------------------------------------------

export function getRootComments() {
  return comments.filter(
    (comment) =>
      !comment.parent_id
  );
}


// ------------------------------------------------------------
// Count replies
// ------------------------------------------------------------

export function getReplyCount(
  commentId
) {
  if (!commentId) {
    return 0;
  }

  return comments.filter(
    (comment) =>
      String(comment.parent_id) ===
      String(commentId)
  ).length;
}


// ------------------------------------------------------------
// Recursively count descendants
// ------------------------------------------------------------

export function getTotalReplyCount(
  commentId
) {
  if (!commentId) {
    return 0;
  }

  let total = 0;

  function countChildren(parentId) {
    const children =
      getReplies(parentId);

    total += children.length;

    children.forEach(
      (child) => {
        countChildren(child.id);
      }
    );
  }

  countChildren(commentId);

  return total;
}


// ------------------------------------------------------------
// Build local comment map
// ------------------------------------------------------------

function rebuildCommentMap() {
  commentMap = new Map();

  comments.forEach(
    (comment) => {
      commentMap.set(
        String(comment.id),
        comment
      );
    }
  );
}


// ------------------------------------------------------------
// Replace comment
// ------------------------------------------------------------

function replaceComment(comment) {
  const index =
    comments.findIndex(
      (item) =>
        String(item.id) ===
        String(comment.id)
    );

  if (index === -1) {
    comments.push(comment);
  } else {
    comments[index] = {
      ...comments[index],
      ...comment
    };
  }

  rebuildCommentMap();
}


// ------------------------------------------------------------
// Add realtime comment
// ------------------------------------------------------------

async function addRealtimeComment(
  comment
) {
  if (!comment?.id) {
    return;
  }

  const exists =
    commentMap.has(
      String(comment.id)
    );

  if (exists) {
    return;
  }

  try {
    const fullComment =
      await getComment(
        comment.id
      );

    if (fullComment) {
      comments.push(
        fullComment
      );

      rebuildCommentMap();

      emit(
        COMMENTS_EVENTS.CREATED,
        fullComment
      );

      emit(
        COMMENTS_EVENTS.CHANGED,
        comments
      );
    }
  } catch (error) {
    console.warn(
      "Could not load realtime comment:",
      error
    );
  }
}


// ------------------------------------------------------------
// Handle realtime update
// ------------------------------------------------------------

async function updateRealtimeComment(
  comment
) {
  if (!comment?.id) {
    return;
  }

  try {
    const fullComment =
      await getComment(
        comment.id
      );

    if (fullComment) {
      replaceComment(
        fullComment
      );

      emit(
        COMMENTS_EVENTS.UPDATED,
        fullComment
      );

      emit(
        COMMENTS_EVENTS.CHANGED,
        comments
      );
    }
  } catch (error) {
    console.warn(
      "Could not refresh realtime comment:",
      error
    );
  }
}


// ------------------------------------------------------------
// Remove realtime comment
// ------------------------------------------------------------

function removeRealtimeComment(
  commentId
) {
  if (!commentId) {
    return;
  }

  const deletedIds =
    collectCommentTreeIds(
      commentId
    );

  comments = comments.filter(
    (comment) =>
      !deletedIds.has(
        String(comment.id)
      )
  );

  rebuildCommentMap();

  emit(
    COMMENTS_EVENTS.DELETED,
    {
      id: commentId,
      deletedIds: [
        ...deletedIds
      ]
    }
  );

  emit(
    COMMENTS_EVENTS.CHANGED,
    comments
  );
}


// ------------------------------------------------------------
// Collect comment tree IDs
// ------------------------------------------------------------

function collectCommentTreeIds(
  commentId
) {
  const ids = new Set([
    String(commentId)
  ]);

  let changed = true;

  while (changed) {
    changed = false;

    comments.forEach(
      (comment) => {
        if (
          comment.parent_id &&
          ids.has(
            String(comment.parent_id)
          ) &&
          !ids.has(
            String(comment.id)
          )
        ) {
          ids.add(
            String(comment.id)
          );

          changed = true;
        }
      }
    );
  }

  return ids;
}


// ------------------------------------------------------------
// Like information
// ------------------------------------------------------------

async function getLikeInformation(
  commentId
) {
  let count = 0;
  let liked = false;

  try {
    const {
      count: total,
      error
    } = await supabase
      .from(COMMENT_LIKES_TABLE)
      .select("id", {
        count: "exact",
        head: true
      })
      .eq(
        "comment_id",
        commentId
      );

    if (!error) {
      count = total || 0;
    }
  } catch {
    count = 0;
  }

  if (currentUser) {
    try {
      const {
        data
      } = await supabase
        .from(COMMENT_LIKES_TABLE)
        .select("id")
        .eq(
          "comment_id",
          commentId
        )
        .eq(
          "user_id",
          currentUser.id
        )
        .maybeSingle();

      liked = Boolean(data);
    } catch {
      liked = false;
    }
  }

  return {
    count,
    liked
  };
}


// ------------------------------------------------------------
// Load likes for comments
// ------------------------------------------------------------

async function loadLikeInformation(
  commentList
) {
  if (!commentList.length) {
    return;
  }

  const ids =
    commentList.map(
      (comment) => comment.id
    );

  let likeRows = [];

  try {
    const {
      data,
      error
    } = await supabase
      .from(COMMENT_LIKES_TABLE)
      .select(
        "id, comment_id, user_id"
      )
      .in(
        "comment_id",
        ids
      );

    if (error) {
      return;
    }

    likeRows = data || [];

  } catch {
    return;
  }

  const counts = new Map();
  const myLikes = new Set();

  likeRows.forEach(
    (like) => {
      const id =
        String(like.comment_id);

      counts.set(
        id,
        (counts.get(id) || 0) + 1
      );

      if (
        currentUser &&
        like.user_id ===
          currentUser.id
      ) {
        myLikes.add(id);
      }
    }
  );

  comments = comments.map(
    (comment) => ({
      ...comment,
      like_count:
        counts.get(
          String(comment.id)
        ) || 0,
      liked_by_me:
        myLikes.has(
          String(comment.id)
        )
    })
  );

  rebuildCommentMap();
}


// ------------------------------------------------------------
// Get comment like count
// ------------------------------------------------------------

export async function getLikeCount(
  commentId
) {
  if (!commentId) {
    return 0;
  }

  const {
    count,
    error
  } = await supabase
    .from(COMMENT_LIKES_TABLE)
    .select("id", {
      count: "exact",
      head: true
    })
    .eq(
      "comment_id",
      commentId
    );

  if (error) {
    throw error;
  }

  return count || 0;
}


// ------------------------------------------------------------
// Check if current user liked comment
// ------------------------------------------------------------

export async function hasLiked(
  commentId
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    return false;
  }

  const {
    data,
    error
  } = await supabase
    .from(COMMENT_LIKES_TABLE)
    .select("id")
    .eq(
      "comment_id",
      commentId
    )
    .eq(
      "user_id",
      user.id
    )
    .maybeSingle();

  if (error) {
    throw error;
  }

  return Boolean(data);
}


// ------------------------------------------------------------
// Like comment
// ------------------------------------------------------------

export async function likeComment(
  commentId
) {
  const user =
    await requireUser();

  if (!commentId) {
    throw new Error(
      "Comment ID is required."
    );
  }

  try {
    const {
      data,
      error
    } = await supabase
      .from(COMMENT_LIKES_TABLE)
      .insert({
        comment_id: commentId,
        user_id: user.id
      })
      .select("id, comment_id, user_id")
      .single();

    if (error) {
      // UNIQUE(comment_id,user_id)
      if (error.code === "23505") {
        return true;
      }

      throw error;
    }

    const comment =
      commentMap.get(
        String(commentId)
      );

    if (comment) {
      comment.like_count =
        (comment.like_count || 0) + 1;

      comment.liked_by_me = true;

      rebuildCommentMap();
    }

    emit(
      COMMENTS_EVENTS.LIKED,
      data
    );

    emit(
      COMMENTS_EVENTS.CHANGED,
      comments
    );

    return true;

  } catch (error) {
    emit(
      COMMENTS_EVENTS.ERROR,
      error
    );

    throw error;
  }
}


// ------------------------------------------------------------
// Unlike comment
// ------------------------------------------------------------

export async function unlikeComment(
  commentId
) {
  const user =
    await requireUser();

  if (!commentId) {
    throw new Error(
      "Comment ID is required."
    );
  }

  const {
    error
  } = await supabase
    .from(COMMENT_LIKES_TABLE)
    .delete()
    .eq(
      "comment_id",
      commentId
    )
    .eq(
      "user_id",
      user.id
    );

  if (error) {
    throw error;
  }

  const comment =
    commentMap.get(
      String(commentId)
    );

  if (comment) {
    comment.like_count =
      Math.max(
        (comment.like_count || 0) - 1,
        0
      );

    comment.liked_by_me = false;

    rebuildCommentMap();
  }

  emit(
    COMMENTS_EVENTS.UNLIKED,
    {
      commentId
    }
  );

  emit(
    COMMENTS_EVENTS.CHANGED,
    comments
  );

  return true;
}


// ------------------------------------------------------------
// Toggle like
// ------------------------------------------------------------

export async function toggleCommentLike(
  commentId
) {
  const liked =
    await hasLiked(commentId);

  if (liked) {
    await unlikeComment(
      commentId
    );

    return false;
  }

  await likeComment(
    commentId
  );

  return true;
}


// ------------------------------------------------------------
// Get comment by ID from cache
// ------------------------------------------------------------

export function getCachedComment(
  commentId
) {
  if (!commentId) {
    return null;
  }

  return (
    commentMap.get(
      String(commentId)
    ) || null
  );
}


// ------------------------------------------------------------
// Get all comments
// ------------------------------------------------------------

export function getComments() {
  return [
    ...comments
  ];
}


// ------------------------------------------------------------
// Get comment tree
// ------------------------------------------------------------

export function getCommentTree() {
  return buildCommentTree(
    comments
  );
}


// ------------------------------------------------------------
// Get root comments
// ------------------------------------------------------------

export function getCommentsCount() {
  return comments.length;
}


// ------------------------------------------------------------
// Subscribe to realtime comments
// ------------------------------------------------------------

export function subscribeToComments(
  postId = currentPostId
) {
  unsubscribeFromComments();

  if (!postId) {
    return null;
  }

  currentPostId = String(postId);

  realtimeChannel =
    supabase
      .channel(
        `comments-${currentPostId}-${Date.now()}`
      )

      // New comments
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: COMMENTS_TABLE,
          filter:
            `post_id=eq.${currentPostId}`
        },
        async (payload) => {
          await addRealtimeComment(
            payload.new
          );
        }
      )

      // Updated comments
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: COMMENTS_TABLE,
          filter:
            `post_id=eq.${currentPostId}`
        },
        async (payload) => {
          await updateRealtimeComment(
            payload.new
          );
        }
      )

      // Deleted comments
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: COMMENTS_TABLE
        },
        async (payload) => {
          const deleted =
            payload.old;

          if (!deleted?.id) {
            return;
          }

          // Only remove it if it is currently
          // loaded in this post's comments.
          if (
            commentMap.has(
              String(deleted.id)
            )
          ) {
            removeRealtimeComment(
              deleted.id
            );
          }
        }
      )

      // Comment likes
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: COMMENT_LIKES_TABLE
        },
        async () => {
          if (!currentPostId) {
            return;
          }

          try {
            await loadComments(
              currentPostId
            );
          } catch (error) {
            console.warn(
              "Could not refresh comment likes:",
              error
            );
          }
        }
      )

      .subscribe(
        (status) => {
          if (
            status === "SUBSCRIBED"
          ) {
            console.log(
              "REGENESIS comments realtime connected."
            );
          }

          if (
            status === "CHANNEL_ERROR"
          ) {
            console.warn(
              "REGENESIS comments realtime channel error."
            );
          }

          if (
            status === "TIMED_OUT"
          ) {
            console.warn(
              "REGENESIS comments realtime timed out."
            );
          }
        }
      );

  return realtimeChannel;
}


// ------------------------------------------------------------
// Unsubscribe realtime
// ------------------------------------------------------------

export async function unsubscribeFromComments() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.warn(
      "Could not remove comments realtime channel:",
      error
    );
  }

  realtimeChannel = null;
}


// ------------------------------------------------------------
// Refresh
// ------------------------------------------------------------

export async function refreshComments(
  options = {}
) {
  if (!currentPostId) {
    return [];
  }

  return loadComments(
    currentPostId,
    options
  );
}


// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

export async function initializeComments(
  postId,
  {
    realtime = true,
    limit = DEFAULT_LIMIT
  } = {}
) {
  setPost(postId);

  try {
    await getCurrentUser();
  } catch {
    currentUser = null;
  }

  const loaded =
    await loadComments(
      postId,
      { limit }
    );

  if (realtime) {
    subscribeToComments(
      postId
    );
  }

  return loaded;
}


// ------------------------------------------------------------
// Clear comments
// ------------------------------------------------------------

export function clearComments() {
  comments = [];
  commentMap.clear();

  emit(
    COMMENTS_EVENTS.CHANGED,
    comments
  );
}


// ------------------------------------------------------------
// State
// ------------------------------------------------------------

export function getState() {
  return {
    currentUser,
    currentPostId,

    comments: [
      ...comments
    ],

    commentCount:
      comments.length,

    loading,
    submitting,

    realtimeConnected:
      Boolean(realtimeChannel)
  };
}


// ------------------------------------------------------------
// Getters
// ------------------------------------------------------------

export function isLoading() {
  return loading;
}

export function isSubmitting() {
  return submitting;
}

export function isRealtimeConnected() {
  return Boolean(
    realtimeChannel
  );
}


// ------------------------------------------------------------
// Cleanup
// ------------------------------------------------------------

export async function destroyComments() {
  await unsubscribeFromComments();

  currentUser = null;
  currentPostId = null;

  comments = [];
  commentMap.clear();

  loading = false;
  submitting = false;

  listeners.clear();
}


// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  // Authentication
  getCurrentUser,
  getCachedUser,

  // Post
  setPost,
  getPostId,

  // Comments
  loadComments,
  getComment,
  createComment,
  replyToComment,
  updateComment,
  deleteComment,

  // Trees
  buildCommentTree,
  getReplies,
  getRootComments,
  getReplyCount,
  getTotalReplyCount,

  // Likes
  getLikeCount,
  hasLiked,
  likeComment,
  unlikeComment,
  toggleCommentLike,

  // Cache
  getCachedComment,
  getComments,
  getCommentTree,
  getCommentsCount,

  // Realtime
  subscribeToComments,
  unsubscribeFromComments,

  // Lifecycle
  refreshComments,
  initializeComments,
  clearComments,
  destroyComments,

  // Validation
  validateComment,

  // State
  getState,
  isLoading,
  isSubmitting,
  isRealtimeConnected,

  // Events
  onCommentsChange
};