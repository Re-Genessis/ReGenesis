// ============================================================
// REGENESIS - Social Posts
// File: js/social/posts.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 50;
const MAX_POST_LENGTH = 5000;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;

let posts = [];
let postMap = new Map();

let loading = false;
let loadingMore = false;
let creating = false;
let updating = false;
let deleting = false;

let hasMore = true;
let currentOffset = 0;

let realtimeChannel = null;

const listeners = new Set();

// ------------------------------------------------------------
// Post selection
// ------------------------------------------------------------

const POST_SELECT = `
  id,
  user_id,
  content,
  image_url,
  created_at,
  updated_at,
  profiles (
    id,
    username,
    display_name,
    avatar_url
  )
`;

// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",

  LOADING_MORE: "loading_more",
  MORE_LOADED: "more_loaded",

  CREATING: "creating",
  CREATED: "created",

  UPDATING: "updating",
  UPDATED: "updated",

  DELETING: "deleting",
  DELETED: "deleted",

  REALTIME_UPDATE: "realtime_update",

  REFRESHED: "refreshed",
  CHANGED: "changed",

  ERROR: "error"
};

// ------------------------------------------------------------
// Event listeners
// ------------------------------------------------------------

export function onPostsChange(callback) {
  if (typeof callback !== "function") {
    throw new TypeError("callback must be a function.");
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(type, payload = {}) {
  const event = {
    type,
    ...payload
  };

  listeners.forEach((callback) => {
    try {
      callback(event);
    } catch (error) {
      console.error(
        "REGENESIS posts listener error:",
        error
      );
    }
  });
}

// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const { data, error } =
    await supabase.auth.getUser();

  if (error) {
    currentUser = null;
    return null;
  }

  currentUser = data?.user || null;

  return currentUser;
}

export function getCachedUser() {
  return currentUser;
}

async function requireUser() {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to perform this action."
    );
  }

  return user;
}

// ------------------------------------------------------------
// Validation
// ------------------------------------------------------------

function validatePostId(postId) {
  if (
    !postId ||
    typeof postId !== "string" ||
    !postId.trim()
  ) {
    throw new Error("A valid post ID is required.");
  }

  return postId.trim();
}

function validateContent(content) {
  if (
    typeof content !== "string" ||
    !content.trim()
  ) {
    throw new Error("Post content cannot be empty.");
  }

  const value = content.trim();

  if (value.length > MAX_POST_LENGTH) {
    throw new Error(
      `Post content cannot exceed ${MAX_POST_LENGTH} characters.`
    );
  }

  return value;
}

function validateImageURL(imageUrl) {
  if (
    imageUrl === null ||
    imageUrl === undefined ||
    imageUrl === ""
  ) {
    return null;
  }

  if (typeof imageUrl !== "string") {
    throw new Error("Invalid image URL.");
  }

  const value = imageUrl.trim();

  if (!value) {
    return null;
  }

  try {
    const url = new URL(value);

    if (
      url.protocol !== "http:" &&
      url.protocol !== "https:"
    ) {
      throw new Error();
    }

    return value;
  } catch {
    throw new Error("Invalid image URL.");
  }
}

function normalizeLimit(limit) {
  const value = Number(limit);

  if (!Number.isFinite(value)) {
    return DEFAULT_LIMIT;
  }

  return Math.min(
    Math.max(Math.floor(value), 1),
    MAX_LIMIT
  );
}

// ------------------------------------------------------------
// Load posts
// ------------------------------------------------------------

export async function loadPosts({
  limit = DEFAULT_LIMIT,
  offset = 0,
  userId = null
} = {}) {
  const safeLimit = normalizeLimit(limit);
  const safeOffset = Math.max(
    Number(offset) || 0,
    0
  );

  loading = true;

  emit(EVENTS.LOADING, {
    offset: safeOffset,
    limit: safeLimit
  });

  try {
    let query = supabase
      .from("posts")
      .select(POST_SELECT)
      .order("created_at", {
        ascending: false
      })
      .range(
        safeOffset,
        safeOffset + safeLimit - 1
      );

    if (userId) {
      query = query.eq(
        "user_id",
        userId
      );
    }

    const { data, error } = await query;

    if (error) {
      throw error;
    }

    const result = data || [];

    posts = result;
    postMap = new Map(
      result.map((post) => [
        post.id,
        post
      ])
    );

    currentOffset = safeOffset + result.length;
    hasMore = result.length === safeLimit;

    emit(EVENTS.LOADED, {
      data: result,
      hasMore,
      offset: safeOffset
    });

    return result;
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "loadPosts",
      error
    });

    throw error;
  } finally {
    loading = false;
  }
}

// ------------------------------------------------------------
// Load more posts
// ------------------------------------------------------------

export async function loadMore({
  limit = DEFAULT_LIMIT
} = {}) {
  if (loadingMore || !hasMore) {
    return [];
  }

  const safeLimit = normalizeLimit(limit);

  loadingMore = true;

  emit(EVENTS.LOADING_MORE, {
    offset: currentOffset,
    limit: safeLimit
  });

  try {
    const { data, error } = await supabase
      .from("posts")
      .select(POST_SELECT)
      .order("created_at", {
        ascending: false
      })
      .range(
        currentOffset,
        currentOffset + safeLimit - 1
      );

    if (error) {
      throw error;
    }

    const result = data || [];

    result.forEach((post) => {
      postMap.set(post.id, post);
    });

    posts = [
      ...posts,
      ...result
    ];

    currentOffset += result.length;

    hasMore =
      result.length === safeLimit;

    emit(EVENTS.MORE_LOADED, {
      data: result,
      hasMore,
      offset: currentOffset
    });

    return result;
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "loadMore",
      error
    });

    throw error;
  } finally {
    loadingMore = false;
  }
}

// ------------------------------------------------------------
// Get one post
// ------------------------------------------------------------

export async function getPost(postId) {
  const id = validatePostId(postId);

  if (postMap.has(id)) {
    return postMap.get(id);
  }

  const { data, error } = await supabase
    .from("posts")
    .select(POST_SELECT)
    .eq("id", id)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (data) {
    postMap.set(data.id, data);
  }

  return data || null;
}

// ------------------------------------------------------------
// Create post
// ------------------------------------------------------------

export async function createPost({
  content,
  imageUrl = null
} = {}) {
  const user = await requireUser();

  const safeContent =
    validateContent(content);

  const safeImageUrl =
    validateImageURL(imageUrl);

  creating = true;

  emit(EVENTS.CREATING, {
    content: safeContent
  });

  try {
    const { data, error } = await supabase
      .from("posts")
      .insert({
        user_id: user.id,
        content: safeContent,
        image_url: safeImageUrl
      })
      .select(POST_SELECT)
      .single();

    if (error) {
      throw error;
    }

    postMap.set(data.id, data);

    posts = [
      data,
      ...posts
    ];

    emit(EVENTS.CREATED, {
      post: data
    });

    emit(EVENTS.CHANGED, {
      action: "created",
      post: data
    });

    return data;
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "create",
      error
    });

    throw error;
  } finally {
    creating = false;
  }
}

// ------------------------------------------------------------
// Update post
// ------------------------------------------------------------

export async function updatePost(
  postId,
  {
    content,
    imageUrl
  } = {}
) {
  const user = await requireUser();
  const id = validatePostId(postId);

  const existing =
    await getPost(id);

  if (!existing) {
    throw new Error("Post not found.");
  }

  if (existing.user_id !== user.id) {
    throw new Error(
      "You can only edit your own posts."
    );
  }

  const updates = {};

  if (content !== undefined) {
    updates.content =
      validateContent(content);
  }

  if (imageUrl !== undefined) {
    updates.image_url =
      validateImageURL(imageUrl);
  }

  if (!Object.keys(updates).length) {
    return existing;
  }

  updating = true;

  emit(EVENTS.UPDATING, {
    postId: id
  });

  try {
    const { data, error } = await supabase
      .from("posts")
      .update(updates)
      .eq("id", id)
      .eq("user_id", user.id)
      .select(POST_SELECT)
      .single();

    if (error) {
      throw error;
    }

    postMap.set(id, data);

    posts = posts.map((post) =>
      post.id === id
        ? data
        : post
    );

    emit(EVENTS.UPDATED, {
      post: data
    });

    emit(EVENTS.CHANGED, {
      action: "updated",
      post: data
    });

    return data;
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "update",
      postId: id,
      error
    });

    throw error;
  } finally {
    updating = false;
  }
}

// ------------------------------------------------------------
// Delete post
// ------------------------------------------------------------

export async function deletePost(postId) {
  const user = await requireUser();
  const id = validatePostId(postId);

  const existing =
    await getPost(id);

  if (!existing) {
    throw new Error("Post not found.");
  }

  if (existing.user_id !== user.id) {
    throw new Error(
      "You can only delete your own posts."
    );
  }

  deleting = true;

  emit(EVENTS.DELETING, {
    postId: id
  });

  try {
    const { error } = await supabase
      .from("posts")
      .delete()
      .eq("id", id)
      .eq("user_id", user.id);

    if (error) {
      throw error;
    }

    postMap.delete(id);

    posts = posts.filter(
      (post) => post.id !== id
    );

    emit(EVENTS.DELETED, {
      postId: id,
      post: existing
    });

    emit(EVENTS.CHANGED, {
      action: "deleted",
      postId: id
    });

    return {
      success: true,
      postId: id
    };
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "delete",
      postId: id,
      error
    });

    throw error;
  } finally {
    deleting = false;
  }
}

// ------------------------------------------------------------
// Get posts by user
// ------------------------------------------------------------

export async function getUserPosts(
  userId,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  if (
    !userId ||
    typeof userId !== "string"
  ) {
    throw new Error(
      "A valid user ID is required."
    );
  }

  return loadPosts({
    limit,
    offset,
    userId: userId.trim()
  });
}

// ------------------------------------------------------------
// Get posts by IDs
// ------------------------------------------------------------

export async function getPostsByIds(
  postIds
) {
  if (!Array.isArray(postIds)) {
    throw new TypeError(
      "postIds must be an array."
    );
  }

  const ids = [
    ...new Set(
      postIds
        .filter(
          (id) =>
            typeof id === "string" &&
            id.trim()
        )
        .map((id) => id.trim())
    )
  ];

  if (!ids.length) {
    return [];
  }

  const { data, error } = await supabase
    .from("posts")
    .select(POST_SELECT)
    .in("id", ids)
    .order("created_at", {
      ascending: false
    });

  if (error) {
    throw error;
  }

  const result = data || [];

  result.forEach((post) => {
    postMap.set(post.id, post);
  });

  return result;
}

// ------------------------------------------------------------
// Search posts
// ------------------------------------------------------------

export async function searchPosts(
  search,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  const term = String(
    search || ""
  ).trim();

  if (!term) {
    return loadPosts({
      limit,
      offset
    });
  }

  const safeLimit =
    normalizeLimit(limit);

  const safeOffset = Math.max(
    Number(offset) || 0,
    0
  );

  const { data, error } =
    await supabase
      .from("posts")
      .select(POST_SELECT)
      .ilike(
        "content",
        `%${term}%`
      )
      .order("created_at", {
        ascending: false
      })
      .range(
        safeOffset,
        safeOffset + safeLimit - 1
      );

  if (error) {
    throw error;
  }

  const result = data || [];

  result.forEach((post) => {
    postMap.set(post.id, post);
  });

  return result;
}

// ------------------------------------------------------------
// Get post count
// ------------------------------------------------------------

export async function getPostCount(
  userId = null
) {
  let query = supabase
    .from("posts")
    .select("id", {
      count: "exact",
      head: true
    });

  if (userId) {
    query = query.eq(
      "user_id",
      userId
    );
  }

  const { count, error } =
    await query;

  if (error) {
    throw error;
  }

  return count || 0;
}

// ------------------------------------------------------------
// Refresh feed
// ------------------------------------------------------------

export async function refreshPosts({
  limit = DEFAULT_LIMIT
} = {}) {
  const result =
    await loadPosts({
      limit,
      offset: 0
    });

  emit(EVENTS.REFRESHED, {
    data: result,
    hasMore
  });

  return result;
}

// ------------------------------------------------------------
// Realtime
// ------------------------------------------------------------

export function subscribeToPosts() {
  if (realtimeChannel) {
    return realtimeChannel;
  }

  realtimeChannel = supabase
    .channel("regenesis-social-posts")
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "posts"
      },
      async (payload) => {
        try {
          const post =
            await getPost(
              payload.new?.id
            );

          if (!post) {
            return;
          }

          postMap.set(
            post.id,
            post
          );

          const exists =
            posts.some(
              (item) =>
                item.id === post.id
            );

          if (!exists) {
            posts = [
              post,
              ...posts
            ];
          }

          emit(
            EVENTS.REALTIME_UPDATE,
            {
              event: "INSERT",
              post
            }
          );

          emit(EVENTS.CHANGED, {
            action: "created",
            post
          });
        } catch (error) {
          emit(EVENTS.ERROR, {
            action: "realtime_insert",
            error
          });
        }
      }
    )
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "posts"
      },
      async (payload) => {
        try {
          const post =
            await getPost(
              payload.new?.id
            );

          if (!post) {
            return;
          }

          postMap.set(
            post.id,
            post
          );

          posts = posts.map(
            (item) =>
              item.id === post.id
                ? post
                : item
          );

          emit(
            EVENTS.REALTIME_UPDATE,
            {
              event: "UPDATE",
              post
            }
          );

          emit(EVENTS.CHANGED, {
            action: "updated",
            post
          });
        } catch (error) {
          emit(EVENTS.ERROR, {
            action: "realtime_update",
            error
          });
        }
      }
    )
    .on(
      "postgres_changes",
      {
        event: "DELETE",
        schema: "public",
        table: "posts"
      },
      (payload) => {
        try {
          const deletedId =
            payload.old?.id;

          if (!deletedId) {
            return;
          }

          postMap.delete(
            deletedId
          );

          posts = posts.filter(
            (post) =>
              post.id !== deletedId
          );

          emit(
            EVENTS.REALTIME_UPDATE,
            {
              event: "DELETE",
              postId: deletedId
            }
          );

          emit(EVENTS.CHANGED, {
            action: "deleted",
            postId: deletedId
          });
        } catch (error) {
          emit(EVENTS.ERROR, {
            action: "realtime_delete",
            error
          });
        }
      }
    )
    .subscribe(
      (status, error) => {
        if (
          status === "CHANNEL_ERROR" ||
          status === "TIMED_OUT"
        ) {
          emit(EVENTS.ERROR, {
            action: "realtime",
            error
          });
        }
      }
    );

  return realtimeChannel;
}

// ------------------------------------------------------------
// Stop realtime
// ------------------------------------------------------------

export async function unsubscribeFromPosts() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "REGENESIS posts channel removal error:",
      error
    );
  }

  realtimeChannel = null;
}

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

export async function initializePosts({
  realtime = true,
  load = true,
  limit = DEFAULT_LIMIT
} = {}) {
  await getCurrentUser();

  if (realtime) {
    subscribeToPosts();
  }

  if (load) {
    await loadPosts({
      limit,
      offset: 0
    });
  }

  return {
    user: currentUser,
    posts: [...posts],
    hasMore
  };
}

// ------------------------------------------------------------
// Clear posts
// ------------------------------------------------------------

export function clearPosts() {
  posts = [];
  postMap.clear();

  currentOffset = 0;
  hasMore = true;

  emit(EVENTS.CHANGED, {
    action: "clear"
  });
}

// ------------------------------------------------------------
// Getters
// ------------------------------------------------------------

export function getCachedPosts() {
  return [...posts];
}

export function getCachedPost(
  postId
) {
  const id = validatePostId(postId);

  return postMap.get(id) || null;
}

export function getPostCountCached() {
  return posts.length;
}

export function hasMorePosts() {
  return hasMore;
}

export function isLoadingPosts() {
  return loading;
}

export function isLoadingMorePosts() {
  return loadingMore;
}

export function isCreatingPost() {
  return creating;
}

export function isUpdatingPost() {
  return updating;
}

export function isDeletingPost() {
  return deleting;
}

export function getCurrentOffset() {
  return currentOffset;
}

// ------------------------------------------------------------
// Destroy
// ------------------------------------------------------------

export async function destroyPosts() {
  await unsubscribeFromPosts();

  clearPosts();

  currentUser = null;

  loading = false;
  loadingMore = false;
  creating = false;
  updating = false;
  deleting = false;

  listeners.clear();
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  EVENTS,

  onPostsChange,

  getCurrentUser,
  getCachedUser,

  loadPosts,
  loadMore,

  getPost,

  createPost,
  updatePost,
  deletePost,

  getUserPosts,
  getPostsByIds,
  searchPosts,
  getPostCount,

  refreshPosts,

  subscribeToPosts,
  unsubscribeFromPosts,

  initializePosts,
  clearPosts,

  getCachedPosts,
  getCachedPost,
  getPostCountCached,
  hasMorePosts,
  isLoadingPosts,
  isLoadingMorePosts,
  isCreatingPost,
  isUpdatingPost,
  isDeletingPost,
  getCurrentOffset,

  destroyPosts
};