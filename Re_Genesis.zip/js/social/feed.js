// ============================================================
// REGENESIS
// js/social/feed.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const POSTS_TABLE = "posts";
const LIKES_TABLE = "likes";
const COMMENTS_TABLE = "comments";

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 50;

const MAX_POST_LENGTH = 5000;


// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;

let posts = [];
let postMap = new Map();

let loading = false;
let loadingMore = false;

let hasMore = true;
let currentOffset = 0;

let realtimeChannel = null;

const listeners = new Set();


// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const FEED_EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",
  LOADING_MORE: "loading_more",
  MORE_LOADED: "more_loaded",

  POST_CREATED: "post_created",
  POST_UPDATED: "post_updated",
  POST_DELETED: "post_deleted",

  LIKE_UPDATED: "like_updated",
  COMMENT_UPDATED: "comment_updated",

  REFRESHED: "refreshed",
  REALTIME_UPDATE: "realtime_update",

  ERROR: "error",
  CHANGED: "changed"
};


// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onFeedChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(event, data = null) {
  listeners.forEach((callback) => {
    try {
      callback({
        event,
        data,
        state: getState()
      });
    } catch (error) {
      console.error(
        "REGENESIS feed listener error:",
        error
      );
    }
  });
}


// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const {
    data,
    error
  } = await supabase.auth.getUser();

  if (error) {
    throw error;
  }

  currentUser = data?.user || null;

  return currentUser;
}

export function getCachedUser() {
  return currentUser;
}


// ------------------------------------------------------------
// Helpers
// ------------------------------------------------------------

function normalizeLimit(limit) {
  return Math.min(
    Math.max(
      Number(limit) || DEFAULT_LIMIT,
      1
    ),
    MAX_LIMIT
  );
}

function normalizeOffset(offset) {
  return Math.max(
    Number(offset) || 0,
    0
  );
}

function validatePostContent(content) {
  const value =
    String(content || "").trim();

  if (!value) {
    throw new Error(
      "Post cannot be empty."
    );
  }

  if (value.length > MAX_POST_LENGTH) {
    throw new Error(
      `Post cannot exceed ${MAX_POST_LENGTH} characters.`
    );
  }

  return value;
}

function rebuildPostMap() {
  postMap = new Map();

  posts.forEach((post) => {
    postMap.set(
      String(post.id),
      post
    );
  });
}

function replacePost(post) {
  const index =
    posts.findIndex(
      (item) =>
        String(item.id) ===
        String(post.id)
    );

  if (index === -1) {
    posts.unshift(post);
  } else {
    posts[index] = {
      ...posts[index],
      ...post
    };
  }

  rebuildPostMap();
}

function removePostLocally(postId) {
  posts = posts.filter(
    (post) =>
      String(post.id) !==
      String(postId)
  );

  rebuildPostMap();
}


// ------------------------------------------------------------
// Post select
// ------------------------------------------------------------

const POST_SELECT = `
  id,
  user_id,
  content,
  image_url,
  created_at,
  updated_at,
  profiles (
    id,
    username,
    display_name,
    avatar_url
  )
`;


// ------------------------------------------------------------
// Load feed
// ------------------------------------------------------------

export async function loadFeed({
  limit = DEFAULT_LIMIT,
  offset = 0
} = {}) {
  limit = normalizeLimit(limit);
  offset = normalizeOffset(offset);

  loading = true;

  emit(
    FEED_EVENTS.LOADING,
    {
      limit,
      offset
    }
  );

  try {
    const {
      data,
      error
    } = await supabase
      .from(POSTS_TABLE)
      .select(POST_SELECT)
      .order("created_at", {
        ascending: false
      })
      .range(
        offset,
        offset + limit - 1
      );

    if (error) {
      throw error;
    }

    const loadedPosts =
      data || [];

    posts = loadedPosts;

    rebuildPostMap();

    await enrichPosts(posts);

    currentOffset =
      offset + loadedPosts.length;

    hasMore =
      loadedPosts.length === limit;

    emit(
      FEED_EVENTS.LOADED,
      posts
    );

    emit(
      FEED_EVENTS.CHANGED,
      posts
    );

    return posts;

  } catch (error) {
    emit(
      FEED_EVENTS.ERROR,
      error
    );

    throw error;

  } finally {
    loading = false;
  }
}


// ------------------------------------------------------------
// Load more
// ------------------------------------------------------------

export async function loadMore({
  limit = DEFAULT_LIMIT
} = {}) {
  if (loadingMore || !hasMore) {
    return [];
  }

  limit = normalizeLimit(limit);

  loadingMore = true;

  emit(
    FEED_EVENTS.LOADING_MORE,
    {
      limit,
      offset: currentOffset
    }
  );

  try {
    const {
      data,
      error
    } = await supabase
      .from(POSTS_TABLE)
      .select(POST_SELECT)
      .order("created_at", {
        ascending: false
      })
      .range(
        currentOffset,
        currentOffset + limit - 1
      );

    if (error) {
      throw error;
    }

    const newPosts =
      data || [];

    await enrichPosts(
      newPosts
    );

    const existingIds =
      new Set(
        posts.map(
          (post) =>
            String(post.id)
        )
      );

    newPosts.forEach((post) => {
      if (
        !existingIds.has(
          String(post.id)
        )
      ) {
        posts.push(post);
      }
    });

    rebuildPostMap();

    currentOffset +=
      newPosts.length;

    hasMore =
      newPosts.length === limit;

    emit(
      FEED_EVENTS.MORE_LOADED,
      newPosts
    );

    emit(
      FEED_EVENTS.CHANGED,
      posts
    );

    return newPosts;

  } catch (error) {
    emit(
      FEED_EVENTS.ERROR,
      error
    );

    throw error;

  } finally {
    loadingMore = false;
  }
}


// ------------------------------------------------------------
// Get one post
// ------------------------------------------------------------

export async function getPost(
  postId
) {
  if (!postId) {
    throw new Error(
      "Post ID is required."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from(POSTS_TABLE)
    .select(POST_SELECT)
    .eq("id", postId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    return null;
  }

  await enrichPosts([
    data
  ]);

  return data;
}


// ------------------------------------------------------------
// Create post
// ------------------------------------------------------------

export async function createPost({
  content,
  imageUrl = null
} = {}) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to create a post."
    );
  }

  const validContent =
    validatePostContent(content);

  const {
    data,
    error
  } = await supabase
    .from(POSTS_TABLE)
    .insert({
      user_id: user.id,
      content: validContent,
      image_url: imageUrl || null
    })
    .select(POST_SELECT)
    .single();

  if (error) {
    throw error;
  }

  const newPost = {
    ...data,
    like_count: 0,
    comment_count: 0,
    liked_by_me: false
  };

  replacePost(
    newPost
  );

  emit(
    FEED_EVENTS.POST_CREATED,
    newPost
  );

  emit(
    FEED_EVENTS.CHANGED,
    posts
  );

  return newPost;
}


// ------------------------------------------------------------
// Update post
// ------------------------------------------------------------

export async function updatePost(
  postId,
  {
    content,
    imageUrl
  } = {}
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const updateData = {};

  if (content !== undefined) {
    updateData.content =
      validatePostContent(
        content
      );
  }

  if (imageUrl !== undefined) {
    updateData.image_url =
      imageUrl || null;
  }

  updateData.updated_at =
    new Date().toISOString();

  const {
    data,
    error
  } = await supabase
    .from(POSTS_TABLE)
    .update(updateData)
    .eq("id", postId)
    .eq("user_id", user.id)
    .select(POST_SELECT)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Post not found or you do not own this post."
    );
  }

  const oldPost =
    postMap.get(
      String(postId)
    );

  const updatedPost = {
    ...data,
    like_count:
      oldPost?.like_count || 0,
    comment_count:
      oldPost?.comment_count || 0,
    liked_by_me:
      oldPost?.liked_by_me || false
  };

  replacePost(
    updatedPost
  );

  emit(
    FEED_EVENTS.POST_UPDATED,
    updatedPost
  );

  emit(
    FEED_EVENTS.CHANGED,
    posts
  );

  return updatedPost;
}


// ------------------------------------------------------------
// Delete post
// ------------------------------------------------------------

export async function deletePost(
  postId
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from(POSTS_TABLE)
    .delete()
    .eq("id", postId)
    .eq("user_id", user.id)
    .select("id")
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Post not found or you do not own this post."
    );
  }

  removePostLocally(
    postId
  );

  emit(
    FEED_EVENTS.POST_DELETED,
    {
      id: postId
    }
  );

  emit(
    FEED_EVENTS.CHANGED,
    posts
  );

  return true;
}


// ------------------------------------------------------------
// Enrich posts with likes/comments
// ------------------------------------------------------------

async function enrichPosts(
  postList
) {
  if (!postList.length) {
    return;
  }

  const ids =
    postList.map(
      (post) => post.id
    );

  // ----------------------------------------------------------
  // Likes
  // ----------------------------------------------------------

  let likeRows = [];

  try {
    const {
      data,
      error
    } = await supabase
      .from(LIKES_TABLE)
      .select(
        "id, post_id, user_id"
      )
      .in(
        "post_id",
        ids
      );

    if (!error) {
      likeRows = data || [];
    }
  } catch {
    likeRows = [];
  }

  const likeCounts =
    new Map();

  const likedByMe =
    new Set();

  likeRows.forEach((like) => {
    const id =
      String(like.post_id);

    likeCounts.set(
      id,
      (likeCounts.get(id) || 0) + 1
    );

    if (
      currentUser &&
      like.user_id ===
        currentUser.id
    ) {
      likedByMe.add(id);
    }
  });


  // ----------------------------------------------------------
  // Comments
  // ----------------------------------------------------------

  let commentRows = [];

  try {
    const {
      data,
      error
    } = await supabase
      .from(COMMENTS_TABLE)
      .select("id, post_id")
      .in(
        "post_id",
        ids
      );

    if (!error) {
      commentRows =
        data || [];
    }
  } catch {
    commentRows = [];
  }

  const commentCounts =
    new Map();

  commentRows.forEach(
    (comment) => {
      const id =
        String(comment.post_id);

      commentCounts.set(
        id,
        (commentCounts.get(id) || 0) + 1
      );
    }
  );


  // ----------------------------------------------------------
  // Apply
  // ----------------------------------------------------------

  postList.forEach((post) => {
    post.like_count =
      likeCounts.get(
        String(post.id)
      ) || 0;

    post.comment_count =
      commentCounts.get(
        String(post.id)
      ) || 0;

    post.liked_by_me =
      likedByMe.has(
        String(post.id)
      );
  });

  rebuildPostMap();
}


// ------------------------------------------------------------
// Like post
// ------------------------------------------------------------

export async function likePost(
  postId
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to like posts."
    );
  }

  const {
    error
  } = await supabase
    .from(LIKES_TABLE)
    .insert({
      post_id: postId,
      user_id: user.id
    });

  if (error) {
    // Unique constraint:
    // one like per user per post.
    if (error.code === "23505") {
      return true;
    }

    throw error;
  }

  const post =
    postMap.get(
      String(postId)
    );

  if (post) {
    post.like_count =
      (post.like_count || 0) + 1;

    post.liked_by_me = true;

    rebuildPostMap();
  }

  emit(
    FEED_EVENTS.LIKE_UPDATED,
    {
      postId,
      liked: true
    }
  );

  emit(
    FEED_EVENTS.CHANGED,
    posts
  );

  return true;
}


// ------------------------------------------------------------
// Unlike post
// ------------------------------------------------------------

export async function unlikePost(
  postId
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to unlike posts."
    );
  }

  const {
    error
  } = await supabase
    .from(LIKES_TABLE)
    .delete()
    .eq(
      "post_id",
      postId
    )
    .eq(
      "user_id",
      user.id
    );

  if (error) {
    throw error;
  }

  const post =
    postMap.get(
      String(postId)
    );

  if (post) {
    post.like_count =
      Math.max(
        (post.like_count || 0) - 1,
        0
      );

    post.liked_by_me = false;

    rebuildPostMap();
  }

  emit(
    FEED_EVENTS.LIKE_UPDATED,
    {
      postId,
      liked: false
    }
  );

  emit(
    FEED_EVENTS.CHANGED,
    posts
  );

  return true;
}


// ------------------------------------------------------------
// Toggle post like
// ------------------------------------------------------------

export async function toggleLike(
  postId
) {
  const post =
    postMap.get(
      String(postId)
    );

  if (post?.liked_by_me) {
    await unlikePost(
      postId
    );

    return false;
  }

  await likePost(
    postId
  );

  return true;
}


// ------------------------------------------------------------
// Check if current user liked post
// ------------------------------------------------------------

export async function hasLikedPost(
  postId
) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    return false;
  }

  const {
    data,
    error
  } = await supabase
    .from(LIKES_TABLE)
    .select("id")
    .eq(
      "post_id",
      postId
    )
    .eq(
      "user_id",
      user.id
    )
    .maybeSingle();

  if (error) {
    throw error;
  }

  return Boolean(data);
}


// ------------------------------------------------------------
// Get like count
// ------------------------------------------------------------

export async function getLikeCount(
  postId
) {
  const {
    count,
    error
  } = await supabase
    .from(LIKES_TABLE)
    .select("id", {
      count: "exact",
      head: true
    })
    .eq(
      "post_id",
      postId
    );

  if (error) {
    throw error;
  }

  return count || 0;
}


// ------------------------------------------------------------
// Get comment count
// ------------------------------------------------------------

export async function getCommentCount(
  postId
) {
  const {
    count,
    error
  } = await supabase
    .from(COMMENTS_TABLE)
    .select("id", {
      count: "exact",
      head: true
    })
    .eq(
      "post_id",
      postId
    );

  if (error) {
    throw error;
  }

  return count || 0;
}


// ------------------------------------------------------------
// Get user's posts
// ------------------------------------------------------------

export async function getUserPosts(
  userId,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  if (!userId) {
    throw new Error(
      "User ID is required."
    );
  }

  limit = normalizeLimit(limit);
  offset = normalizeOffset(offset);

  const {
    data,
    error
  } = await supabase
    .from(POSTS_TABLE)
    .select(POST_SELECT)
    .eq(
      "user_id",
      userId
    )
    .order("created_at", {
      ascending: false
    })
    .range(
      offset,
      offset + limit - 1
    );

  if (error) {
    throw error;
  }

  const userPosts =
    data || [];

  await enrichPosts(
    userPosts
  );

  return userPosts;
}


// ------------------------------------------------------------
// Get posts by IDs
// ------------------------------------------------------------

export async function getPostsByIds(
  postIds
) {
  if (
    !Array.isArray(postIds) ||
    postIds.length === 0
  ) {
    return [];
  }

  const {
    data,
    error
  } = await supabase
    .from(POSTS_TABLE)
    .select(POST_SELECT)
    .in(
      "id",
      postIds
    )
    .order("created_at", {
      ascending: false
    });

  if (error) {
    throw error;
  }

  const result =
    data || [];

  await enrichPosts(
    result
  );

  return result;
}


// ------------------------------------------------------------
// Search posts
// ------------------------------------------------------------

export async function searchPosts(
  query,
  {
    limit = DEFAULT_LIMIT,
    offset = 0
  } = {}
) {
  const value =
    String(query || "")
      .trim();

  if (!value) {
    return [];
  }

  limit = normalizeLimit(limit);
  offset = normalizeOffset(offset);

  const escaped =
    value
      .replace(/\\/g, "\\\\")
      .replace(/%/g, "\\%")
      .replace(/_/g, "\\_");

  const pattern =
    `%${escaped}%`;

  const {
    data,
    error
  } = await supabase
    .from(POSTS_TABLE)
    .select(POST_SELECT)
    .ilike(
      "content",
      pattern
    )
    .order("created_at", {
      ascending: false
    })
    .range(
      offset,
      offset + limit - 1
    );

  if (error) {
    throw error;
  }

  const result =
    data || [];

  await enrichPosts(
    result
  );

  return result;
}


// ------------------------------------------------------------
// Refresh feed
// ------------------------------------------------------------

export async function refreshFeed({
  limit = DEFAULT_LIMIT
} = {}) {
  const result =
    await loadFeed({
      limit,
      offset: 0
    });

  emit(
    FEED_EVENTS.REFRESHED,
    result
  );

  return result;
}


// ------------------------------------------------------------
// Realtime: fetch updated post
// ------------------------------------------------------------

async function refreshRealtimePost(
  postId
) {
  try {
    const post =
      await getPost(
        postId
      );

    if (!post) {
      removePostLocally(
        postId
      );

      emit(
        FEED_EVENTS.POST_DELETED,
        {
          id: postId
        }
      );
    } else {
      replacePost(
        post
      );

      emit(
        FEED_EVENTS.POST_UPDATED,
        post
      );
    }

    emit(
      FEED_EVENTS.REALTIME_UPDATE,
      post
    );

    emit(
      FEED_EVENTS.CHANGED,
      posts
    );

  } catch (error) {
    console.warn(
      "Could not refresh realtime post:",
      error
    );
  }
}


// ------------------------------------------------------------
// Subscribe to realtime feed
// ------------------------------------------------------------

export function subscribeToFeed() {
  unsubscribeFromFeed();

  realtimeChannel =
    supabase
      .channel(
        `regenesis-feed-${Date.now()}`
      )

      // New posts
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: POSTS_TABLE
        },
        async (payload) => {
          if (!payload?.new?.id) {
            return;
          }

          const exists =
            postMap.has(
              String(payload.new.id)
            );

          if (exists) {
            return;
          }

          await refreshRealtimePost(
            payload.new.id
          );
        }
      )

      // Updated posts
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: POSTS_TABLE
        },
        async (payload) => {
          if (!payload?.new?.id) {
            return;
          }

          await refreshRealtimePost(
            payload.new.id
          );
        }
      )

      // Deleted posts
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: POSTS_TABLE
        },
        (payload) => {
          const id =
            payload?.old?.id;

          if (!id) {
            return;
          }

          if (
            postMap.has(
              String(id)
            )
          ) {
            removePostLocally(
              id
            );

            emit(
              FEED_EVENTS.POST_DELETED,
              { id }
            );

            emit(
              FEED_EVENTS.CHANGED,
              posts
            );
          }
        }
      )

      // Likes
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: LIKES_TABLE
        },
        async (payload) => {
          const postId =
            payload?.new?.post_id ||
            payload?.old?.post_id;

          if (!postId) {
            return;
          }

          const post =
            postMap.get(
              String(postId)
            );

          if (!post) {
            return;
          }

          try {
            post.like_count =
              await getLikeCount(
                postId
              );

            post.liked_by_me =
              await hasLikedPost(
                postId
              );

            rebuildPostMap();

            emit(
              FEED_EVENTS.LIKE_UPDATED,
              {
                postId,
                count:
                  post.like_count,
                liked:
                  post.liked_by_me
              }
            );

            emit(
              FEED_EVENTS.CHANGED,
              posts
            );

          } catch (error) {
            console.warn(
              "Could not refresh post like state:",
              error
            );
          }
        }
      )

      // Comments
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: COMMENTS_TABLE
        },
        async (payload) => {
          const postId =
            payload?.new?.post_id ||
            payload?.old?.post_id;

          if (!postId) {
            return;
          }

          const post =
            postMap.get(
              String(postId)
            );

          if (!post) {
            return;
          }

          try {
            post.comment_count =
              await getCommentCount(
                postId
              );

            rebuildPostMap();

            emit(
              FEED_EVENTS.COMMENT_UPDATED,
              {
                postId,
                count:
                  post.comment_count
              }
            );

            emit(
              FEED_EVENTS.CHANGED,
              posts
            );

          } catch (error) {
            console.warn(
              "Could not refresh comment count:",
              error
            );
          }
        }
      )

      .subscribe(
        (status) => {
          if (
            status === "SUBSCRIBED"
          ) {
            console.log(
              "REGENESIS feed realtime connected."
            );
          }

          if (
            status === "CHANNEL_ERROR"
          ) {
            console.warn(
              "REGENESIS feed realtime channel error."
            );
          }

          if (
            status === "TIMED_OUT"
          ) {
            console.warn(
              "REGENESIS feed realtime timed out."
            );
          }
        }
      );

  return realtimeChannel;
}


// ------------------------------------------------------------
// Unsubscribe
// ------------------------------------------------------------

export async function unsubscribeFromFeed() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.warn(
      "Could not remove feed realtime channel:",
      error
    );
  }

  realtimeChannel = null;
}


// ------------------------------------------------------------
// Initialize feed
// ------------------------------------------------------------

export async function initializeFeed({
  limit = DEFAULT_LIMIT,
  realtime = true
} = {}) {
  try {
    await getCurrentUser();
  } catch {
    currentUser = null;
  }

  const result =
    await loadFeed({
      limit,
      offset: 0
    });

  if (realtime) {
    subscribeToFeed();
  }

  return result;
}


// ------------------------------------------------------------
// Clear feed
// ------------------------------------------------------------

export function clearFeed() {
  posts = [];
  postMap.clear();

  currentOffset = 0;
  hasMore = true;

  emit(
    FEED_EVENTS.CHANGED,
    posts
  );
}


// ------------------------------------------------------------
// Get cached post
// ------------------------------------------------------------

export function getCachedPost(
  postId
) {
  if (!postId) {
    return null;
  }

  return (
    postMap.get(
      String(postId)
    ) || null
  );
}


// ------------------------------------------------------------
// Get posts
// ------------------------------------------------------------

export function getPosts() {
  return [
    ...posts
  ];
}


// ------------------------------------------------------------
// Get feed state
// ------------------------------------------------------------

export function getState() {
  return {
    currentUser,

    posts: [
      ...posts
    ],

    loading,
    loadingMore,

    hasMore,
    currentOffset,

    realtimeConnected:
      Boolean(realtimeChannel)
  };
}


// ------------------------------------------------------------
// Getters
// ------------------------------------------------------------

export function isLoading() {
  return loading;
}

export function isLoadingMore() {
  return loadingMore;
}

export function canLoadMore() {
  return hasMore &&
    !loadingMore;
}

export function getCurrentOffset() {
  return currentOffset;
}

export function hasMorePosts() {
  return hasMore;
}


// ------------------------------------------------------------
// Cleanup
// ------------------------------------------------------------

export async function destroyFeed() {
  await unsubscribeFromFeed();

  currentUser = null;

  posts = [];
  postMap.clear();

  loading = false;
  loadingMore = false;

  hasMore = true;
  currentOffset = 0;

  listeners.clear();
}


// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  // Authentication
  getCurrentUser,
  getCachedUser,

  // Feed
  loadFeed,
  loadMore,
  refreshFeed,
  initializeFeed,
  clearFeed,
  destroyFeed,

  // Posts
  getPost,
  getPosts,
  getCachedPost,
  getUserPosts,
  getPostsByIds,
  searchPosts,

  createPost,
  updatePost,
  deletePost,

  // Likes
  likePost,
  unlikePost,
  toggleLike,
  hasLikedPost,
  getLikeCount,

  // Comments
  getCommentCount,

  // Realtime
  subscribeToFeed,
  unsubscribeFromFeed,

  // State
  getState,
  isLoading,
  isLoadingMore,
  canLoadMore,
  getCurrentOffset,
  hasMorePosts,

  // Events
  onFeedChange
};