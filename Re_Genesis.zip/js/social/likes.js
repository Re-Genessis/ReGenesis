// ============================================================
// REGENESIS - Social Likes
// File: js/social/likes.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;

// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentUser = null;

const likedPosts = new Set();
const likeCounts = new Map();

let loading = false;
let realtimeChannel = null;

const listeners = new Set();

// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const EVENTS = {
  LOADING: "loading",
  LOADED: "loaded",

  LIKED: "liked",
  UNLIKED: "unliked",

  COUNT_UPDATED: "count_updated",
  STATUS_UPDATED: "status_updated",

  REALTIME_UPDATE: "realtime_update",

  CHANGED: "changed",
  ERROR: "error"
};

// ------------------------------------------------------------
// Event listeners
// ------------------------------------------------------------

export function onLikesChange(callback) {
  if (typeof callback !== "function") {
    throw new TypeError("callback must be a function");
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(type, payload = {}) {
  const event = {
    type,
    ...payload
  };

  listeners.forEach((callback) => {
    try {
      callback(event);
    } catch (error) {
      console.error(
        "REGENESIS likes listener error:",
        error
      );
    }
  });
}

// ------------------------------------------------------------
// Authentication
// ------------------------------------------------------------

export async function getCurrentUser() {
  const { data, error } =
    await supabase.auth.getUser();

  if (error) {
    currentUser = null;
    return null;
  }

  currentUser = data?.user || null;

  return currentUser;
}

export function getCachedUser() {
  return currentUser;
}

async function requireUser() {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in to like posts."
    );
  }

  return user;
}

// ------------------------------------------------------------
// Validation
// ------------------------------------------------------------

function validatePostId(postId) {
  if (
    !postId ||
    typeof postId !== "string" ||
    !postId.trim()
  ) {
    throw new Error("A valid post ID is required.");
  }

  return postId.trim();
}

function normalizeLimit(limit) {
  const value = Number(limit);

  if (!Number.isFinite(value)) {
    return DEFAULT_LIMIT;
  }

  return Math.min(
    Math.max(Math.floor(value), 1),
    MAX_LIMIT
  );
}

// ------------------------------------------------------------
// Check if current user liked a post
// ------------------------------------------------------------

export async function hasLikedPost(postId) {
  const user = await requireUser();
  const id = validatePostId(postId);

  if (likedPosts.has(id)) {
    return true;
  }

  const { data, error } = await supabase
    .from("likes")
    .select("id")
    .eq("post_id", id)
    .eq("user_id", user.id)
    .maybeSingle();

  if (error) {
    throw error;
  }

  const liked = Boolean(data);

  if (liked) {
    likedPosts.add(id);
  } else {
    likedPosts.delete(id);
  }

  emit(EVENTS.STATUS_UPDATED, {
    postId: id,
    liked
  });

  return liked;
}

// ------------------------------------------------------------
// Get like count
// ------------------------------------------------------------

export async function getLikeCount(postId) {
  const id = validatePostId(postId);

  if (likeCounts.has(id)) {
    return likeCounts.get(id);
  }

  const { count, error } = await supabase
    .from("likes")
    .select("id", {
      count: "exact",
      head: true
    })
    .eq("post_id", id);

  if (error) {
    throw error;
  }

  const total = count || 0;

  likeCounts.set(id, total);

  return total;
}

// ------------------------------------------------------------
// Get multiple like counts
// ------------------------------------------------------------

export async function getLikeCounts(postIds) {
  if (!Array.isArray(postIds)) {
    throw new TypeError(
      "postIds must be an array."
    );
  }

  const ids = [
    ...new Set(
      postIds
        .filter(
          (id) =>
            typeof id === "string" &&
            id.trim()
        )
        .map((id) => id.trim())
    )
  ];

  if (!ids.length) {
    return {};
  }

  const { data, error } = await supabase
    .from("likes")
    .select("post_id")
    .in("post_id", ids);

  if (error) {
    throw error;
  }

  const counts = {};

  ids.forEach((id) => {
    counts[id] = 0;
  });

  (data || []).forEach((like) => {
    if (likeCounts.has(like.post_id)) {
      likeCounts.set(
        like.post_id,
        likeCounts.get(like.post_id) + 1
      );
    } else {
      likeCounts.set(like.post_id, 1);
    }

    counts[like.post_id] =
      (counts[like.post_id] || 0) + 1;
  });

  ids.forEach((id) => {
    if (!counts[id]) {
      likeCounts.set(id, 0);
    }
  });

  return counts;
}

// ------------------------------------------------------------
// Get posts liked by current user
// ------------------------------------------------------------

export async function getMyLikedPosts({
  limit = DEFAULT_LIMIT,
  offset = 0
} = {}) {
  const user = await requireUser();

  const safeLimit = normalizeLimit(limit);
  const safeOffset = Math.max(
    Number(offset) || 0,
    0
  );

  const { data, error } = await supabase
    .from("likes")
    .select(`
      id,
      post_id,
      user_id,
      created_at
    `)
    .eq("user_id", user.id)
    .order("created_at", {
      ascending: false
    })
    .range(
      safeOffset,
      safeOffset + safeLimit - 1
    );

  if (error) {
    throw error;
  }

  return data || [];
}

// ------------------------------------------------------------
// Like a post
// ------------------------------------------------------------

export async function likePost(postId) {
  const user = await requireUser();
  const id = validatePostId(postId);

  if (likedPosts.has(id)) {
    return {
      success: true,
      alreadyLiked: true,
      postId: id
    };
  }

  const existing = await supabase
    .from("likes")
    .select("id")
    .eq("post_id", id)
    .eq("user_id", user.id)
    .maybeSingle();

  if (existing.error) {
    throw existing.error;
  }

  if (existing.data) {
    likedPosts.add(id);

    return {
      success: true,
      alreadyLiked: true,
      postId: id
    };
  }

  const { data, error } = await supabase
    .from("likes")
    .insert({
      post_id: id,
      user_id: user.id
    })
    .select()
    .single();

  if (error) {
    // Unique constraint:
    // one user can only like a post once.
    if (error.code === "23505") {
      likedPosts.add(id);

      return {
        success: true,
        alreadyLiked: true,
        postId: id
      };
    }

    emit(EVENTS.ERROR, {
      action: "like",
      postId: id,
      error
    });

    throw error;
  }

  likedPosts.add(id);

  const previousCount =
    likeCounts.get(id) || 0;

  likeCounts.set(
    id,
    previousCount + 1
  );

  emit(EVENTS.LIKED, {
    postId: id,
    like: data,
    count: previousCount + 1
  });

  emit(EVENTS.COUNT_UPDATED, {
    postId: id,
    count: previousCount + 1
  });

  emit(EVENTS.CHANGED, {
    action: "liked",
    postId: id
  });

  return {
    success: true,
    alreadyLiked: false,
    data,
    count: previousCount + 1
  };
}

// ------------------------------------------------------------
// Unlike a post
// ------------------------------------------------------------

export async function unlikePost(postId) {
  const user = await requireUser();
  const id = validatePostId(postId);

  const { error } = await supabase
    .from("likes")
    .delete()
    .eq("post_id", id)
    .eq("user_id", user.id);

  if (error) {
    emit(EVENTS.ERROR, {
      action: "unlike",
      postId: id,
      error
    });

    throw error;
  }

  likedPosts.delete(id);

  const previousCount =
    likeCounts.get(id) || 0;

  const newCount = Math.max(
    previousCount - 1,
    0
  );

  likeCounts.set(id, newCount);

  emit(EVENTS.UNLIKED, {
    postId: id,
    count: newCount
  });

  emit(EVENTS.COUNT_UPDATED, {
    postId: id,
    count: newCount
  });

  emit(EVENTS.CHANGED, {
    action: "unliked",
    postId: id
  });

  return {
    success: true,
    postId: id,
    count: newCount
  };
}

// ------------------------------------------------------------
// Toggle like
// ------------------------------------------------------------

export async function toggleLike(postId) {
  const id = validatePostId(postId);

  const liked = await hasLikedPost(id);

  if (liked) {
    return unlikePost(id);
  }

  return likePost(id);
}

// ------------------------------------------------------------
// Load like status for multiple posts
// ------------------------------------------------------------

export async function loadLikeStatuses(postIds) {
  const user = await requireUser();

  if (!Array.isArray(postIds)) {
    throw new TypeError(
      "postIds must be an array."
    );
  }

  const ids = [
    ...new Set(
      postIds
        .filter(
          (id) =>
            typeof id === "string" &&
            id.trim()
        )
        .map((id) => id.trim())
    )
  ];

  if (!ids.length) {
    return {};
  }

  loading = true;

  emit(EVENTS.LOADING, {
    type: "statuses"
  });

  try {
    const { data, error } = await supabase
      .from("likes")
      .select(`
        post_id
      `)
      .eq("user_id", user.id)
      .in("post_id", ids);

    if (error) {
      throw error;
    }

    const result = {};

    ids.forEach((id) => {
      result[id] = false;
      likedPosts.delete(id);
    });

    (data || []).forEach((like) => {
      result[like.post_id] = true;
      likedPosts.add(like.post_id);
    });

    emit(EVENTS.STATUS_UPDATED, {
      statuses: result
    });

    emit(EVENTS.LOADED, {
      type: "statuses",
      data: result
    });

    return result;
  } catch (error) {
    emit(EVENTS.ERROR, {
      action: "loadLikeStatuses",
      error
    });

    throw error;
  } finally {
    loading = false;
  }
}

// ------------------------------------------------------------
// Load everything needed for a feed
// ------------------------------------------------------------

export async function loadLikesForPosts(
  postIds,
  {
    includeStatus = true
  } = {}
) {
  if (!Array.isArray(postIds)) {
    throw new TypeError(
      "postIds must be an array."
    );
  }

  const counts =
    await getLikeCounts(postIds);

  let statuses = {};

  if (includeStatus) {
    const user =
      currentUser || await getCurrentUser();

    if (user) {
      statuses =
        await loadLikeStatuses(postIds);
    }
  }

  return {
    counts,
    statuses
  };
}

// ------------------------------------------------------------
// Realtime
// ------------------------------------------------------------

export function subscribeToLikes() {
  if (realtimeChannel) {
    return realtimeChannel;
  }

  realtimeChannel = supabase
    .channel("regenesis-social-likes")
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "likes"
      },
      async (payload) => {
        try {
          const row =
            payload.new ||
            payload.old ||
            {};

          const postId =
            row.post_id;

          if (!postId) {
            return;
          }

          // Update cached count.
          const current =
            likeCounts.get(postId);

          if (
            payload.eventType === "INSERT"
          ) {
            if (typeof current === "number") {
              likeCounts.set(
                postId,
                current + 1
              );
            }

            if (
              currentUser &&
              row.user_id === currentUser.id
            ) {
              likedPosts.add(postId);
            }
          }

          if (
            payload.eventType === "DELETE"
          ) {
            if (typeof current === "number") {
              likeCounts.set(
                postId,
                Math.max(current - 1, 0)
              );
            }

            if (
              currentUser &&
              row.user_id === currentUser.id
            ) {
              likedPosts.delete(postId);
            }
          }

          const count =
            likeCounts.get(postId);

          emit(EVENTS.REALTIME_UPDATE, {
            event: payload.eventType,
            postId,
            userId: row.user_id,
            count,
            payload
          });

          emit(EVENTS.COUNT_UPDATED, {
            postId,
            count
          });

          emit(EVENTS.CHANGED, {
            action:
              payload.eventType?.toLowerCase(),
            postId
          });
        } catch (error) {
          emit(EVENTS.ERROR, {
            action: "realtime",
            error
          });
        }
      }
    )
    .subscribe((status, error) => {
      if (
        status === "CHANNEL_ERROR" ||
        status === "TIMED_OUT"
      ) {
        emit(EVENTS.ERROR, {
          action: "realtime",
          error
        });
      }
    });

  return realtimeChannel;
}

// ------------------------------------------------------------
// Stop realtime
// ------------------------------------------------------------

export async function unsubscribeFromLikes() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "REGENESIS likes channel removal error:",
      error
    );
  }

  realtimeChannel = null;
}

// ------------------------------------------------------------
// Refresh one post's like data
// ------------------------------------------------------------

export async function refreshLike(
  postId
) {
  const id = validatePostId(postId);

  const count =
    await getLikeCount(id);

  let liked = false;

  const user =
    currentUser || await getCurrentUser();

  if (user) {
    liked =
      await hasLikedPost(id);
  }

  emit(EVENTS.CHANGED, {
    action: "refresh",
    postId: id,
    count,
    liked
  });

  return {
    postId: id,
    count,
    liked
  };
}

// ------------------------------------------------------------
// Refresh multiple posts
// ------------------------------------------------------------

export async function refreshLikes(
  postIds
) {
  const result =
    await loadLikesForPosts(postIds);

  emit(EVENTS.CHANGED, {
    action: "refresh_multiple",
    ...result
  });

  return result;
}

// ------------------------------------------------------------
// Clear cache
// ------------------------------------------------------------

export function clearLikes() {
  likedPosts.clear();
  likeCounts.clear();

  emit(EVENTS.CHANGED, {
    action: "clear"
  });
}

// ------------------------------------------------------------
// Cached helpers
// ------------------------------------------------------------

export function getCachedLikeCount(
  postId
) {
  const id = validatePostId(postId);

  return likeCounts.get(id) ?? null;
}

export function getCachedLikeStatus(
  postId
) {
  const id = validatePostId(postId);

  return likedPosts.has(id);
}

export function getCachedLikedPostIds() {
  return new Set(likedPosts);
}

export function getCachedLikeCounts() {
  return new Map(likeCounts);
}

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

export async function initializeLikes({
  realtime = true,
  user = true
} = {}) {
  if (user) {
    await getCurrentUser();
  }

  if (realtime) {
    subscribeToLikes();
  }

  return {
    user: currentUser
  };
}

// ------------------------------------------------------------
// Destroy
// ------------------------------------------------------------

export async function destroyLikes() {
  await unsubscribeFromLikes();

  clearLikes();

  currentUser = null;

  listeners.clear();
}

// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  EVENTS,

  onLikesChange,

  getCurrentUser,
  getCachedUser,

  hasLikedPost,

  getLikeCount,
  getLikeCounts,

  getMyLikedPosts,

  likePost,
  unlikePost,
  toggleLike,

  loadLikeStatuses,
  loadLikesForPosts,

  subscribeToLikes,
  unsubscribeFromLikes,

  refreshLike,
  refreshLikes,

  clearLikes,

  getCachedLikeCount,
  getCachedLikeStatus,
  getCachedLikedPostIds,
  getCachedLikeCounts,

  initializeLikes,
  destroyLikes
};