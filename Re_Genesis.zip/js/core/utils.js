// ============================================================
// REGENESIS — CORE UTILITIES
// File: js/core/utils.js
// ============================================================


// ============================================================
// STRING UTILITIES
// ============================================================

export function escapeHTML(value) {

  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");

}


export function truncateText(
  text,
  maxLength = 120
) {

  const value =
    String(text ?? "").trim();


  if (
    value.length <= maxLength
  ) {

    return value;

  }


  return (
    value
      .slice(0, Math.max(0, maxLength - 1))
      .trimEnd() +
    "…"
  );

}


export function normalizeText(
  text
) {

  return String(text ?? "")
    .trim()
    .replace(/\s+/g, " ");

}


export function slugify(
  text
) {

  return String(text ?? "")
    .toLowerCase()
    .trim()
    .normalize("NFKD")
    .replace(
      /[\u0300-\u036f]/g,
      ""
    )
    .replace(
      /[^a-z0-9\s-]/g,
      ""
    )
    .replace(
      /\s+/g,
      "-"
    )
    .replace(
      /-+/g,
      "-"
    )
    .replace(
      /^-|-$/g,
      ""
    );

}


// ============================================================
// ID UTILITIES
// ============================================================

export function generateId(
  length = 16
) {

  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";


  let result = "";


  if (
    window.crypto?.getRandomValues
  ) {

    const values =
      new Uint32Array(
        length
      );

    window.crypto.getRandomValues(
      values
    );


    for (
      let i = 0;
      i < length;
      i++
    ) {

      result +=
        characters[
          values[i] %
          characters.length
        ];

    }


    return result;

  }


  for (
    let i = 0;
    i < length;
    i++
  ) {

    result +=
      characters[
        Math.floor(
          Math.random() *
          characters.length
        )
      ];

  }


  return result;

}


export function isValidUUID(
  value
) {

  if (
    typeof value !==
    "string"
  ) {

    return false;

  }


  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    .test(value);

}


// ============================================================
// DATE & TIME
// ============================================================

export function formatDate(
  value,
  options = {}
) {

  const date =
    value instanceof Date
      ? value
      : new Date(value);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {

    return "";

  }


  return new Intl.DateTimeFormat(
    undefined,
    {
      dateStyle: "medium",
      ...options
    }
  ).format(date);

}


export function formatDateTime(
  value,
  options = {}
) {

  const date =
    value instanceof Date
      ? value
      : new Date(value);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {

    return "";

  }


  return new Intl.DateTimeFormat(
    undefined,
    {
      dateStyle: "medium",
      timeStyle: "short",
      ...options
    }
  ).format(date);

}


export function formatTime(
  value,
  options = {}
) {

  const date =
    value instanceof Date
      ? value
      : new Date(value);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {

    return "";

  }


  return new Intl.DateTimeFormat(
    undefined,
    {
      timeStyle: "short",
      ...options
    }
  ).format(date);

}


export function relativeTime(
  value
) {

  const date =
    value instanceof Date
      ? value
      : new Date(value);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {

    return "";

  }


  const now =
    Date.now();


  const difference =
    date.getTime() -
    now;


  const seconds =
    Math.round(
      difference / 1000
    );


  const absoluteSeconds =
    Math.abs(seconds);


  const formatter =
    new Intl.RelativeTimeFormat(
      undefined,
      {
        numeric: "auto"
      }
    );


  if (
    absoluteSeconds < 60
  ) {

    return formatter.format(
      seconds,
      "second"
    );

  }


  const minutes =
    Math.round(
      seconds / 60
    );


  if (
    Math.abs(minutes) < 60
  ) {

    return formatter.format(
      minutes,
      "minute"
    );

  }


  const hours =
    Math.round(
      minutes / 60
    );


  if (
    Math.abs(hours) < 24
  ) {

    return formatter.format(
      hours,
      "hour"
    );

  }


  const days =
    Math.round(
      hours / 24
    );


  if (
    Math.abs(days) < 30
  ) {

    return formatter.format(
      days,
      "day"
    );

  }


  const months =
    Math.round(
      days / 30
    );


  if (
    Math.abs(months) < 12
  ) {

    return formatter.format(
      months,
      "month"
    );

  }


  const years =
    Math.round(
      months / 12
    );


  return formatter.format(
    years,
    "year"
  );

}


export function isPast(
  value
) {

  const date =
    new Date(value);


  return (
    !Number.isNaN(
      date.getTime()
    ) &&
    date.getTime() <
      Date.now()
  );

}


export function isFuture(
  value
) {

  const date =
    new Date(value);


  return (
    !Number.isNaN(
      date.getTime()
    ) &&
    date.getTime() >
      Date.now()
  );

}


// ============================================================
// URL UTILITIES
// ============================================================

export function getQueryParam(
  name,
  url = window.location.href
) {

  try {

    const parsed =
      new URL(url);


    return parsed.searchParams.get(
      name
    );

  } catch {

    return null;

  }

}


export function getAllQueryParams(
  url = window.location.href
) {

  try {

    const parsed =
      new URL(url);


    return Object.fromEntries(
      parsed.searchParams.entries()
    );

  } catch {

    return {};

  }

}


export function setQueryParam(
  name,
  value,
  url = window.location.href
) {

  const parsed =
    new URL(url);


  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {

    parsed.searchParams.delete(
      name
    );

  } else {

    parsed.searchParams.set(
      name,
      value
    );

  }


  return parsed.toString();

}


export function removeQueryParam(
  name,
  url = window.location.href
) {

  return setQueryParam(
    name,
    null,
    url
  );

}


export function isExternalURL(
  url
) {

  try {

    const parsed =
      new URL(
        url,
        window.location.origin
      );


    return (
      parsed.origin !==
      window.location.origin
    );

  } catch {

    return false;

  }

}


export function safeURL(
  url,
  fallback = "#"
) {

  if (
    !url ||
    typeof url !==
      "string"
  ) {

    return fallback;

  }


  const value =
    url.trim();


  if (
    value.startsWith(
      "javascript:"
    ) ||
    value.startsWith(
      "data:"
    ) ||
    value.startsWith(
      "vbscript:"
    )
  ) {

    return fallback;

  }


  return value;

}


// ============================================================
// IMAGE UTILITIES
// ============================================================

export function setImageSource(
  image,
  source,
  fallback = ""
) {

  if (
    !image
  ) {

    return;

  }


  const url =
    safeURL(
      source,
      fallback
    );


  image.src =
    url;


  if (
    fallback &&
    url !== fallback
  ) {

    image.addEventListener(
      "error",
      () => {

        if (
          image.src !== fallback
        ) {

          image.src =
            fallback;

        }

      },
      {
        once: true
      }
    );

  }

}


export function getFileExtension(
  filename
) {

  const value =
    String(filename ?? "")
      .trim();


  const match =
    value.match(
      /\.([^.]+)$/
    );


  return match
    ? match[1].toLowerCase()
    : "";

}


export function formatFileSize(
  bytes
) {

  const size =
    Number(bytes);


  if (
    !Number.isFinite(size) ||
    size < 0
  ) {

    return "0 B";

  }


  if (
    size < 1024
  ) {

    return `${size} B`;

  }


  if (
    size < 1024 * 1024
  ) {

    return `${(
      size / 1024
    ).toFixed(1)} KB`;

  }


  if (
    size < 1024 * 1024 * 1024
  ) {

    return `${(
      size /
      (1024 * 1024)
    ).toFixed(1)} MB`;

  }


  return `${(
    size /
    (1024 * 1024 * 1024)
  ).toFixed(1)} GB`;

}


// ============================================================
// VALIDATION
// ============================================================

export function isValidEmail(
  email
) {

  const value =
    String(email ?? "")
      .trim();


  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    .test(value);

}


export function isValidUsername(
  username
) {

  const value =
    String(username ?? "")
      .trim();


  return /^[a-zA-Z0-9_]{3,30}$/
    .test(value);

}


export function isValidURL(
  value
) {

  try {

    const url =
      new URL(value);


    return (
      url.protocol === "http:" ||
      url.protocol === "https:"
    );

  } catch {

    return false;

  }

}


// ============================================================
// LOCAL STORAGE
// ============================================================

export function storageGet(
  key,
  fallback = null
) {

  try {

    const value =
      localStorage.getItem(
        key
      );


    if (
      value === null
    ) {

      return fallback;

    }


    try {

      return JSON.parse(
        value
      );

    } catch {

      return value;

    }

  } catch {

    return fallback;

  }

}


export function storageSet(
  key,
  value
) {

  try {

    localStorage.setItem(
      key,
      typeof value === "string"
        ? value
        : JSON.stringify(value)
    );

    return true;

  } catch (error) {

    console.error(
      "[REGENESIS Utils] Storage set failed:",
      error
    );

    return false;

  }

}


export function storageRemove(
  key
) {

  try {

    localStorage.removeItem(
      key
    );

    return true;

  } catch {

    return false;

  }

}


// ============================================================
// SESSION STORAGE
// ============================================================

export function sessionGet(
  key,
  fallback = null
) {

  try {

    const value =
      sessionStorage.getItem(
        key
      );


    if (
      value === null
    ) {

      return fallback;

    }


    try {

      return JSON.parse(
        value
      );

    } catch {

      return value;

    }

  } catch {

    return fallback;

  }

}


export function sessionSet(
  key,
  value
) {

  try {

    sessionStorage.setItem(
      key,
      typeof value === "string"
        ? value
        : JSON.stringify(value)
    );

    return true;

  } catch {

    return false;

  }

}


export function sessionRemove(
  key
) {

  try {

    sessionStorage.removeItem(
      key
    );

    return true;

  } catch {

    return false;

  }

}


// ============================================================
// DEBOUNCE
// ============================================================

export function debounce(
  callback,
  delay = 300
) {

  let timeout = null;


  return function (...args) {

    clearTimeout(
      timeout
    );


    timeout =
      setTimeout(
        () => {

          callback.apply(
            this,
            args
          );

        },
        delay
      );

  };

}


// ============================================================
// THROTTLE
// ============================================================

export function throttle(
  callback,
  delay = 300
) {

  let waiting = false;


  return function (...args) {

    if (
      waiting
    ) {

      return;

    }


    callback.apply(
      this,
      args
    );


    waiting = true;


    setTimeout(
      () => {

        waiting = false;

      },
      delay
    );

  };

}


// ============================================================
// DELAY
// ============================================================

export function sleep(
  milliseconds
) {

  return new Promise(
    resolve => {

      setTimeout(
        resolve,
        milliseconds
      );

    }
  );

}


// ============================================================
// CLIPBOARD
// ============================================================

export async function copyToClipboard(
  text
) {

  if (
    !navigator.clipboard
  ) {

    return false;

  }


  try {

    await navigator.clipboard.writeText(
      String(text ?? "")
    );

    return true;

  } catch {

    return false;

  }

}


// ============================================================
// DOM HELPERS
// ============================================================

export function $(selector, parent = document) {

  return parent.querySelector(
    selector
  );

}


export function $$(selector, parent = document) {

  return Array.from(
    parent.querySelectorAll(
      selector
    )
  );

}


export function createElement(
  tag,
  attributes = {},
  text = null
) {

  const element =
    document.createElement(
      tag
    );


  Object.entries(
    attributes
  ).forEach(
    ([key, value]) => {

      if (
        key === "className"
      ) {

        element.className =
          value;

      } else if (
        key === "dataset" &&
        value &&
        typeof value === "object"
      ) {

        Object.entries(
          value
        ).forEach(
          ([dataKey, dataValue]) => {

            element.dataset[
              dataKey
            ] =
              dataValue;

          }
        );

      } else {

        element.setAttribute(
          key,
          value
        );

      }

    }
  );


  if (
    text !== null
  ) {

    element.textContent =
      text;

  }


  return element;

}


// ============================================================
// UI HELPERS
// ============================================================

export function showElement(
  element
) {

  if (
    !element
  ) {

    return;

  }


  element.hidden =
    false;


  element.style.display =
    "";

}


export function hideElement(
  element
) {

  if (
    !element
  ) {

    return;

  }


  element.hidden =
    true;

}


export function toggleElement(
  element,
  visible
) {

  if (
    visible
  ) {

    showElement(
      element
    );

  } else {

    hideElement(
      element
    );

  }

}


// ============================================================
// BUTTON LOADING STATE
// ============================================================

export function setButtonLoading(
  button,
  loading,
  loadingText = "Loading..."
) {

  if (
    !button
  ) {

    return;

  }


  if (
    loading
  ) {

    if (
      button.dataset.originalText ===
      undefined
    ) {

      button.dataset.originalText =
        button.textContent;

    }


    button.disabled =
      true;

    button.textContent =
      loadingText;

  } else {

    button.disabled =
      false;


    if (
      button.dataset.originalText !==
      undefined
    ) {

      button.textContent =
        button.dataset.originalText;

      delete button.dataset.originalText;

    }

  }

}


// ============================================================
// SCROLL
// ============================================================

export function scrollToElement(
  element,
  behavior = "smooth"
) {

  if (
    !element
  ) {

    return;

  }


  element.scrollIntoView({
    behavior,
    block: "start"
  });

}


export function scrollToTop(
  behavior = "smooth"
) {

  window.scrollTo({
    top: 0,
    behavior
  });

}


// ============================================================
// RANDOM ARRAY ITEM
// ============================================================

export function randomItem(
  array
) {

  if (
    !Array.isArray(array) ||
    array.length === 0
  ) {

    return null;

  }


  return array[
    Math.floor(
      Math.random() *
      array.length
    )
  ];

}


// ============================================================
// ARRAY UTILITIES
// ============================================================

export function uniqueArray(
  array
) {

  if (
    !Array.isArray(array)
  ) {

    return [];

  }


  return [
    ...new Set(array)
  ];

}


export function uniqueBy(
  array,
  key
) {

  if (
    !Array.isArray(array)
  ) {

    return [];

  }


  const seen =
    new Set();


  return array.filter(
    item => {

      const value =
        typeof key ===
        "function"
          ? key(item)
          : item?.[key];


      if (
        seen.has(value)
      ) {

        return false;

      }


      seen.add(value);

      return true;

    }
  );

}


// ============================================================
// NUMBER UTILITIES
// ============================================================

export function clamp(
  value,
  min,
  max
) {

  const number =
    Number(value);


  if (
    Number.isNaN(number)
  ) {

    return min;

  }


  return Math.min(
    Math.max(
      number,
      min
    ),
    max
  );

}


export function formatNumber(
  value
) {

  const number =
    Number(value);


  if (
    !Number.isFinite(number)
  ) {

    return "0";

  }


  return new Intl.NumberFormat()
    .format(number);

}


// ============================================================
// ERROR HANDLING
// ============================================================

export function getErrorMessage(
  error,
  fallback = "Something went wrong."
) {

  if (!error) {

    return fallback;

  }


  if (
    typeof error ===
    "string"
  ) {

    return error;

  }


  if (
    error.message
  ) {

    return error.message;

  }


  return fallback;

}


// ============================================================
// NETWORK STATUS
// ============================================================

export function isOnline() {

  return navigator.onLine;

}


export function onNetworkChange(
  callback
) {

  if (
    typeof callback !==
    "function"
  ) {

    throw new Error(
      "A callback function is required."
    );

  }


  const online =
    () => callback(true);


  const offline =
    () => callback(false);


  window.addEventListener(
    "online",
    online
  );


  window.addEventListener(
    "offline",
    offline
  );


  return () => {

    window.removeEventListener(
      "online",
      online
    );


    window.removeEventListener(
      "offline",
      offline
    );

  };

}


// ============================================================
// EXPORT DEFAULT
// ============================================================

export default {

  escapeHTML,

  truncateText,

  normalizeText,

  slugify,

  generateId,

  isValidUUID,

  formatDate,

  formatDateTime,

  formatTime,

  relativeTime,

  isPast,

  isFuture,

  getQueryParam,

  getAllQueryParams,

  setQueryParam,

  removeQueryParam,

  isExternalURL,

  safeURL,

  setImageSource,

  getFileExtension,

  formatFileSize,

  isValidEmail,

  isValidUsername,

  isValidURL,

  storageGet,

  storageSet,

  storageRemove,

  sessionGet,

  sessionSet,

  sessionRemove,

  debounce,

  throttle,

  sleep,

  copyToClipboard,

  $,

  $$,

  createElement,

  showElement,

  hideElement,

  toggleElement,

  setButtonLoading,

  scrollToElement,

  scrollToTop,

  randomItem,

  uniqueArray,

  uniqueBy,

  clamp,

  formatNumber,

  getErrorMessage,

  isOnline,

  onNetworkChange

};