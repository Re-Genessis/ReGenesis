// ============================================================
// REGENESIS — REALTIME ENGINE
// File: js/core/realtime.js
// ============================================================

import { supabase } from "../supabase.js";


// ============================================================
// CONFIG
// ============================================================

const DEFAULT_SCHEMA = "public";


// ============================================================
// INTERNAL STATE
// ============================================================

const channels = new Map();


// ============================================================
// CREATE UNIQUE CHANNEL NAME
// ============================================================

function createChannelName(prefix = "regenesis") {

  return `${prefix}-${Date.now()}-${Math.random()
    .toString(36)
    .slice(2, 9)}`;

}


// ============================================================
// REMOVE CHANNEL
// ============================================================

export async function removeRealtimeChannel(channel) {

  if (!channel) {
    return;
  }

  try {

    await supabase.removeChannel(channel);

  } catch (error) {

    console.error(
      "[REGENESIS Realtime] Failed to remove channel:",
      error
    );

  }

}


// ============================================================
// REMOVE CHANNEL BY NAME
// ============================================================

export async function removeRealtimeChannelByName(
  channelName
) {

  const channel = channels.get(
    channelName
  );

  if (!channel) {
    return;
  }

  await removeRealtimeChannel(
    channel
  );

  channels.delete(
    channelName
  );

}


// ============================================================
// REMOVE ALL CHANNELS
// ============================================================

export async function removeAllRealtimeChannels() {

  for (
    const [name, channel]
    of channels.entries()
  ) {

    await removeRealtimeChannel(
      channel
    );

    channels.delete(
      name
    );

  }

}


// ============================================================
// GENERIC POSTGRES REALTIME SUBSCRIPTION
// ============================================================

export function subscribeToTable({

  table,

  event = "*",

  schema = DEFAULT_SCHEMA,

  filter = null,

  callback,

  channelName = null

} = {}) {

  if (!table) {

    throw new Error(
      "subscribeToTable requires a table name."
    );

  }


  if (
    typeof callback !== "function"
  ) {

    throw new Error(
      "subscribeToTable requires a callback function."
    );

  }


  const name =
    channelName ||
    createChannelName(
      `table-${table}`
    );


  let channel =
    supabase.channel(
      name
    );


  const config = {

    event,

    schema,

    table

  };


  if (filter) {

    config.filter =
      filter;

  }


  channel =
    channel.on(
      "postgres_changes",
      config,
      payload => {

        try {

          callback(
            payload
          );

        } catch (error) {

          console.error(
            "[REGENESIS Realtime] Callback error:",
            error
          );

        }

      }
    );


  channel.subscribe(
    status => {

      if (
        status === "SUBSCRIBED"
      ) {

        console.log(
          `[REGENESIS Realtime] Subscribed: ${name}`
        );

      }

      if (
        status === "CHANNEL_ERROR"
      ) {

        console.error(
          `[REGENESIS Realtime] Channel error: ${name}`
        );

      }

      if (
        status === "TIMED_OUT"
      ) {

        console.error(
          `[REGENESIS Realtime] Channel timed out: ${name}`
        );

      }

      if (
        status === "CLOSED"
      ) {

        console.log(
          `[REGENESIS Realtime] Channel closed: ${name}`
        );

      }

    }
  );


  channels.set(
    name,
    channel
  );


  return channel;

}


// ============================================================
// SUBSCRIBE TO MULTIPLE TABLES
// ============================================================

export function subscribeToTables({

  subscriptions = [],

  channelName = null,

  onStatus = null

} = {}) {

  if (
    !Array.isArray(
      subscriptions
    )
  ) {

    throw new Error(
      "subscriptions must be an array."
    );

  }


  const name =
    channelName ||
    createChannelName(
      "multi-table"
    );


  let channel =
    supabase.channel(
      name
    );


  subscriptions.forEach(
    subscription => {

      const {

        table,

        event = "*",

        schema = DEFAULT_SCHEMA,

        filter = null,

        callback

      } = subscription;


      if (!table) {
        return;
      }


      const config = {

        event,

        schema,

        table

      };


      if (filter) {

        config.filter =
          filter;

      }


      channel =
        channel.on(
          "postgres_changes",
          config,
          payload => {

            if (
              typeof callback ===
              "function"
            ) {

              callback(
                payload
              );

            }

          }
        );

    }
  );


  channel.subscribe(
    status => {

      if (
        typeof onStatus ===
        "function"
      ) {

        onStatus(
          status
        );

      }

    }
  );


  channels.set(
    name,
    channel
  );


  return channel;

}


// ============================================================
// GAME COMMUNITY REALTIME
// ============================================================

export function subscribeToGameCommunity({

  gameId,

  onPost = null,

  onMember = null,

  onUpdate = null

} = {}) {

  if (!gameId) {

    throw new Error(
      "gameId is required."
    );

  }


  const channelName =
    `game-community-${gameId}`;


  let channel =
    supabase.channel(
      channelName
    );


  // Game posts

  if (
    typeof onPost ===
    "function"
  ) {

    channel =
      channel.on(
        "postgres_changes",
        {
          event: "*",
          schema: DEFAULT_SCHEMA,
          table: "game_posts",
          filter: `game_id=eq.${gameId}`
        },
        payload => {

          onPost(
            payload
          );

        }
      );

  }


  // Game members

  if (
    typeof onMember ===
    "function"
  ) {

    channel =
      channel.on(
        "postgres_changes",
        {
          event: "*",
          schema: DEFAULT_SCHEMA,
          table: "game_members",
          filter: `game_id=eq.${gameId}`
        },
        payload => {

          onMember(
            payload
          );

        }
      );

  }


  // Game community itself

  if (
    typeof onUpdate ===
    "function"
  ) {

    channel =
      channel.on(
        "postgres_changes",
        {
          event: "*",
          schema: DEFAULT_SCHEMA,
          table: "game_communities",
          filter: `id=eq.${gameId}`
        },
        payload => {

          onUpdate(
            payload
          );

        }
      );

  }


  channel.subscribe();

  channels.set(
    channelName,
    channel
  );


  return channel;

}


// ============================================================
// DISCUSSION REALTIME
// ============================================================

export function subscribeToDiscussion({

  table = "posts",

  postId = null,

  onChange = null

} = {}) {

  const filter =
    postId
      ? `id=eq.${postId}`
      : null;


  return subscribeToTable({

    table,

    event: "*",

    filter,

    callback:
      onChange,

    channelName:
      createChannelName(
        `discussion-${table}`
      )

  });

}


// ============================================================
// COMMENTS REALTIME
// ============================================================

export function subscribeToComments({

  postId,

  onChange

} = {}) {

  if (!postId) {

    throw new Error(
      "postId is required."
    );

  }


  return subscribeToTable({

    table: "comments",

    event: "*",

    filter:
      `post_id=eq.${postId}`,

    callback:
      onChange,

    channelName:
      createChannelName(
        `comments-${postId}`
      )

  });

}


// ============================================================
// LIKES REALTIME
// ============================================================

export function subscribeToLikes({

  postId,

  onChange

} = {}) {

  if (!postId) {

    throw new Error(
      "postId is required."
    );

  }


  return subscribeToTable({

    table: "likes",

    event: "*",

    filter:
      `post_id=eq.${postId}`,

    callback:
      onChange,

    channelName:
      createChannelName(
        `likes-${postId}`
      )

  });

}


// ============================================================
// NOTIFICATIONS REALTIME
// ============================================================

export function subscribeToNotifications({

  userId,

  onChange

} = {}) {

  if (!userId) {

    throw new Error(
      "userId is required."
    );

  }


  return subscribeToTable({

    table: "notifications",

    event: "*",

    filter:
      `user_id=eq.${userId}`,

    callback:
      onChange,

    channelName:
      `notifications-${userId}`

  });

}


// ============================================================
// MESSAGES / INBOX REALTIME
// ============================================================

export function subscribeToMessages({

  userId,

  onMessage

} = {}) {

  if (!userId) {

    throw new Error(
      "userId is required."
    );

  }


  return subscribeToTable({

    table: "messages",

    event: "*",

    filter:
      `receiver_id=eq.${userId}`,

    callback:
      onMessage,

    channelName:
      `messages-${userId}`

  });

}


// ============================================================
// CONVERSATION REALTIME
// ============================================================

export function subscribeToConversation({

  conversationId,

  onMessage

} = {}) {

  if (!conversationId) {

    throw new Error(
      "conversationId is required."
    );

  }


  return subscribeToTable({

    table: "messages",

    event: "*",

    filter:
      `conversation_id=eq.${conversationId}`,

    callback:
      onMessage,

    channelName:
      `conversation-${conversationId}`

  });

}


// ============================================================
// EVENTS REALTIME
// ============================================================

export function subscribeToEvents({

  onEvent = null,

  onAttendee = null

} = {}) {

  return subscribeToTables({

    channelName:
      "regenesis-events",

    subscriptions: [

      {

        table: "events",

        event: "*",

        callback:
          onEvent

      },

      {

        table: "event_attendees",

        event: "*",

        callback:
          onAttendee

      }

    ]

  });

}


// ============================================================
// SINGLE EVENT REALTIME
// ============================================================

export function subscribeToEvent({

  eventId,

  onEvent = null,

  onAttendee = null

} = {}) {

  if (!eventId) {

    throw new Error(
      "eventId is required."
    );

  }


  return subscribeToTables({

    channelName:
      `event-${eventId}`,

    subscriptions: [

      {

        table: "events",

        event: "*",

        filter:
          `id=eq.${eventId}`,

        callback:
          onEvent

      },

      {

        table: "event_attendees",

        event: "*",

        filter:
          `event_id=eq.${eventId}`,

        callback:
          onAttendee

      }

    ]

  });

}


// ============================================================
// GALLERY REALTIME
// ============================================================

export function subscribeToGallery({

  onChange

} = {}) {

  return subscribeToTable({

    table:
      "gallery_items",

    event:
      "*",

    callback:
      onChange,

    channelName:
      "regenesis-gallery"

  });

}


// ============================================================
// PROFILE REALTIME
// ============================================================

export function subscribeToProfile({

  userId,

  onChange

} = {}) {

  if (!userId) {

    throw new Error(
      "userId is required."
    );

  }


  return subscribeToTable({

    table:
      "profiles",

    event:
      "*",

    filter:
      `id=eq.${userId}`,

    callback:
      onChange,

    channelName:
      `profile-${userId}`

  });

}


// ============================================================
// ANIME DISCUSSIONS
// ============================================================

export function subscribeToAnimeDiscussions({

  animeId,

  onChange

} = {}) {

  if (!animeId) {

    throw new Error(
      "animeId is required."
    );

  }


  return subscribeToTable({

    table:
      "anime_discussions",

    event:
      "*",

    filter:
      `anime_id=eq.${animeId}`,

    callback:
      onChange,

    channelName:
      `anime-discussions-${animeId}`

  });

}


// ============================================================
// MANGA DISCUSSIONS
// ============================================================

export function subscribeToMangaDiscussions({

  mangaId,

  onChange

} = {}) {

  if (!mangaId) {

    throw new Error(
      "mangaId is required."
    );

  }


  return subscribeToTable({

    table:
      "manga_discussions",

    event:
      "*",

    filter:
      `manga_id=eq.${mangaId}`,

    callback:
      onChange,

    channelName:
      `manga-discussions-${mangaId}`

  });

}


// ============================================================
// COSPLAY REALTIME
// ============================================================

export function subscribeToCosplay({

  onProfile = null,

  onVote = null,

  onCompetition = null

} = {}) {

  return subscribeToTables({

    channelName:
      "regenesis-cosplay",

    subscriptions: [

      {

        table:
          "cosplay_profiles",

        event:
          "*",

        callback:
          onProfile

      },

      {

        table:
          "cosplay_votes",

        event:
          "*",

        callback:
          onVote

      },

      {

        table:
          "cosplay_competitions",

        event:
          "*",

        callback:
          onCompetition

      }

    ]

  });

}


// ============================================================
// AUTH STATE REALTIME
// ============================================================

export function subscribeToAuth(

  callback

) {

  if (
    typeof callback !==
    "function"
  ) {

    throw new Error(
      "Auth callback is required."
    );

  }


  return supabase.auth.onAuthStateChange(
    (
      event,
      session
    ) => {

      callback(
        event,
        session
      );

    }
  );

}


// ============================================================
// CONNECTION STATUS
// ============================================================

export function getRealtimeChannels() {

  return Array.from(
    channels.values()
  );

}


export function getRealtimeChannelCount() {

  return channels.size;

}


// ============================================================
// CLEANUP WHEN PAGE IS CLOSED
// ============================================================

window.addEventListener(
  "beforeunload",
  () => {

    for (
      const channel
      of channels.values()
    ) {

      try {

        supabase.removeChannel(
          channel
        );

      } catch (_) {}

    }

    channels.clear();

  }
);


// ============================================================
// DEFAULT EXPORT
// ============================================================

export default {

  subscribeToTable,

  subscribeToTables,

  subscribeToGameCommunity,

  subscribeToDiscussion,

  subscribeToComments,

  subscribeToLikes,

  subscribeToNotifications,

  subscribeToMessages,

  subscribeToConversation,

  subscribeToEvents,

  subscribeToEvent,

  subscribeToGallery,

  subscribeToProfile,

  subscribeToAnimeDiscussions,

  subscribeToMangaDiscussions,

  subscribeToCosplay,

  subscribeToAuth,

  removeRealtimeChannel,

  removeRealtimeChannelByName,

  removeAllRealtimeChannels,

  getRealtimeChannels,

  getRealtimeChannelCount

};