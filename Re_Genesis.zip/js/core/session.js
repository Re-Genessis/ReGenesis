// ============================================================
// REGENESIS — SESSION MANAGER
// File: js/core/session.js
// ============================================================

import {
  supabase,
  getSession,
  getUser,
  onAuthChange
} from "../supabase.js";


// ============================================================
// SESSION STATE
// ============================================================

let currentSession = null;
let currentUser = null;

let initialized = false;

const listeners = new Set();


// ============================================================
// SESSION EVENTS
// ============================================================

export const SESSION_EVENTS = {

  INITIALIZED:
    "session:initialized",

  SIGNED_IN:
    "session:signed-in",

  SIGNED_OUT:
    "session:signed-out",

  UPDATED:
    "session:updated",

  USER_UPDATED:
    "session:user-updated"

};


// ============================================================
// INTERNAL EVENT DISPATCHER
// ============================================================

function notifyListeners(
  event,
  session,
  user
) {

  listeners.forEach(
    listener => {

      try {

        listener({
          event,
          session,
          user
        });

      } catch (error) {

        console.error(
          "[REGENESIS Session] Listener error:",
          error
        );

      }

    }
  );

}


// ============================================================
// SUBSCRIBE TO SESSION CHANGES
// ============================================================

export function onSessionChange(
  callback
) {

  if (
    typeof callback !==
    "function"
  ) {

    throw new Error(
      "onSessionChange requires a callback."
    );

  }


  listeners.add(
    callback
  );


  return () => {

    listeners.delete(
      callback
    );

  };

}


// ============================================================
// GET CURRENT SESSION
// ============================================================

export function getCurrentSession() {

  return currentSession;

}


// ============================================================
// GET CURRENT USER
// ============================================================

export function getCurrentUser() {

  return currentUser;

}


// ============================================================
// CHECK AUTHENTICATION
// ============================================================

export function isSignedIn() {

  return !!(
    currentSession &&
    currentUser
  );

}


// ============================================================
// INITIALIZE SESSION
// ============================================================

export async function initSession() {

  if (
    initialized
  ) {

    return {
      session:
        currentSession,

      user:
        currentUser
    };

  }


  try {

    const {
      data,
      error
    } =
      await supabase.auth.getSession();


    if (error) {
      throw error;
    }


    currentSession =
      data?.session ||
      null;


    currentUser =
      currentSession?.user ||
      null;


    initialized =
      true;


    notifyListeners(
      SESSION_EVENTS.INITIALIZED,
      currentSession,
      currentUser
    );


    return {

      session:
        currentSession,

      user:
        currentUser

    };


  } catch (error) {

    console.error(
      "[REGENESIS Session] Initialization failed:",
      error
    );


    currentSession =
      null;

    currentUser =
      null;

    initialized =
      true;


    notifyListeners(
      SESSION_EVENTS.INITIALIZED,
      null,
      null
    );


    return {

      session: null,

      user: null,

      error

    };

  }

}


// ============================================================
// LISTEN TO SUPABASE AUTH CHANGES
// ============================================================

const authSubscription =
  onAuthChange(
    async (
      event,
      session
    ) => {

      const previousUser =
        currentUser;


      currentSession =
        session ||
        null;


      currentUser =
        session?.user ||
        null;


      initialized =
        true;


      let sessionEvent =
        SESSION_EVENTS.UPDATED;


      if (
        event ===
        "SIGNED_IN"
      ) {

        sessionEvent =
          SESSION_EVENTS.SIGNED_IN;

      }


      if (
        event ===
        "SIGNED_OUT"
      ) {

        sessionEvent =
          SESSION_EVENTS.SIGNED_OUT;

      }


      if (
        event ===
        "USER_UPDATED"
      ) {

        sessionEvent =
          SESSION_EVENTS.USER_UPDATED;

      }


      notifyListeners(
        sessionEvent,
        currentSession,
        currentUser
      );


      // Keep the profile/user reference fresh.

      if (
        event ===
        "USER_UPDATED" &&
        previousUser?.id ===
        currentUser?.id
      ) {

        notifyListeners(
          SESSION_EVENTS.UPDATED,
          currentSession,
          currentUser
        );

      }

    }
  );


// ============================================================
// REFRESH SESSION
// ============================================================

export async function refreshSession() {

  try {

    const {
      data,
      error
    } =
      await supabase.auth.refreshSession();


    if (error) {
      throw error;
    }


    currentSession =
      data?.session ||
      null;


    currentUser =
      data?.user ||
      currentSession?.user ||
      null;


    initialized =
      true;


    notifyListeners(
      SESSION_EVENTS.UPDATED,
      currentSession,
      currentUser
    );


    return {

      session:
        currentSession,

      user:
        currentUser

    };


  } catch (error) {

    console.error(
      "[REGENESIS Session] Refresh failed:",
      error
    );


    return {

      session:
        currentSession,

      user:
        currentUser,

      error

    };

  }

}


// ============================================================
// VERIFY SESSION
// ============================================================

export async function verifySession() {

  try {

    const session =
      await getSession();


    if (!session) {

      currentSession =
        null;

      currentUser =
        null;

      return false;

    }


    currentSession =
      session;


    currentUser =
      session.user ||
      null;


    return !!currentUser;

  } catch (error) {

    console.error(
      "[REGENESIS Session] Verification failed:",
      error
    );

    return false;

  }

}


// ============================================================
// GET FRESH USER
// ============================================================

export async function refreshUser() {

  try {

    const {
      data,
      error
    } =
      await supabase.auth.getUser();


    if (error) {
      throw error;
    }


    currentUser =
      data?.user ||
      null;


    if (
      currentSession
    ) {

      currentSession = {

        ...currentSession,

        user:
          currentUser

      };

    }


    notifyListeners(
      SESSION_EVENTS.USER_UPDATED,
      currentSession,
      currentUser
    );


    return currentUser;

  } catch (error) {

    console.error(
      "[REGENESIS Session] User refresh failed:",
      error
    );


    return null;

  }

}


// ============================================================
// REQUIRE SESSION
// ============================================================

export async function requireSession({

  redirect = "../auth/login.html",

  returnTo = true

} = {}) {

  const result =
    await initSession();


  if (
    result.user
  ) {

    return {

      authenticated: true,

      session:
        result.session,

      user:
        result.user

    };

  }


  if (
    typeof window !==
    "undefined"
  ) {

    let target =
      redirect;


    if (
      returnTo
    ) {

      const currentURL =
        window.location.href;


      target +=
        `?redirect=${encodeURIComponent(
          currentURL
        )}`;

    }


    window.location.replace(
      target
    );

  }


  return {

    authenticated: false,

    session: null,

    user: null

  };

}


// ============================================================
// REDIRECT AUTHENTICATED USERS
// ============================================================

export async function redirectIfAuthenticated({

  redirect = "../index.html"

} = {}) {

  const result =
    await initSession();


  if (
    result.user
  ) {

    if (
      typeof window !==
      "undefined"
    ) {

      window.location.replace(
        redirect
      );

    }


    return true;

  }


  return false;

}


// ============================================================
// SIGN OUT
// ============================================================

export async function signOut() {

  try {

    const {
      error
    } =
      await supabase.auth.signOut();


    if (error) {
      throw error;
    }


    currentSession =
      null;

    currentUser =
      null;


    notifyListeners(
      SESSION_EVENTS.SIGNED_OUT,
      null,
      null
    );


    return {

      success: true

    };

  } catch (error) {

    console.error(
      "[REGENESIS Session] Sign out failed:",
      error
    );


    return {

      success: false,

      error

    };

  }

}


// ============================================================
// GET ACCESS TOKEN
// ============================================================

export function getAccessToken() {

  return (
    currentSession?.access_token ||
    null
  );

}


// ============================================================
// GET REFRESH TOKEN
// ============================================================

export function getRefreshToken() {

  return (
    currentSession?.refresh_token ||
    null
  );

}


// ============================================================
// GET USER ID
// ============================================================

export function getUserId() {

  return (
    currentUser?.id ||
    null
  );

}


// ============================================================
// GET USER EMAIL
// ============================================================

export function getUserEmail() {

  return (
    currentUser?.email ||
    null
  );

}


// ============================================================
// GET AUTH PROVIDER
// ============================================================

export function getAuthProvider() {

  return (
    currentUser
      ?.app_metadata
      ?.provider ||
    null
  );

}


// ============================================================
// GET SESSION EXPIRATION
// ============================================================

export function getSessionExpiresAt() {

  if (
    !currentSession
  ) {

    return null;

  }


  return (
    currentSession.expires_at ||
    null
  );

}


// ============================================================
// CHECK WHETHER SESSION IS EXPIRING
// ============================================================

export function isSessionExpiring(

  seconds = 60

) {

  const expiresAt =
    getSessionExpiresAt();


  if (
    !expiresAt
  ) {

    return false;

  }


  const now =
    Math.floor(
      Date.now() / 1000
    );


  return (
    expiresAt - now <=
    seconds
  );

}


// ============================================================
// SESSION SNAPSHOT
// ============================================================

export function getSessionSnapshot() {

  return {

    initialized,

    authenticated:
      isSignedIn(),

    session:
      currentSession,

    user:
      currentUser,

    userId:
      getUserId(),

    email:
      getUserEmail(),

    provider:
      getAuthProvider(),

    accessToken:
      getAccessToken(),

    expiresAt:
      getSessionExpiresAt()

  };

}


// ============================================================
// INITIALIZE AUTOMATICALLY
// ============================================================

initSession().catch(
  error => {

    console.error(
      "[REGENESIS Session] Auto initialization failed:",
      error
    );

  }
);


// ============================================================
// PAGE VISIBILITY
// Refresh when the user returns to the page.
// ============================================================

document.addEventListener(
  "visibilitychange",
  async () => {

    if (
      document.visibilityState !==
      "visible"
    ) {

      return;

    }


    if (
      !currentSession
    ) {

      return;

    }


    if (
      isSessionExpiring(120)
    ) {

      await refreshSession();

    }

  }
);


// ============================================================
// DEFAULT EXPORT
// ============================================================

export default {

  initSession,

  getCurrentSession,

  getCurrentUser,

  isSignedIn,

  onSessionChange,

  refreshSession,

  refreshUser,

  verifySession,

  requireSession,

  redirectIfAuthenticated,

  signOut,

  getAccessToken,

  getRefreshToken,

  getUserId,

  getUserEmail,

  getAuthProvider,

  getSessionExpiresAt,

  isSessionExpiring,

  getSessionSnapshot,

  SESSION_EVENTS

};