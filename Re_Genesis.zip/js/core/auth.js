/* =========================================================
   REGENESIS
   Core Authentication
   File: js/core/auth.js

   Uses:
   ../supabase.js

   This file handles:
   - Current user/session
   - Login state
   - Logout
   - Auth state changes
   - Protected pages
   - Redirects
   - User profile loading
   - Auth UI updates
   ========================================================= */

import {
    supabase,
    getUser,
    getSession,
    signOut
} from "../supabase.js";


/* =========================================================
   CONFIGURATION
   ========================================================= */

const HOME_PAGE = "../index.html";
const LOGIN_PAGE = "../auth/login.html";
const PROFILE_PAGE = "../pages/profile.html";


/* =========================================================
   CURRENT USER
   ========================================================= */

let currentUser = null;
let currentSession = null;
let currentProfile = null;


/* =========================================================
   GET CURRENT USER
   ========================================================= */

export async function getCurrentUser() {

    try {

        const user = await getUser();

        currentUser = user;

        return user;

    } catch (error) {

        console.error(
            "REGENESIS: Could not get current user.",
            error
        );

        currentUser = null;

        return null;
    }
}


/* =========================================================
   GET CURRENT SESSION
   ========================================================= */

export async function getCurrentSession() {

    try {

        const session = await getSession();

        currentSession = session;

        return session;

    } catch (error) {

        console.error(
            "REGENESIS: Could not get current session.",
            error
        );

        currentSession = null;

        return null;
    }
}


/* =========================================================
   GET CACHED USER
   ========================================================= */

export function getCachedUser() {

    return currentUser;
}


/* =========================================================
   GET CACHED SESSION
   ========================================================= */

export function getCachedSession() {

    return currentSession;
}


/* =========================================================
   LOAD USER PROFILE
   ========================================================= */

export async function getUserProfile(userId = null) {

    try {

        const user = currentUser || await getCurrentUser();

        const id = userId || user?.id;

        if (!id) {
            return null;
        }

        const {
            data,
            error
        } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", id)
            .maybeSingle();

        if (error) {

            console.error(
                "REGENESIS: Profile loading error.",
                error
            );

            return null;
        }

        currentProfile = data;

        return data;

    } catch (error) {

        console.error(
            "REGENESIS: Unexpected profile error.",
            error
        );

        return null;
    }
}


/* =========================================================
   GET CACHED PROFILE
   ========================================================= */

export function getCachedProfile() {

    return currentProfile;
}


/* =========================================================
   CHECK AUTHENTICATION
   ========================================================= */

export async function isAuthenticated() {

    const session = await getCurrentSession();

    return !!session?.user;
}


/* =========================================================
   REQUIRE LOGIN
   Use this on pages that require authentication.
   ========================================================= */

export async function requireAuth() {

    const session = await getCurrentSession();

    if (!session?.user) {

        const currentUrl =
            window.location.pathname +
            window.location.search +
            window.location.hash;

        const redirect =
            encodeURIComponent(currentUrl);

        window.location.replace(
            `${LOGIN_PAGE}?redirect=${redirect}`
        );

        return null;
    }

    currentUser = session.user;

    return session.user;
}


/* =========================================================
   REDIRECT IF ALREADY LOGGED IN
   Useful for:
   - login.html
   - register.html
   - forgot.html
   ========================================================= */

export async function redirectIfAuthenticated(
    destination = HOME_PAGE
) {

    const session = await getCurrentSession();

    if (session?.user) {

        window.location.replace(destination);

        return true;
    }

    return false;
}


/* =========================================================
   LOGOUT
   ========================================================= */

export async function logout(
    destination = LOGIN_PAGE
) {

    try {

        await signOut();

        currentUser = null;
        currentSession = null;
        currentProfile = null;

        window.location.replace(destination);

    } catch (error) {

        console.error(
            "REGENESIS: Logout failed.",
            error
        );

        throw error;
    }
}


/* =========================================================
   AUTH STATE LISTENER
   ========================================================= */

export function onAuthStateChange(callback) {

    return supabase.auth.onAuthStateChange(
        async (event, session) => {

            currentSession = session;
            currentUser = session?.user || null;

            if (currentUser) {

                try {

                    currentProfile =
                        await getUserProfile(
                            currentUser.id
                        );

                } catch (error) {

                    console.error(
                        "REGENESIS: Could not refresh profile.",
                        error
                    );
                }

            } else {

                currentProfile = null;
            }

            if (typeof callback === "function") {

                callback(
                    event,
                    session,
                    currentUser,
                    currentProfile
                );
            }
        }
    );
}


/* =========================================================
   AUTH EVENTS
   ========================================================= */

export const AUTH_EVENTS = {

    SIGNED_IN: "SIGNED_IN",
    SIGNED_OUT: "SIGNED_OUT",
    PASSWORD_RECOVERY: "PASSWORD_RECOVERY",
    TOKEN_REFRESHED: "TOKEN_REFRESHED",
    USER_UPDATED: "USER_UPDATED",
    INITIAL_SESSION: "INITIAL_SESSION"
};


/* =========================================================
   GET USER DISPLAY NAME
   ========================================================= */

export function getDisplayName(
    user = currentUser,
    profile = currentProfile
) {

    if (profile?.display_name) {
        return profile.display_name;
    }

    if (profile?.username) {
        return profile.username;
    }

    if (user?.user_metadata?.full_name) {
        return user.user_metadata.full_name;
    }

    if (user?.user_metadata?.name) {
        return user.user_metadata.name;
    }

    if (user?.email) {
        return user.email.split("@")[0];
    }

    return "REGENESIS User";
}


/* =========================================================
   GET USER AVATAR
   ========================================================= */

export function getAvatarUrl(
    user = currentUser,
    profile = currentProfile
) {

    if (profile?.avatar_url) {
        return profile.avatar_url;
    }

    if (user?.user_metadata?.avatar_url) {
        return user.user_metadata.avatar_url;
    }

    if (user?.user_metadata?.picture) {
        return user.user_metadata.picture;
    }

    return "";
}


/* =========================================================
   UPDATE AUTH UI
   Automatically updates elements using these IDs:
   
   authUserName
   authUserAvatar
   loginButton
   registerButton
   logoutButton
   ========================================================= */

export async function updateAuthUI() {

    const user = currentUser || await getCurrentUser();

    const profile =
        currentProfile ||
        (user ? await getUserProfile(user.id) : null);


    const name =
        getDisplayName(user, profile);

    const avatar =
        getAvatarUrl(user, profile);


    const userNameElement =
        document.getElementById("authUserName");

    const avatarElement =
        document.getElementById("authUserAvatar");

    const loginButton =
        document.getElementById("loginButton");

    const registerButton =
        document.getElementById("registerButton");

    const logoutButton =
        document.getElementById("logoutButton");


    if (userNameElement) {

        userNameElement.textContent =
            user ? name : "Guest";
    }


    if (avatarElement) {

        if (avatar) {

            avatarElement.src = avatar;
            avatarElement.alt = name;

        } else {

            avatarElement.removeAttribute("src");
            avatarElement.alt = name;
        }
    }


    if (loginButton) {

        loginButton.style.display =
            user ? "none" : "";
    }


    if (registerButton) {

        registerButton.style.display =
            user ? "none" : "";
    }


    if (logoutButton) {

        logoutButton.style.display =
            user ? "" : "none";
    }
}


/* =========================================================
   SETUP LOGOUT BUTTONS
   Any element with:
   
   data-action="logout"
   
   will become a real logout button.
   ========================================================= */

export function setupLogoutButtons() {

    const buttons =
        document.querySelectorAll(
            '[data-action="logout"]'
        );

    buttons.forEach(button => {

        button.addEventListener(
            "click",
            async event => {

                event.preventDefault();

                button.disabled = true;

                try {

                    await logout();

                } catch (error) {

                    button.disabled = false;

                    console.error(
                        "REGENESIS: Logout failed.",
                        error
                    );
                }
            }
        );
    });
}


/* =========================================================
   INITIALIZE AUTH
   ========================================================= */

export async function initAuth() {

    try {

        const session =
            await getCurrentSession();

        currentSession = session;
        currentUser = session?.user || null;


        if (currentUser) {

            currentProfile =
                await getUserProfile(
                    currentUser.id
                );
        }


        await updateAuthUI();

        setupLogoutButtons();


        return {
            user: currentUser,
            session: currentSession,
            profile: currentProfile
        };

    } catch (error) {

        console.error(
            "REGENESIS: Auth initialization failed.",
            error
        );

        return {
            user: null,
            session: null,
            profile: null
        };
    }
}


/* =========================================================
   AUTO INITIALIZATION
   ========================================================= */

if (document.readyState === "loading") {

    document.addEventListener(
        "DOMContentLoaded",
        () => {
            initAuth();
        }
    );

} else {

    initAuth();
}


/* =========================================================
   GLOBAL AUTH STATE LISTENER
   ========================================================= */

onAuthStateChange(
    async () => {

        await updateAuthUI();
    }
);


/* =========================================================
   DEFAULT EXPORT
   ========================================================= */

export default {

    getCurrentUser,
    getCurrentSession,
    getCachedUser,
    getCachedSession,

    getUserProfile,
    getCachedProfile,

    isAuthenticated,
    requireAuth,
    redirectIfAuthenticated,

    logout,
    onAuthStateChange,

    getDisplayName,
    getAvatarUrl,

    updateAuthUI,
    setupLogoutButtons,

    initAuth,

    AUTH_EVENTS
};