/* =========================================================
   REGENESIS
   Core Navigation
   File: js/core/navigation.js

   Handles:
   - Main navigation
   - Mobile menu
   - Active page
   - Internal navigation
   - Back button
   - Search navigation
   - Login/profile navigation
   - Logout buttons
   - Navigation guards
   ========================================================= */

import {
    getCurrentUser,
    logout
} from "./auth.js";


/* =========================================================
   CONFIG
========================================================= */

const ROUTES = {

    home:
        "/index.html",

    login:
        "/auth/login.html",

    register:
        "/auth/register.html",

    profile:
        "/pages/profile.html",

    editProfile:
        "/pages/edit-profile.html",

    inbox:
        "/pages/inbox.html",

    notifications:
        "/pages/notifications.html",

    search:
        "/pages/search.html",

    settings:
        "/pages/settings.html",

    about:
        "/pages/about.html",

    anime:
        "/pages/anime.html",

    manga:
        "/manga/index.html",

    cosplay:
        "/cosplay/index.html",

    news:
        "/news/index.html"
};


/* =========================================================
   NAVIGATION
========================================================= */

export function navigate(
    path,
    options = {}
) {

    if (!path) {
        return;
    }

    const {
        replace = false,
        newTab = false
    } = options;


    if (newTab) {

        window.open(
            path,
            "_blank",
            "noopener,noreferrer"
        );

        return;
    }


    if (replace) {

        window.location.replace(path);

    } else {

        window.location.href = path;
    }
}


/* =========================================================
   ROUTE HELPER
========================================================= */

export function goTo(
    route,
    options = {}
) {

    const path =
        ROUTES[route];


    if (!path) {

        console.error(
            `REGENESIS: Unknown route "${route}".`
        );

        return;
    }


    navigate(
        path,
        options
    );
}


/* =========================================================
   HOME
========================================================= */

export function goHome() {

    goTo("home");
}


/* =========================================================
   BACK
========================================================= */

export function goBack(
    fallback = ROUTES.home
) {

    if (
        window.history.length > 1 &&
        document.referrer
    ) {

        window.history.back();

    } else {

        navigate(
            fallback
        );
    }
}


/* =========================================================
   FORWARD
========================================================= */

export function goForward() {

    window.history.forward();
}


/* =========================================================
   CURRENT PATH
========================================================= */

export function getCurrentPath() {

    return window.location.pathname;
}


/* =========================================================
   ACTIVE PAGE
========================================================= */

export function getActiveRoute() {

    const path =
        window.location.pathname
            .replace(/\/+/g, "/")
            .toLowerCase();


    if (
        path === "/" ||
        path.endsWith("/index.html")
    ) {

        if (
            path.includes("/manga/")
        ) {
            return "manga";
        }

        if (
            path.includes("/news/")
        ) {
            return "news";
        }

        if (
            path.includes("/cosplay/")
        ) {
            return "cosplay";
        }

        return "home";
    }


    for (
        const [name, route]
        of Object.entries(ROUTES)
    ) {

        if (
            path === route.toLowerCase()
        ) {

            return name;
        }
    }


    if (
        path.includes("/anime/")
    ) {
        return "anime";
    }


    if (
        path.includes("/manga/")
    ) {
        return "manga";
    }


    if (
        path.includes("/cosplay/")
    ) {
        return "cosplay";
    }


    if (
        path.includes("/news/")
    ) {
        return "news";
    }


    return null;
}


/* =========================================================
   MARK ACTIVE NAVIGATION ITEM
========================================================= */

export function setActiveNavigation() {

    const activeRoute =
        getActiveRoute();


    const items =
        document.querySelectorAll(
            "[data-route]"
        );


    items.forEach(item => {

        const route =
            item.dataset.route;


        const isActive =
            route === activeRoute;


        item.classList.toggle(
            "active",
            isActive
        );


        item.setAttribute(
            "aria-current",
            isActive
                ? "page"
                : "false"
        );
    });
}


/* =========================================================
   NAVIGATION LINKS
========================================================= */

export function setupNavigationLinks() {

    const links =
        document.querySelectorAll(
            "[data-navigate]"
        );


    links.forEach(link => {

        link.addEventListener(
            "click",
            event => {

                const path =
                    link.dataset.navigate;


                if (!path) {
                    return;
                }


                event.preventDefault();


                navigate(
                    path
                );
            }
        );
    });
}


/* =========================================================
   ROUTE LINKS
========================================================= */

export function setupRouteLinks() {

    const links =
        document.querySelectorAll(
            "[data-route]"
        );


    links.forEach(link => {

        const route =
            link.dataset.route;


        const path =
            ROUTES[route];


        if (!path) {
            return;
        }


        if (
            link.tagName === "A"
        ) {

            link.href =
                path;
        }


        link.addEventListener(
            "click",
            event => {

                /*
                  Allow Ctrl / Cmd / middle click
                  to behave normally.
                */

                if (
                    event.ctrlKey ||
                    event.metaKey ||
                    event.shiftKey ||
                    event.button === 1
                ) {
                    return;
                }


                event.preventDefault();


                goTo(route);
            }
        );
    });
}


/* =========================================================
   MOBILE MENU
========================================================= */

export function setupMobileMenu() {

    const menuButton =
        document.querySelector(
            "[data-menu-toggle]"
        );


    const menu =
        document.querySelector(
            "[data-mobile-menu]"
        );


    if (
        !menuButton ||
        !menu
    ) {
        return;
    }


    menuButton.addEventListener(
        "click",
        () => {

            const isOpen =
                menu.classList.toggle(
                    "open"
                );


            menuButton.setAttribute(
                "aria-expanded",
                String(isOpen)
            );


            menuButton.setAttribute(
                "aria-label",
                isOpen
                    ? "Close menu"
                    : "Open menu"
            );
        }
    );


    /*
      Close menu after navigation.
    */

    menu.querySelectorAll("a")
        .forEach(link => {

            link.addEventListener(
                "click",
                () => {

                    menu.classList.remove(
                        "open"
                    );


                    menuButton.setAttribute(
                        "aria-expanded",
                        "false"
                    );
                }
            );
        });


    /*
      Close menu when clicking outside.
    */

    document.addEventListener(
        "click",
        event => {

            if (
                !menu.contains(event.target) &&
                !menuButton.contains(event.target)
            ) {

                menu.classList.remove(
                    "open"
                );


                menuButton.setAttribute(
                    "aria-expanded",
                    "false"
                );
            }
        }
    );
}


/* =========================================================
   SEARCH NAVIGATION
========================================================= */

export function setupSearchNavigation() {

    const forms =
        document.querySelectorAll(
            "[data-search-form]"
        );


    forms.forEach(form => {

        form.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const input =
                    form.querySelector(
                        "input[name='q'], input[type='search']"
                    );


                const query =
                    input?.value.trim() || "";


                if (!query) {

                    goTo("search");

                    return;
                }


                navigate(
                    `${ROUTES.search}?q=${encodeURIComponent(query)}`
                );
            }
        );
    });
}


/* =========================================================
   LOGIN / PROFILE BUTTON
========================================================= */

export async function setupAccountNavigation() {

    const user =
        await getCurrentUser();


    const accountButtons =
        document.querySelectorAll(
            "[data-account]"
        );


    accountButtons.forEach(button => {

        button.addEventListener(
            "click",
            event => {

                event.preventDefault();


                if (user) {

                    goTo("profile");

                } else {

                    goTo("login");
                }
            }
        );
    });
}


/* =========================================================
   LOGOUT BUTTONS
========================================================= */

export function setupNavigationLogout() {

    const buttons =
        document.querySelectorAll(
            "[data-navigation-logout]"
        );


    buttons.forEach(button => {

        button.addEventListener(
            "click",
            async event => {

                event.preventDefault();


                if (
                    button.disabled
                ) {
                    return;
                }


                button.disabled =
                    true;


                try {

                    await logout();

                } catch (error) {

                    console.error(
                        "REGENESIS: Logout failed.",
                        error
                    );


                    button.disabled =
                        false;
                }
            }
        );
    });
}


/* =========================================================
   PROTECTED NAVIGATION
========================================================= */

export async function requireNavigationAuth(
    destination
) {

    const user =
        await getCurrentUser();


    if (!user) {

        const current =
            window.location.pathname +
            window.location.search;


        const loginUrl =
            `${ROUTES.login}?redirect=${encodeURIComponent(current)}`;


        navigate(
            loginUrl,
            {
                replace: true
            }
        );


        return false;
    }


    if (destination) {

        navigate(
            destination
        );
    }


    return true;
}


/* =========================================================
   DATA-PROTECTED LINKS
========================================================= */

export function setupProtectedLinks() {

    const links =
        document.querySelectorAll(
            "[data-requires-auth]"
        );


    links.forEach(link => {

        link.addEventListener(
            "click",
            async event => {

                event.preventDefault();


                const user =
                    await getCurrentUser();


                if (!user) {

                    const current =
                        window.location.pathname +
                        window.location.search;


                    navigate(
                        `${ROUTES.login}?redirect=${encodeURIComponent(current)}`
                    );

                    return;
                }


                const href =
                    link.getAttribute("href");


                if (href) {

                    navigate(href);
                }
            }
        );
    });
}


/* =========================================================
   SCROLL TO TOP
========================================================= */

export function setupScrollToTop() {

    const button =
        document.querySelector(
            "[data-scroll-top]"
        );


    if (!button) {
        return;
    }


    button.addEventListener(
        "click",
        () => {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    );
}


/* =========================================================
   INTERNAL ANCHOR LINKS
========================================================= */

export function setupSmoothAnchors() {

    document.addEventListener(
        "click",
        event => {

            const link =
                event.target.closest(
                    "a[href^='#']"
                );


            if (!link) {
                return;
            }


            const targetId =
                link.getAttribute("href");


            if (
                !targetId ||
                targetId === "#"
            ) {
                return;
            }


            const target =
                document.querySelector(
                    targetId
                );


            if (!target) {
                return;
            }


            event.preventDefault();


            target.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });


            history.replaceState(
                null,
                "",
                targetId
            );
        }
    );
}


/* =========================================================
   HANDLE ESC KEY
========================================================= */

export function setupEscapeNavigation() {

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key !== "Escape"
            ) {
                return;
            }


            const menu =
                document.querySelector(
                    "[data-mobile-menu]"
                );


            const button =
                document.querySelector(
                    "[data-menu-toggle]"
                );


            if (menu) {

                menu.classList.remove(
                    "open"
                );
            }


            if (button) {

                button.setAttribute(
                    "aria-expanded",
                    "false"
                );
            }
        }
    );
}


/* =========================================================
   HANDLE LOGO
========================================================= */

export function setupLogo() {

    const logos =
        document.querySelectorAll(
            "[data-logo]"
        );


    logos.forEach(logo => {

        logo.addEventListener(
            "click",
            event => {

                event.preventDefault();

                goHome();
            }
        );
    });
}


/* =========================================================
   INITIALIZE NAVIGATION
========================================================= */

export async function initNavigation() {

    setupNavigationLinks();

    setupRouteLinks();

    setupMobileMenu();

    setupSearchNavigation();

    await setupAccountNavigation();

    setupNavigationLogout();

    setupProtectedLinks();

    setupScrollToTop();

    setupSmoothAnchors();

    setupEscapeNavigation();

    setupLogo();

    setActiveNavigation();


    return {
        currentRoute:
            getActiveRoute(),

        currentPath:
            getCurrentPath()
    };
}


/* =========================================================
   PUBLIC ROUTES
========================================================= */

export { ROUTES };


/* =========================================================
   AUTO START
========================================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        () => {

            initNavigation()
                .catch(error => {

                    console.error(
                        "REGENESIS navigation initialization failed:",
                        error
                    );

                });

        }
    );

} else {

    initNavigation()
        .catch(error => {

            console.error(
                "REGENESIS navigation initialization failed:",
                error
            );

        });
}