// js/gallery/gallery.js
// REGENESIS — Gallery System
// Real Supabase-powered gallery management

import { supabase } from "../supabase.js";

/* =========================================================
   CONFIG
========================================================= */

const STORAGE_BUCKET = "gallery";
const MAX_FILE_SIZE = 10 * 1024 * 1024;

const ALLOWED_IMAGE_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp"
];

/* =========================================================
   STATE
========================================================= */

let currentUser = null;
let currentItem = null;
let galleryItems = [];
let loading = false;
let realtimeChannel = null;

const listeners = new Set();

export const GALLERY_EVENTS = {
  LOADING: "gallery:loading",
  LOADED: "gallery:loaded",
  CREATED: "gallery:created",
  UPDATED: "gallery:updated",
  DELETED: "gallery:deleted",
  CHANGED: "gallery:changed",
  ERROR: "gallery:error"
};

/* =========================================================
   EVENTS
========================================================= */

function emit(event, detail = {}) {
  listeners.forEach((callback) => {
    try {
      callback(event, detail);
    } catch (error) {
      console.error(
        "Gallery listener error:",
        error
      );
    }
  });

  if (typeof document !== "undefined") {
    document.dispatchEvent(
      new CustomEvent(`regenesis:${event}`, {
        detail
      })
    );
  }
}

export function onGalleryChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

/* =========================================================
   CURRENT USER
========================================================= */

export async function getCurrentUser() {
  const {
    data: { user },
    error
  } = await supabase.auth.getUser();

  if (error) {
    console.error(
      "Failed to get current user:",
      error
    );

    return null;
  }

  currentUser = user || null;

  return currentUser;
}

/* =========================================================
   ADMIN CHECK
========================================================= */

export async function isAdmin(userId = null) {
  let id = userId;

  if (!id) {
    const user =
      currentUser ||
      await getCurrentUser();

    if (!user) {
      return false;
    }

    id = user.id;
  }

  const {
    data,
    error
  } = await supabase
    .from("profiles")
    .select("id, is_admin")
    .eq("id", id)
    .maybeSingle();

  if (error) {
    console.error(
      "Failed to check gallery admin:",
      error
    );

    return false;
  }

  return data?.is_admin === true;
}

/* =========================================================
   LOAD GALLERY
========================================================= */

export async function loadGallery(options = {}) {
  const {
    search = "",
    category = "",
    limit = 60,
    offset = 0
  } = options;

  loading = true;

  emit(GALLERY_EVENTS.LOADING, {
    search,
    category
  });

  try {
    let query = supabase
      .from("gallery_items")
      .select(`
        id,
        user_id,
        title,
        description,
        image_url,
        category,
        created_at,
        profiles (
          id,
          username,
          avatar_url
        )
      `);

    const searchValue =
      String(search || "").trim();

    const categoryValue =
      String(category || "").trim();

    /*
      Search by title only.
      User input is not inserted into a raw
      PostgREST .or() expression.
    */

    if (searchValue) {
      query = query.ilike(
        "title",
        `%${searchValue}%`
      );
    }

    if (categoryValue &&
        categoryValue !== "all") {
      query = query.eq(
        "category",
        categoryValue
      );
    }

    const safeLimit = Math.min(
      Math.max(
        Number(limit) || 60,
        1
      ),
      100
    );

    const safeOffset = Math.max(
      Number(offset) || 0,
      0
    );

    const {
      data,
      error
    } = await query
      .order("created_at", {
        ascending: false
      })
      .range(
        safeOffset,
        safeOffset + safeLimit - 1
      );

    if (error) {
      throw error;
    }

    galleryItems = data || [];

    emit(GALLERY_EVENTS.LOADED, {
      items: galleryItems,
      count: galleryItems.length
    });

    return galleryItems;
  } catch (error) {
    console.error(
      "Failed to load gallery:",
      error
    );

    emit(GALLERY_EVENTS.ERROR, {
      error
    });

    throw error;
  } finally {
    loading = false;
  }
}

/* =========================================================
   GET SINGLE ITEM
========================================================= */

export async function getGalleryItem(
  itemId
) {
  if (!itemId) {
    throw new Error(
      "Gallery item ID is required."
    );
  }

  const {
    data,
    error
  } = await supabase
    .from("gallery_items")
    .select(`
      id,
      user_id,
      title,
      description,
      image_url,
      category,
      created_at,
      profiles (
        id,
        username,
        avatar_url
      )
    `)
    .eq("id", itemId)
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Gallery item not found."
    );
  }

  currentItem = data;

  return data;
}

/* =========================================================
   GET ITEMS BY CATEGORY
========================================================= */

export async function getByCategory(
  category,
  options = {}
) {
  const categoryValue =
    String(category || "").trim();

  if (!categoryValue) {
    return [];
  }

  const {
    limit = 60
  } = options;

  const safeLimit = Math.min(
    Math.max(
      Number(limit) || 60,
      1
    ),
    100
  );

  const {
    data,
    error
  } = await supabase
    .from("gallery_items")
    .select(`
      id,
      user_id,
      title,
      description,
      image_url,
      category,
      created_at,
      profiles (
        id,
        username,
        avatar_url
      )
    `)
    .eq(
      "category",
      categoryValue
    )
    .order("created_at", {
      ascending: false
    })
    .limit(safeLimit);

  if (error) {
    throw error;
  }

  return data || [];
}

/* =========================================================
   SEARCH
========================================================= */

export async function searchGallery(
  search,
  options = {}
) {
  return loadGallery({
    ...options,
    search
  });
}

/* =========================================================
   IMAGE VALIDATION
========================================================= */

export function validateImageFile(file) {
  if (!file) {
    return {
      valid: false,
      message: "Please select an image."
    };
  }

  if (
    !ALLOWED_IMAGE_TYPES.includes(
      file.type
    )
  ) {
    return {
      valid: false,
      message:
        "Only JPG, PNG, and WEBP images are allowed."
    };
  }

  if (
    file.size > MAX_FILE_SIZE
  ) {
    return {
      valid: false,
      message:
        "Image must be 10 MB or smaller."
    };
  }

  return {
    valid: true,
    message: ""
  };
}

/* =========================================================
   FILE EXTENSION
========================================================= */

function getExtension(file) {
  const name =
    String(file?.name || "");

  const parts =
    name.split(".");

  if (parts.length > 1) {
    return parts
      .pop()
      .toLowerCase();
  }

  if (file?.type === "image/png") {
    return "png";
  }

  if (file?.type === "image/webp") {
    return "webp";
  }

  return "jpg";
}

/* =========================================================
   SAFE FILE NAME
========================================================= */

function createStoragePath(
  userId,
  file
) {
  const extension =
    getExtension(file);

  const randomPart =
    typeof crypto !== "undefined" &&
    crypto.randomUUID
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random()
          .toString(36)
          .slice(2)}`;

  return `${userId}/${Date.now()}-${randomPart}.${extension}`;
}

/* =========================================================
   CREATE GALLERY ITEM
========================================================= */

export async function createGalleryItem({
  file,
  title,
  description = "",
  category = "other"
}) {
  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(user.id);

  if (!admin) {
    throw new Error(
      "Only administrators can upload gallery items."
    );
  }

  const validation =
    validateImageFile(file);

  if (!validation.valid) {
    throw new Error(
      validation.message
    );
  }

  const cleanTitle =
    String(title || "").trim();

  if (!cleanTitle) {
    throw new Error(
      "Gallery title is required."
    );
  }

  const allowedCategories = [
    "art",
    "edit",
    "cosplay",
    "other"
  ];

  const cleanCategory =
    allowedCategories.includes(
      category
    )
      ? category
      : "other";

  const storagePath =
    createStoragePath(
      user.id,
      file
    );

  /*
    Upload the actual image.
  */

  const {
    error: uploadError
  } = await supabase.storage
    .from(STORAGE_BUCKET)
    .upload(
      storagePath,
      file,
      {
        cacheControl: "3600",
        upsert: false,
        contentType: file.type
      }
    );

  if (uploadError) {
    throw uploadError;
  }

  /*
    Get the public URL.
    The "gallery" bucket must be public.
  */

  const {
    data: publicData
  } = supabase.storage
    .from(STORAGE_BUCKET)
    .getPublicUrl(
      storagePath
    );

  const imageUrl =
    publicData?.publicUrl;

  if (!imageUrl) {
    await supabase.storage
      .from(STORAGE_BUCKET)
      .remove([
        storagePath
      ]);

    throw new Error(
      "Could not create image URL."
    );
  }

  /*
    Insert gallery metadata.
  */

  const {
    data,
    error
  } = await supabase
    .from("gallery_items")
    .insert({
      user_id: user.id,
      title: cleanTitle,
      description:
        String(
          description || ""
        ).trim() || null,
      image_url: imageUrl,
      category: cleanCategory
    })
    .select(`
      id,
      user_id,
      title,
      description,
      image_url,
      category,
      created_at
    `)
    .single();

  /*
    If database insertion fails,
    remove the uploaded image.
  */

  if (error) {
    await supabase.storage
      .from(STORAGE_BUCKET)
      .remove([
        storagePath
      ]);

    throw error;
  }

  galleryItems.unshift(data);

  emit(GALLERY_EVENTS.CREATED, {
    item: data
  });

  return data;
}

/* =========================================================
   UPDATE GALLERY ITEM
========================================================= */

export async function updateGalleryItem(
  itemId,
  updates = {}
) {
  if (!itemId) {
    throw new Error(
      "Gallery item ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(user.id);

  if (!admin) {
    throw new Error(
      "Only administrators can update gallery items."
    );
  }

  const allowedFields = [
    "title",
    "description",
    "category"
  ];

  const cleanUpdates = {};

  for (
    const field of allowedFields
  ) {
    if (
      Object.prototype.hasOwnProperty.call(
        updates,
        field
      )
    ) {
      cleanUpdates[field] =
        updates[field];
    }
  }

  if (
    cleanUpdates.title !== undefined
  ) {
    cleanUpdates.title =
      String(
        cleanUpdates.title
      ).trim();

    if (!cleanUpdates.title) {
      throw new Error(
        "Title cannot be empty."
      );
    }
  }

  if (
    cleanUpdates.description !==
    undefined
  ) {
    cleanUpdates.description =
      String(
        cleanUpdates.description ||
          ""
      ).trim() || null;
  }

  if (
    cleanUpdates.category !==
    undefined
  ) {
    const allowedCategories = [
      "art",
      "edit",
      "cosplay",
      "other"
    ];

    if (
      !allowedCategories.includes(
        cleanUpdates.category
      )
    ) {
      throw new Error(
        "Invalid gallery category."
      );
    }
  }

  const {
    data,
    error
  } = await supabase
    .from("gallery_items")
    .update(cleanUpdates)
    .eq(
      "id",
      itemId
    )
    .select(`
      id,
      user_id,
      title,
      description,
      image_url,
      category,
      created_at
    `)
    .single();

  if (error) {
    throw error;
  }

  currentItem = data;

  galleryItems =
    galleryItems.map(
      (item) =>
        item.id === itemId
          ? {
              ...item,
              ...data
            }
          : item
    );

  emit(GALLERY_EVENTS.UPDATED, {
    item: data
  });

  return data;
}

/* =========================================================
   GET STORAGE PATH FROM URL
========================================================= */

function getStoragePathFromURL(
  imageUrl
) {
  if (!imageUrl) {
    return null;
  }

  try {
    const url =
      new URL(imageUrl);

    const marker =
      `/storage/v1/object/public/${STORAGE_BUCKET}/`;

    const index =
      url.pathname.indexOf(
        marker
      );

    if (index === -1) {
      return null;
    }

    return decodeURIComponent(
      url.pathname.slice(
        index + marker.length
      )
    );
  } catch {
    return null;
  }
}

/* =========================================================
   DELETE GALLERY ITEM
========================================================= */

export async function deleteGalleryItem(
  itemId
) {
  if (!itemId) {
    throw new Error(
      "Gallery item ID is required."
    );
  }

  const user =
    currentUser ||
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "You must be logged in."
    );
  }

  const admin =
    await isAdmin(user.id);

  if (!admin) {
    throw new Error(
      "Only administrators can delete gallery items."
    );
  }

  /*
    Get the item first so we know
    which storage file to remove.
  */

  const item =
    currentItem?.id === itemId
      ? currentItem
      : await getGalleryItem(
          itemId
        );

  const {
    error
  } = await supabase
    .from("gallery_items")
    .delete()
    .eq(
      "id",
      itemId
    );

  if (error) {
    throw error;
  }

  /*
    Remove the actual image from Storage.
  */

  const storagePath =
    getStoragePathFromURL(
      item.image_url
    );

  if (storagePath) {
    const {
      error: storageError
    } = await supabase.storage
      .from(STORAGE_BUCKET)
      .remove([
        storagePath
      ]);

    if (storageError) {
      console.warn(
        "Gallery row deleted, but storage image could not be removed:",
        storageError
      );
    }
  }

  galleryItems =
    galleryItems.filter(
      (galleryItem) =>
        galleryItem.id !== itemId
    );

  if (
    currentItem?.id === itemId
  ) {
    currentItem = null;
  }

  emit(GALLERY_EVENTS.DELETED, {
    itemId
  });

  return {
    success: true
  };
}

/* =========================================================
   COUNT ITEMS
========================================================= */

export async function getGalleryCount(
  category = ""
) {
  let query = supabase
    .from("gallery_items")
    .select("id", {
      count: "exact",
      head: true
    });

  if (
    category &&
    category !== "all"
  ) {
    query = query.eq(
      "category",
      category
    );
  }

  const {
    count,
    error
  } = await query;

  if (error) {
    throw error;
  }

  return Number(
    count || 0
  );
}

/* =========================================================
   REALTIME
========================================================= */

export function subscribeToGallery() {
  if (realtimeChannel) {
    return realtimeChannel;
  }

  realtimeChannel = supabase
    .channel(
      "regenesis-gallery"
    )
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "gallery_items"
      },
      async (payload) => {
        emit(
          GALLERY_EVENTS.CHANGED,
          {
            payload
          }
        );

        try {
          await loadGallery();
        } catch (error) {
          console.error(
            "Failed to refresh gallery after realtime update:",
            error
          );
        }
      }
    )
    .subscribe((status) => {
      console.log(
        "Gallery realtime:",
        status
      );
    });

  return realtimeChannel;
}

/* =========================================================
   UNSUBSCRIBE
========================================================= */

export async function unsubscribeFromGallery() {
  if (!realtimeChannel) {
    return;
  }

  try {
    await supabase.removeChannel(
      realtimeChannel
    );
  } catch (error) {
    console.error(
      "Failed to remove gallery realtime:",
      error
    );
  }

  realtimeChannel = null;
}

/* =========================================================
   REFRESH
========================================================= */

export async function refreshGallery(
  options = {}
) {
  return loadGallery(options);
}

/* =========================================================
   STATE
========================================================= */

export function getGalleryItems() {
  return [...galleryItems];
}

export function getCurrentItem() {
  return currentItem;
}

export function getCurrentUser() {
  return currentUser;
}

export function isLoading() {
  return loading;
}

/* =========================================================
   INITIALIZE
========================================================= */

export async function initializeGallery(
  options = {}
) {
  await getCurrentUser();

  subscribeToGallery();

  return loadGallery(
    options
  );
}

/* =========================================================
   CLEANUP
========================================================= */

export async function destroyGallery() {
  await unsubscribeFromGallery();

  currentUser = null;
  currentItem = null;
  galleryItems = [];
  loading = false;

  listeners.clear();
}

/* =========================================================
   DEFAULT EXPORT
========================================================= */

export default {
  GALLERY_EVENTS,

  onGalleryChange,

  getCurrentUser,
  isAdmin,

  loadGallery,
  refreshGallery,
  searchGallery,
  getByCategory,

  getGalleryItem,
  getGalleryCount,

  validateImageFile,

  createGalleryItem,
  updateGalleryItem,
  deleteGalleryItem,

  subscribeToGallery,
  unsubscribeFromGallery,

  initializeGallery,
  destroyGallery,

  getGalleryItems,
  getCurrentItem,
  isLoading
};