// ============================================================
// REGENESIS
// js/search/search.js
// ============================================================

import { supabase } from "../supabase.js";

// ------------------------------------------------------------
// Configuration
// ------------------------------------------------------------

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 50;

const TABLES = {
  profiles: "profiles",
  anime: "anime",
  manga: "manga",
  games: "game_communities",
  news: "news",
  animeDiscussions: "anime_discussions",
  mangaDiscussions: "manga_discussions",
  gamePosts: "game_posts"
};


// ------------------------------------------------------------
// State
// ------------------------------------------------------------

let currentQuery = "";
let currentType = "all";

let results = {
  profiles: [],
  anime: [],
  manga: [],
  games: [],
  news: [],
  animeDiscussions: [],
  mangaDiscussions: [],
  gamePosts: []
};

let loading = false;
let lastError = null;

const listeners = new Set();


// ------------------------------------------------------------
// Events
// ------------------------------------------------------------

export const SEARCH_EVENTS = {
  SEARCHING: "searching",
  SEARCHED: "searched",
  ERROR: "error",
  CLEARED: "cleared",
  CHANGED: "changed"
};


// ------------------------------------------------------------
// Event system
// ------------------------------------------------------------

export function onSearchChange(callback) {
  if (typeof callback !== "function") {
    return () => {};
  }

  listeners.add(callback);

  return () => {
    listeners.delete(callback);
  };
}

function emit(event, data = null) {
  listeners.forEach((callback) => {
    try {
      callback({
        event,
        data,
        state: getState()
      });
    } catch (error) {
      console.error(
        "REGENESIS search listener error:",
        error
      );
    }
  });
}


// ------------------------------------------------------------
// Error helper
// ------------------------------------------------------------

function getErrorMessage(error) {
  if (!error) {
    return "Something went wrong.";
  }

  return (
    error.message ||
    error.error_description ||
    error.details ||
    error.hint ||
    "Something went wrong."
  );
}


// ------------------------------------------------------------
// Search normalization
// ------------------------------------------------------------

function normalizeQuery(query) {
  return String(query || "")
    .trim()
    .replace(/\s+/g, " ");
}


// ------------------------------------------------------------
// Escape LIKE special characters
// ------------------------------------------------------------

function escapeLike(value) {
  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/%/g, "\\%")
    .replace(/_/g, "\\_");
}


// ------------------------------------------------------------
// Validate search type
// ------------------------------------------------------------

function normalizeType(type) {
  const allowed = [
    "all",
    "profiles",
    "anime",
    "manga",
    "games",
    "news",
    "animeDiscussions",
    "mangaDiscussions",
    "gamePosts"
  ];

  return allowed.includes(type)
    ? type
    : "all";
}


// ------------------------------------------------------------
// Empty results
// ------------------------------------------------------------

function createEmptyResults() {
  return {
    profiles: [],
    anime: [],
    manga: [],
    games: [],
    news: [],
    animeDiscussions: [],
    mangaDiscussions: [],
    gamePosts: []
  };
}


// ------------------------------------------------------------
// Search profiles
// ------------------------------------------------------------

export async function searchProfiles(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.profiles)
    .select(`
      id,
      username,
      display_name,
      bio,
      avatar_url,
      banner_url,
      created_at
    `)
    .or(
      `username.ilike.${pattern},display_name.ilike.${pattern}`
    )
    .order("username", {
      ascending: true
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search anime
// ------------------------------------------------------------

export async function searchAnime(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.anime)
    .select(`
      id,
      title,
      slug,
      description,
      cover_url,
      genres,
      status,
      created_at
    `)
    .or(
      `title.ilike.${pattern},slug.ilike.${pattern}`
    )
    .order("title", {
      ascending: true
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search manga
// ------------------------------------------------------------

export async function searchManga(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.manga)
    .select(`
      id,
      title,
      slug,
      description,
      cover_url,
      author,
      artist,
      status,
      genres,
      created_at
    `)
    .or(
      `title.ilike.${pattern},slug.ilike.${pattern}`
    )
    .order("title", {
      ascending: true
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search games
// ------------------------------------------------------------

export async function searchGames(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.games)
    .select(`
      id,
      name,
      slug,
      description,
      image_url,
      created_at
    `)
    .or(
      `name.ilike.${pattern},slug.ilike.${pattern}`
    )
    .order("name", {
      ascending: true
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search news
// ------------------------------------------------------------

export async function searchNews(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.news)
    .select(`
      id,
      title,
      slug,
      excerpt,
      content,
      image_url,
      category,
      created_at,
      updated_at
    `)
    .or(
      `title.ilike.${pattern},slug.ilike.${pattern},excerpt.ilike.${pattern}`
    )
    .order("created_at", {
      ascending: false
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search anime discussions
// ------------------------------------------------------------

export async function searchAnimeDiscussions(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.animeDiscussions)
    .select(`
      id,
      anime_id,
      user_id,
      title,
      content,
      created_at,
      updated_at,
      profiles (
        id,
        username,
        display_name,
        avatar_url
      )
    `)
    .or(
      `title.ilike.${pattern},content.ilike.${pattern}`
    )
    .order("created_at", {
      ascending: false
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search manga discussions
// ------------------------------------------------------------

export async function searchMangaDiscussions(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.mangaDiscussions)
    .select(`
      id,
      manga_id,
      user_id,
      title,
      content,
      created_at,
      updated_at,
      profiles (
        id,
        username,
        display_name,
        avatar_url
      )
    `)
    .or(
      `title.ilike.${pattern},content.ilike.${pattern}`
    )
    .order("created_at", {
      ascending: false
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search game posts
// ------------------------------------------------------------

export async function searchGamePosts(
  query,
  limit = DEFAULT_LIMIT
) {
  const value = normalizeQuery(query);

  if (!value) {
    return [];
  }

  limit = Math.min(
    Math.max(Number(limit) || DEFAULT_LIMIT, 1),
    MAX_LIMIT
  );

  const pattern = `%${escapeLike(value)}%`;

  const {
    data,
    error
  } = await supabase
    .from(TABLES.gamePosts)
    .select(`
      id,
      game_id,
      user_id,
      content,
      created_at,
      profiles (
        id,
        username,
        display_name,
        avatar_url
      )
    `)
    .ilike(
      "content",
      pattern
    )
    .order("created_at", {
      ascending: false
    })
    .limit(limit);

  if (error) {
    throw error;
  }

  return data || [];
}


// ------------------------------------------------------------
// Search EVERYTHING
// ------------------------------------------------------------

export async function searchAll(
  query,
  {
    limit = DEFAULT_LIMIT
  } = {}
) {
  const value = normalizeQuery(query);

  if (!value) {
    return createEmptyResults();
  }

  const [
    profiles,
    anime,
    manga,
    games,
    news,
    animeDiscussions,
    mangaDiscussions,
    gamePosts
  ] = await Promise.all([
    searchProfiles(value, limit),
    searchAnime(value, limit),
    searchManga(value, limit),
    searchGames(value, limit),
    searchNews(value, limit),
    searchAnimeDiscussions(value, limit),
    searchMangaDiscussions(value, limit),
    searchGamePosts(value, limit)
  ]);

  return {
    profiles,
    anime,
    manga,
    games,
    news,
    animeDiscussions,
    mangaDiscussions,
    gamePosts
  };
}


// ------------------------------------------------------------
// Search one category
// ------------------------------------------------------------

export async function searchByType(
  query,
  type = "all",
  options = {}
) {
  const normalizedType =
    normalizeType(type);

  if (normalizedType === "all") {
    return searchAll(query, options);
  }

  const functions = {
    profiles: searchProfiles,
    anime: searchAnime,
    manga: searchManga,
    games: searchGames,
    news: searchNews,
    animeDiscussions: searchAnimeDiscussions,
    mangaDiscussions: searchMangaDiscussions,
    gamePosts: searchGamePosts
  };

  const searchFunction =
    functions[normalizedType];

  if (!searchFunction) {
    return [];
  }

  return searchFunction(
    query,
    options.limit || DEFAULT_LIMIT
  );
}


// ------------------------------------------------------------
// Main search
// ------------------------------------------------------------

export async function search(
  query,
  {
    type = "all",
    limit = DEFAULT_LIMIT
  } = {}
) {
  const value = normalizeQuery(query);
  const normalizedType =
    normalizeType(type);

  currentQuery = value;
  currentType = normalizedType;

  lastError = null;

  if (!value) {
    results = createEmptyResults();

    emit(
      SEARCH_EVENTS.CLEARED,
      results
    );

    return results;
  }

  loading = true;

  emit(
    SEARCH_EVENTS.SEARCHING,
    {
      query: value,
      type: normalizedType
    }
  );

  try {
    const data =
      await searchByType(
        value,
        normalizedType,
        { limit }
      );

    if (normalizedType === "all") {
      results = data;
    } else {
      results = createEmptyResults();

      results[normalizedType] = data;
    }

    emit(
      SEARCH_EVENTS.SEARCHED,
      results
    );

    emit(
      SEARCH_EVENTS.CHANGED,
      results
    );

    return results;

  } catch (error) {
    lastError = error;

    emit(
      SEARCH_EVENTS.ERROR,
      error
    );

    throw error;

  } finally {
    loading = false;
  }
}


// ------------------------------------------------------------
// Quick search
// ------------------------------------------------------------

export async function quickSearch(
  query,
  limit = 8
) {
  const value = normalizeQuery(query);

  if (!value) {
    return createEmptyResults();
  }

  return searchAll(value, {
    limit: Math.min(
      Math.max(Number(limit) || 8, 1),
      20
    )
  });
}


// ------------------------------------------------------------
// Search users only
// ------------------------------------------------------------

export async function searchUsers(
  query,
  limit = DEFAULT_LIMIT
) {
  return searchProfiles(
    query,
    limit
  );
}


// ------------------------------------------------------------
// Search communities
// ------------------------------------------------------------

export async function searchCommunities(
  query,
  limit = DEFAULT_LIMIT
) {
  const [
    anime,
    manga,
    games
  ] = await Promise.all([
    searchAnime(query, limit),
    searchManga(query, limit),
    searchGames(query, limit)
  ]);

  return {
    anime,
    manga,
    games
  };
}


// ------------------------------------------------------------
// Search discussions
// ------------------------------------------------------------

export async function searchDiscussions(
  query,
  limit = DEFAULT_LIMIT
) {
  const [
    animeDiscussions,
    mangaDiscussions,
    gamePosts
  ] = await Promise.all([
    searchAnimeDiscussions(
      query,
      limit
    ),
    searchMangaDiscussions(
      query,
      limit
    ),
    searchGamePosts(
      query,
      limit
    )
  ]);

  return {
    animeDiscussions,
    mangaDiscussions,
    gamePosts
  };
}


// ------------------------------------------------------------
// Count all search results
// ------------------------------------------------------------

export function getResultCount(
  resultSet = results
) {
  if (!resultSet) {
    return 0;
  }

  return Object.values(resultSet)
    .reduce(
      (total, items) =>
        total +
        (Array.isArray(items)
          ? items.length
          : 0),
      0
    );
}


// ------------------------------------------------------------
// Count one category
// ------------------------------------------------------------

export function getCategoryCount(
  category,
  resultSet = results
) {
  if (
    !resultSet ||
    !Array.isArray(resultSet[category])
  ) {
    return 0;
  }

  return resultSet[category].length;
}


// ------------------------------------------------------------
// Check whether results exist
// ------------------------------------------------------------

export function hasResults(
  resultSet = results
) {
  return getResultCount(
    resultSet
  ) > 0;
}


// ------------------------------------------------------------
// Clear search
// ------------------------------------------------------------

export function clearSearch() {
  currentQuery = "";
  currentType = "all";
  results = createEmptyResults();
  lastError = null;

  emit(
    SEARCH_EVENTS.CLEARED,
    results
  );

  emit(
    SEARCH_EVENTS.CHANGED,
    results
  );
}


// ------------------------------------------------------------
// Get current state
// ------------------------------------------------------------

export function getState() {
  return {
    currentQuery,
    currentType,

    results: {
      ...results,
      profiles: [
        ...results.profiles
      ],
      anime: [
        ...results.anime
      ],
      manga: [
        ...results.manga
      ],
      games: [
        ...results.games
      ],
      news: [
        ...results.news
      ],
      animeDiscussions: [
        ...results.animeDiscussions
      ],
      mangaDiscussions: [
        ...results.mangaDiscussions
      ],
      gamePosts: [
        ...results.gamePosts
      ]
    },

    loading,

    lastError
  };
}


// ------------------------------------------------------------
// Getters
// ------------------------------------------------------------

export function getCurrentQuery() {
  return currentQuery;
}

export function getCurrentType() {
  return currentType;
}

export function getResults() {
  return getState().results;
}

export function isSearching() {
  return loading;
}

export function getLastError() {
  return lastError;
}


// ------------------------------------------------------------
// Cleanup
// ------------------------------------------------------------

export function destroySearch() {
  currentQuery = "";
  currentType = "all";

  results = createEmptyResults();

  loading = false;
  lastError = null;

  listeners.clear();
}


// ------------------------------------------------------------
// Default export
// ------------------------------------------------------------

export default {
  search,
  searchAll,
  searchByType,
  quickSearch,

  searchProfiles,
  searchUsers,

  searchAnime,
  searchManga,
  searchGames,
  searchNews,

  searchAnimeDiscussions,
  searchMangaDiscussions,
  searchGamePosts,

  searchCommunities,
  searchDiscussions,

  getResultCount,
  getCategoryCount,
  hasResults,

  clearSearch,

  getCurrentQuery,
  getCurrentType,
  getResults,
  isSearching,
  getLastError,

  getState,

  onSearchChange,

  destroySearch
};