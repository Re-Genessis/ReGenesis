/* =========================================================
   REGENESIS
   js/anime/discussion.js

   REAL ANIME DISCUSSION SYSTEM

   Handles:
   - Loading discussions
   - Creating discussions
   - Loading comments
   - Posting comments
   - Likes
   - Deleting own posts/comments
   - Authentication
   - Realtime updates
   - Search/filter support

   Supabase client:
   ../supabase.js
========================================================= */

import { supabase } from "../supabase.js";


/* =========================================================
   CONFIG
========================================================= */

const CONFIG = {

    postsTable: "posts",

    commentsTable: "comments",

    likesTable: "post_likes",

    profilesTable: "profiles",

    animeCategory: "anime",

    maxPosts: 30,

    maxComments: 100

};


/* =========================================================
   STATE
========================================================= */

let currentUser = null;

let currentPostId = null;

let currentPost = null;

let realtimeChannels = [];


/* =========================================================
   DOM
========================================================= */

function $(id) {
    return document.getElementById(id);
}


/* =========================================================
   AUTHENTICATION
========================================================= */

async function getCurrentUser() {

    const {
        data,
        error
    } = await supabase.auth.getUser();


    if (error) {

        console.error(
            "Unable to get user:",
            error
        );

        currentUser = null;

        return null;
    }


    currentUser =
        data?.user || null;


    return currentUser;
}


/* =========================================================
   AUTH STATE
========================================================= */

supabase.auth.onAuthStateChange(
    (_event, session) => {

        currentUser =
            session?.user || null;

        updateAuthUI();

    }
);


/* =========================================================
   AUTH UI
========================================================= */

function updateAuthUI() {

    const loginButton =
        $("loginButton");


    const profileButton =
        $("profileButton");


    const createButton =
        $("createDiscussionButton");


    if (currentUser) {

        if (loginButton) {

            loginButton.textContent =
                "Profile";

            loginButton.href =
                "../profile.html";
        }


        if (profileButton) {

            profileButton.style.display =
                "inline-flex";
        }


        if (createButton) {

            createButton.style.display =
                "inline-flex";
        }

    } else {

        if (loginButton) {

            loginButton.textContent =
                "Login";

            loginButton.href =
                "../../auth/login.html";
        }


        if (profileButton) {

            profileButton.style.display =
                "none";
        }


        if (createButton) {

            createButton.style.display =
                "inline-flex";

            createButton.onclick =
                () => {

                    window.location.href =
                        "../../auth/login.html";

                };
        }
    }
}


/* =========================================================
   GET POST ID
========================================================= */

function getPostIdFromURL() {

    const params =
        new URLSearchParams(
            window.location.search
        );


    return (
        params.get("id") ||
        params.get("post")
    );
}


/* =========================================================
   LOAD ANIME DISCUSSIONS
========================================================= */

async function loadAnimeDiscussions(options = {}) {

    const container =
        options.containerId
            ? $(options.containerId)
            : $("discussionList");


    if (!container) {
        return;
    }


    container.innerHTML = `
        <div class="discussion-loading">
            Loading real discussions...
        </div>
    `;


    let query =
        supabase
            .from(CONFIG.postsTable)
            .select(`
                id,
                user_id,
                title,
                content,
                category,
                created_at
            `)
            .eq(
                "category",
                CONFIG.animeCategory
            );


    if (options.search) {

        const search =
            options.search.trim();


        if (search) {

            query =
                query.or(
                    `title.ilike.%${escapeForLike(search)}%,content.ilike.%${escapeForLike(search)}%`
                );
        }
    }


    const ascending =
        options.order === "oldest";


    const {
        data,
        error
    } =
        await query
            .order(
                "created_at",
                {
                    ascending
                }
            )
            .limit(
                options.limit ||
                CONFIG.maxPosts
            );


    if (error) {

        console.error(
            "Anime discussion error:",
            error
        );


        container.innerHTML = `
            <div class="discussion-error">
                <strong>Unable to load discussions.</strong>
                <br>
                ${escapeHTML(error.message)}
            </div>
        `;

        return [];
    }


    if (!data || data.length === 0) {

        container.innerHTML = `
            <div class="discussion-empty">
                <strong>No anime discussions yet.</strong>
                <br>
                Be the first member to start a conversation.
            </div>
        `;

        return [];
    }


    /*
      Load profiles separately.

      This avoids requiring a foreign-key relationship
      to already exist in Supabase.
    */

    const userIds =
        [
            ...new Set(
                data
                    .map(post => post.user_id)
                    .filter(Boolean)
            )
        ];


    const profiles =
        await getProfiles(
            userIds
        );


    container.innerHTML = "";


    data.forEach(
        post => {

            container.appendChild(
                createDiscussionElement(
                    post,
                    profiles[post.user_id]
                )
            );

        }
    );


    return data;
}


/* =========================================================
   CREATE DISCUSSION ELEMENT
========================================================= */

function createDiscussionElement(
    post,
    profile
) {

    const article =
        document.createElement("article");


    article.className =
        "discussion-card";


    article.dataset.postId =
        post.id;


    const username =
        profile?.username ||
        profile?.display_name ||
        "REGENESIS Member";


    const excerpt =
        stripHTML(
            post.content || ""
        );


    const isOwner =
        currentUser &&
        currentUser.id === post.user_id;


    article.innerHTML = `

        <div class="discussion-card-header">

            <div>

                <div class="discussion-author">

                    ${escapeHTML(username)}

                </div>

                <div class="discussion-date">

                    ${formatDate(post.created_at)}

                </div>

            </div>

            ${
                isOwner
                    ? `
                        <button
                            type="button"
                            class="discussion-delete"
                            data-delete-post="${escapeHTML(post.id)}"
                        >
                            Delete
                        </button>
                    `
                    : ""
            }

        </div>


        <a
            href="discussion.html?id=${encodeURIComponent(post.id)}"
            class="discussion-content-link"
        >

            <h3>

                ${escapeHTML(
                    post.title ||
                    "Untitled discussion"
                )}

            </h3>


            <p>

                ${escapeHTML(
                    excerpt.length > 240
                        ? excerpt.substring(0, 240) + "..."
                        : excerpt
                )}

            </p>

        </a>


        <div class="discussion-footer">

            <button
                type="button"
                class="discussion-action"
                data-open-post="${escapeHTML(post.id)}"
            >
                💬 Discuss
            </button>


            <button
                type="button"
                class="discussion-action"
                data-like-post="${escapeHTML(post.id)}"
            >
                ♡ Like
            </button>

        </div>

    `;


    const deleteButton =
        article.querySelector(
            "[data-delete-post]"
        );


    if (deleteButton) {

        deleteButton.addEventListener(
            "click",
            event => {

                event.preventDefault();

                deletePost(
                    post.id
                );

            }
        );
    }


    const openButton =
        article.querySelector(
            "[data-open-post]"
        );


    if (openButton) {

        openButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "discussion.html?id=" +
                    encodeURIComponent(
                        post.id
                    );

            }
        );
    }


    const likeButton =
        article.querySelector(
            "[data-like-post]"
        );


    if (likeButton) {

        likeButton.addEventListener(
            "click",
            () => {

                toggleLike(
                    post.id,
                    likeButton
                );

            }
        );
    }


    return article;
}


/* =========================================================
   LOAD SINGLE DISCUSSION
========================================================= */

async function loadDiscussion(
    postId = getPostIdFromURL()
) {

    if (!postId) {

        showDiscussionError(
            "No discussion was selected."
        );

        return null;
    }


    currentPostId =
        postId;


    const {
        data,
        error
    } =
        await supabase
            .from(CONFIG.postsTable)
            .select(`
                id,
                user_id,
                title,
                content,
                category,
                created_at
            `)
            .eq(
                "id",
                postId
            )
            .eq(
                "category",
                CONFIG.animeCategory
            )
            .maybeSingle();


    if (error) {

        console.error(
            "Single discussion error:",
            error
        );


        showDiscussionError(
            "Unable to load this discussion."
        );

        return null;
    }


    if (!data) {

        showDiscussionError(
            "This discussion doesn't exist."
        );

        return null;
    }


    currentPost =
        data;


    const profiles =
        await getProfiles(
            data.user_id
                ? [data.user_id]
                : []
        );


    renderSingleDiscussion(
        data,
        profiles[data.user_id]
    );


    await loadComments(
        data.id
    );


    setupDiscussionRealtime(
        data.id
    );


    return data;
}


/* =========================================================
   RENDER SINGLE DISCUSSION
========================================================= */

function renderSingleDiscussion(
    post,
    profile
) {

    const title =
        $("discussionTitle");


    const content =
        $("discussionContent");


    const author =
        $("discussionAuthor");


    const date =
        $("discussionDate");


    if (title) {

        title.textContent =
            post.title ||
            "Untitled discussion";
    }


    if (content) {

        /*
          Content can contain HTML if your post editor
          supports formatted posts.

          For a simple plain-text system use textContent.
        */

        content.textContent =
            stripHTML(
                post.content || ""
            );
    }


    if (author) {

        author.textContent =
            profile?.username ||
            profile?.display_name ||
            "REGENESIS Member";
    }


    if (date) {

        date.textContent =
            formatDate(
                post.created_at
            );
    }


    const deleteButton =
        $("deleteDiscussionButton");


    if (
        deleteButton &&
        currentUser &&
        currentUser.id === post.user_id
    ) {

        deleteButton.style.display =
            "inline-flex";


        deleteButton.onclick =
            () => {

                deletePost(
                    post.id
                );

            };
    }
}


/* =========================================================
   CREATE DISCUSSION
========================================================= */

async function createDiscussion({
    title,
    content,
    category = CONFIG.animeCategory
}) {

    if (!currentUser) {

        window.location.href =
            "../../auth/login.html";

        return null;
    }


    const cleanTitle =
        String(title || "").trim();


    const cleanContent =
        String(content || "").trim();


    if (!cleanTitle) {

        throw new Error(
            "A discussion title is required."
        );
    }


    if (!cleanContent) {

        throw new Error(
            "Discussion content is required."
        );
    }


    if (
        category !==
        CONFIG.animeCategory
    ) {

        throw new Error(
            "Invalid anime discussion category."
        );
    }


    const payload = {

        user_id:
            currentUser.id,

        title:
            cleanTitle,

        content:
            cleanContent,

        category:
            CONFIG.animeCategory

    };


    const {
        data,
        error
    } =
        await supabase
            .from(CONFIG.postsTable)
            .insert(payload)
            .select()
            .single();


    if (error) {

        console.error(
            "Create discussion error:",
            error
        );

        throw error;
    }


    return data;
}


/* =========================================================
   CREATE DISCUSSION FORM
========================================================= */

function setupDiscussionForm() {

    const form =
        $("discussionForm");


    if (!form) {
        return;
    }


    form.addEventListener(
        "submit",
        async event => {

            event.preventDefault();


            if (!currentUser) {

                window.location.href =
                    "../../auth/login.html";

                return;
            }


            const titleInput =
                $("discussionTitleInput");


            const contentInput =
                $("discussionContentInput");


            const submitButton =
                form.querySelector(
                    "button[type='submit']"
                );


            const title =
                titleInput?.value || "";


            const content =
                contentInput?.value || "";


            try {

                if (submitButton) {

                    submitButton.disabled =
                        true;

                    submitButton.textContent =
                        "Publishing...";
                }


                const post =
                    await createDiscussion({
                        title,
                        content
                    });


                if (post) {

                    window.location.href =
                        "discussion.html?id=" +
                        encodeURIComponent(
                            post.id
                        );
                }

            } catch (error) {

                console.error(
                    error
                );


                showFormError(
                    error.message ||
                    "Unable to publish discussion."
                );


                if (submitButton) {

                    submitButton.disabled =
                        false;

                    submitButton.textContent =
                        "Publish";
                }
            }

        }
    );
}


/* =========================================================
   LOAD COMMENTS
========================================================= */

async function loadComments(
    postId = currentPostId
) {

    const container =
        $("commentsList");


    if (!container || !postId) {
        return [];
    }


    container.innerHTML = `
        <div class="comments-loading">
            Loading comments...
        </div>
    `;


    const {
        data,
        error
    } =
        await supabase
            .from(CONFIG.commentsTable)
            .select(`
                id,
                post_id,
                user_id,
                content,
                created_at
            `)
            .eq(
                "post_id",
                postId
            )
            .order(
                "created_at",
                {
                    ascending:true
                }
            )
            .limit(
                CONFIG.maxComments
            );


    if (error) {

        console.error(
            "Comments error:",
            error
        );


        container.innerHTML = `
            <div class="comments-error">
                Unable to load comments.
            </div>
        `;

        return [];
    }


    if (!data || data.length === 0) {

        container.innerHTML = `
            <div class="comments-empty">
                No comments yet. Start the conversation.
            </div>
        `;

        updateCommentCount(0);

        return [];
    }


    const userIds =
        [
            ...new Set(
                data
                    .map(comment =>
                        comment.user_id
                    )
                    .filter(Boolean)
            )
        ];


    const profiles =
        await getProfiles(
            userIds
        );


    container.innerHTML = "";


    data.forEach(
        comment => {

            container.appendChild(
                createCommentElement(
                    comment,
                    profiles[comment.user_id]
                )
            );

        }
    );


    updateCommentCount(
        data.length
    );


    return data;
}


/* =========================================================
   CREATE COMMENT ELEMENT
========================================================= */

function createCommentElement(
    comment,
    profile
) {

    const element =
        document.createElement("article");


    element.className =
        "comment";


    element.dataset.commentId =
        comment.id;


    const username =
        profile?.username ||
        profile?.display_name ||
        "REGENESIS Member";


    const owner =
        currentUser &&
        currentUser.id === comment.user_id;


    element.innerHTML = `

        <div class="comment-header">

            <strong>
                ${escapeHTML(username)}
            </strong>

            <span>
                ${formatDate(comment.created_at)}
            </span>

        </div>


        <div class="comment-body">

            ${escapeHTML(
                stripHTML(
                    comment.content || ""
                )
            )}

        </div>


        ${
            owner
                ? `
                    <button
                        type="button"
                        class="comment-delete"
                    >
                        Delete
                    </button>
                `
                : ""
        }

    `;


    const deleteButton =
        element.querySelector(
            ".comment-delete"
        );


    if (deleteButton) {

        deleteButton.addEventListener(
            "click",
            () => {

                deleteComment(
                    comment.id
                );

            }
        );
    }


    return element;
}


/* =========================================================
   ADD COMMENT
========================================================= */

async function addComment(
    content,
    postId = currentPostId
) {

    if (!currentUser) {

        window.location.href =
            "../../auth/login.html";

        return null;
    }


    if (!postId) {

        throw new Error(
            "No discussion selected."
        );
    }


    const cleanContent =
        String(content || "").trim();


    if (!cleanContent) {

        throw new Error(
            "Comment cannot be empty."
        );
    }


    const payload = {

        post_id:
            postId,

        user_id:
            currentUser.id,

        content:
            cleanContent

    };


    const {
        data,
        error
    } =
        await supabase
            .from(CONFIG.commentsTable)
            .insert(payload)
            .select()
            .single();


    if (error) {

        console.error(
            "Comment error:",
            error
        );

        throw error;
    }


    return data;
}


/* =========================================================
   COMMENT FORM
========================================================= */

function setupCommentForm() {

    const form =
        $("commentForm");


    if (!form) {
        return;
    }


    form.addEventListener(
        "submit",
        async event => {

            event.preventDefault();


            if (!currentUser) {

                window.location.href =
                    "../../auth/login.html";

                return;
            }


            const input =
                $("commentInput");


            const button =
                form.querySelector(
                    "button[type='submit']"
                );


            try {

                if (button) {

                    button.disabled =
                        true;

                    button.textContent =
                        "Posting...";
                }


                await addComment(
                    input?.value || ""
                );


                if (input) {
                    input.value = "";
                }


                await loadComments();


            } catch (error) {

                console.error(
                    error
                );


                showFormError(
                    error.message ||
                    "Unable to post comment."
                );


            } finally {

                if (button) {

                    button.disabled =
                        false;

                    button.textContent =
                        "Comment";
                }
            }

        }
    );
}


/* =========================================================
   DELETE POST
========================================================= */

async function deletePost(
    postId
) {

    if (!currentUser) {
        return;
    }


    const confirmed =
        window.confirm(
            "Delete this discussion?"
        );


    if (!confirmed) {
        return;
    }


    const {
        data,
        error
    } =
        await supabase
            .from(CONFIG.postsTable)
            .delete()
            .eq(
                "id",
                postId
            )
            .eq(
                "user_id",
                currentUser.id
            )
            .select();


    if (error) {

        console.error(
            "Delete post error:",
            error
        );

        showFormError(
            "Unable to delete discussion."
        );

        return;
    }


    if (!data || data.length === 0) {

        showFormError(
            "You don't have permission to delete this discussion."
        );

        return;
    }


    if (
        currentPostId === postId
    ) {

        window.location.href =
            "index.html";

        return;
    }


    const element =
        document.querySelector(
            `[data-post-id="${CSS.escape(postId)}"]`
        );


    if (element) {
        element.remove();
    }
}


/* =========================================================
   DELETE COMMENT
========================================================= */

async function deleteComment(
    commentId
) {

    if (!currentUser) {
        return;
    }


    const confirmed =
        window.confirm(
            "Delete this comment?"
        );


    if (!confirmed) {
        return;
    }


    const {
        data,
        error
    } =
        await supabase
            .from(CONFIG.commentsTable)
            .delete()
            .eq(
                "id",
                commentId
            )
            .eq(
                "user_id",
                currentUser.id
            )
            .select();


    if (error) {

        console.error(
            "Delete comment error:",
            error
        );

        showFormError(
            "Unable to delete comment."
        );

        return;
    }


    if (!data || data.length === 0) {

        showFormError(
            "You don't have permission to delete this comment."
        );

        return;
    }


    const element =
        document.querySelector(
            `[data-comment-id="${CSS.escape(commentId)}"]`
        );


    if (element) {
        element.remove();
    }


    const comments =
        document.querySelectorAll(
            ".comment"
        );


    updateCommentCount(
        comments.length
    );
}


/* =========================================================
   LIKE / UNLIKE
========================================================= */

async function toggleLike(
    postId,
    button = null
) {

    if (!currentUser) {

        window.location.href =
            "../../auth/login.html";

        return;
    }


    const {
        data: existing,
        error: checkError
    } =
        await supabase
            .from(CONFIG.likesTable)
            .select("id")
            .eq(
                "post_id",
                postId
            )
            .eq(
                "user_id",
                currentUser.id
            )
            .maybeSingle();


    if (checkError) {

        console.error(
            "Like check error:",
            checkError
        );

        return;
    }


    if (existing) {

        const {
            error
        } =
            await supabase
                .from(CONFIG.likesTable)
                .delete()
                .eq(
                    "id",
                    existing.id
                );


        if (error) {

            console.error(
                "Unlike error:",
                error
            );

            return;
        }


        if (button) {

            button.textContent =
                "♡ Like";
        }


    } else {

        const {
            error
        } =
            await supabase
                .from(CONFIG.likesTable)
                .insert({
                    post_id:
                        postId,

                    user_id:
                        currentUser.id
                });


        if (error) {

            console.error(
                "Like error:",
                error
            );

            return;
        }


        if (button) {

            button.textContent =
                "♥ Liked";
        }
    }
}


/* =========================================================
   LOAD PROFILES
========================================================= */

async function getProfiles(
    userIds
) {

    if (!userIds || !userIds.length) {
        return {};
    }


    const {
        data,
        error
    } =
        await supabase
            .from(CONFIG.profilesTable)
            .select(
                "id,username,display_name,avatar_url"
            )
            .in(
                "id",
                userIds
            );


    if (error) {

        console.error(
            "Profiles error:",
            error
        );

        return {};
    }


    const result = {};


    (data || []).forEach(
        profile => {

            result[profile.id] =
                profile;

        }
    );


    return result;
}


/* =========================================================
   REALTIME
========================================================= */

function setupDiscussionRealtime(
    postId = currentPostId
) {

    if (!postId) {
        return;
    }


    cleanupRealtime();


    const postChannel =
        supabase
            .channel(
                "anime-post-" + postId
            )
            .on(
                "postgres_changes",
                {
                    event:"*",
                    schema:"public",
                    table:CONFIG.postsTable,
                    filter:
                        "id=eq." + postId
                },
                () => {

                    loadDiscussion(
                        postId
                    );

                }
            )
            .subscribe();


    const commentChannel =
        supabase
            .channel(
                "anime-comments-" + postId
            )
            .on(
                "postgres_changes",
                {
                    event:"*",
                    schema:"public",
                    table:CONFIG.commentsTable,
                    filter:
                        "post_id=eq." + postId
                },
                () => {

                    loadComments(
                        postId
                    );

                }
            )
            .subscribe();


    realtimeChannels.push(
        postChannel,
        commentChannel
    );
}


/* =========================================================
   REALTIME DISCUSSION LIST
========================================================= */

function setupDiscussionListRealtime() {

    const channel =
        supabase
            .channel(
                "anime-discussion-list"
            )
            .on(
                "postgres_changes",
                {
                    event:"*",
                    schema:"public",
                    table:CONFIG.postsTable,
                    filter:
                        "category=eq.anime"
                },
                () => {

                    loadAnimeDiscussions();

                }
            )
            .subscribe();


    realtimeChannels.push(
        channel
    );
}


/* =========================================================
   CLEAN REALTIME CHANNELS
========================================================= */

function cleanupRealtime() {

    realtimeChannels.forEach(
        channel => {

            supabase.removeChannel(
                channel
            );

        }
    );


    realtimeChannels = [];
}


/* =========================================================
   COMMENT COUNT
========================================================= */

function updateCommentCount(
    count
) {

    const elements =
        document.querySelectorAll(
            "#commentCount,.commentCount"
        );


    elements.forEach(
        element => {

            element.textContent =
                String(count);

        }
    );
}


/* =========================================================
   SEARCH
========================================================= */

function setupSearch() {

    const input =
        $("animeDiscussionSearch");


    const button =
        $("animeDiscussionSearchButton");


    if (button) {

        button.addEventListener(
            "