/* =========================================================
   REGENESIS
   js/anime/anime.js

   Anime community / quiz frontend logic
   Uses the existing Supabase client.

   Expected:
   ../supabase.js

   Expected database tables:
   - anime_quizzes
   - quiz_answers
   - profiles

   This file does NOT create fake anime data.
========================================================= */

import { supabase } from "../supabase.js";


/* =========================================================
   CONFIG
========================================================= */

const CONFIG = {
    quizTable: "anime_quizzes",
    answerTable: "quiz_answers",
    profileTable: "profiles",

    defaultQuizLimit: 1,
    leaderboardLimit: 10
};


/* =========================================================
   STATE
========================================================= */

let currentQuiz = null;
let currentQuestion = null;
let currentUser = null;

let selectedAnswer = null;
let answerLocked = false;

let quizScore = 0;
let questionsAnswered = 0;


/* =========================================================
   DOM HELPERS
========================================================= */

function $(id) {
    return document.getElementById(id);
}

function exists(id) {
    return !!$(id);
}


/* =========================================================
   AUTH
========================================================= */

async function getCurrentUser() {

    const { data, error } =
        await supabase.auth.getUser();

    if (error) {
        console.error("Auth error:", error);
        return null;
    }

    currentUser = data?.user || null;

    return currentUser;
}


/* =========================================================
   AUTH STATE
========================================================= */

supabase.auth.onAuthStateChange(
    (_event, session) => {

        currentUser =
            session?.user || null;

        updateAuthUI();
    }
);


async function updateAuthUI() {

    if (!currentUser) {
        await getCurrentUser();
    }

    const loginButton =
        $("loginButton");

    const profileButton =
        $("profileButton");

    if (loginButton) {

        if (currentUser) {

            loginButton.textContent =
                "Profile";

            loginButton.href =
                "../pages/profile.html";

        } else {

            loginButton.textContent =
                "Login";

            loginButton.href =
                "../auth/login.html";
        }
    }

    if (profileButton) {

        profileButton.style.display =
            currentUser
                ? "inline-flex"
                : "none";
    }
}


/* =========================================================
   LOAD RANDOM QUIZ
========================================================= */

async function loadRandomQuiz() {

    resetQuizState();

    setQuizStatus(
        "Loading a real quiz..."
    );


    const { data, error } =
        await supabase
            .from(CONFIG.quizTable)
            .select("*")
            .limit(100);


    if (error) {

        console.error(
            "Quiz loading error:",
            error
        );

        setQuizStatus(
            "Unable to load quizzes. Check your Supabase quiz table and policies."
        );

        return null;
    }


    if (!data || data.length === 0) {

        setQuizStatus(
            "No anime quizzes have been added yet."
        );

        return null;
    }


    /*
      Pick randomly from the real rows returned
      by Supabase.

      No fake quiz is generated here.
    */

    currentQuiz =
        data[
            Math.floor(
                Math.random() * data.length
            )
        ];


    currentQuestion =
        currentQuiz;


    renderQuiz(currentQuiz);

    return currentQuiz;
}


/* =========================================================
   RENDER QUIZ
========================================================= */

function renderQuiz(quiz) {

    answerLocked = false;
    selectedAnswer = null;


    const title =
        $("quizTitle");

    const question =
        $("quizQuestion");

    const options =
        $("quizOptions");


    if (title) {

        title.textContent =
            quiz.title ||
            "Anime Quiz";
    }


    if (question) {

        question.textContent =
            quiz.question ||
            "";
    }


    if (!options) {
        return;
    }


    options.innerHTML = "";


    const answers =
        getQuizOptions(quiz);


    if (!answers.length) {

        options.innerHTML = `
            <div style="
                padding:20px;
                border-radius:12px;
                background:#10151d;
                color:#858e9d;
            ">
                This quiz doesn't have valid answer choices yet.
            </div>
        `;

        return;
    }


    answers.forEach(
        (answer, index) => {

            const button =
                document.createElement("button");


            button.type =
                "button";


            button.className =
                "quiz-option";


            button.dataset.index =
                index;


            button.textContent =
                answer.text;


            button.addEventListener(
                "click",
                () => {

                    submitAnswer(
                        answer,
                        button
                    );

                }
            );


            options.appendChild(button);
        }
    );


    setQuizStatus(
        "Choose one answer."
    );
}


/* =========================================================
   GET ANSWER OPTIONS
========================================================= */

function getQuizOptions(quiz) {

    /*
      Supports either:

      options: [
        "Answer A",
        "Answer B"
      ]

      OR

      options: [
        {
          text: "Answer A",
          value: "a"
        }
      ]

      OR separate fields:

      option_a
      option_b
      option_c
      option_d
    */


    if (Array.isArray(quiz.options)) {

        return quiz.options.map(
            option => {

                if (
                    typeof option === "string"
                ) {

                    return {
                        text: option,
                        value: option
                    };

                }

                return {
                    text:
                        option.text ??
                        option.label ??
                        option.value ??
                        "",
                    value:
                        option.value ??
                        option.text ??
                        ""
                };
            }
        );
    }


    const fields = [
        "option_a",
        "option_b",
        "option_c",
        "option_d"
    ];


    return fields
        .filter(
            field =>
                quiz[field] !== null &&
                quiz[field] !== undefined &&
                String(quiz[field]).trim() !== ""
        )
        .map(
            field => ({
                text: String(quiz[field]),
                value: String(quiz[field])
            })
        );
}


/* =========================================================
   SUBMIT ANSWER
========================================================= */

async function submitAnswer(
    answer,
    button
) {

    /*
      Prevent selecting another answer.

      The user can answer only once
      for the current question.
    */

    if (answerLocked) {
        return;
    }


    answerLocked = true;

    selectedAnswer =
        answer.value;


    document
        .querySelectorAll(".quiz-option")
        .forEach(
            option => {

                option.disabled =
                    true;

                option.style.pointerEvents =
                    "none";

                option.style.opacity =
                    "0.65";
            }
        );


    const isCorrect =
        checkAnswer(
            currentQuiz,
            answer
        );


    if (isCorrect) {

        quizScore++;

        button.style.borderColor =
            "#42d392";

        button.style.background =
            "rgba(66,211,146,.12)";

        setQuizStatus(
            "Correct! 🎉"
        );

    } else {

        button.style.borderColor =
            "#ff6464";

        button.style.background =
            "rgba(255,100,100,.10)";

        setQuizStatus(
            "Incorrect."
        );
    }


    questionsAnswered++;


    await saveAnswer({
        quiz: currentQuiz,
        answer: answer,
        correct: isCorrect
    });


    updateScoreUI();


    /*
      Give the user time to see the result
      before loading another question.
    */

    setTimeout(
        () => {

            loadRandomQuiz();

        },
        1200
    );
}


/* =========================================================
   CHECK ANSWER
========================================================= */

function checkAnswer(
    quiz,
    answer
) {

    if (!quiz) {
        return false;
    }


    /*
      Recommended database field:

      correct_answer

      It can contain either the answer value
      or the actual answer text.
    */

    const correct =
        quiz.correct_answer;


    if (
        correct === null ||
        correct === undefined
    ) {

        console.warn(
            "Quiz has no correct_answer field:",
            quiz.id
        );

        return false;
    }


    return normalize(correct) ===
        normalize(answer.value);
}


function normalize(value) {

    return String(value)
        .trim()
        .toLowerCase();
}


/* =========================================================
   SAVE ANSWER
========================================================= */

async function saveAnswer({
    quiz,
    answer,
    correct
}) {

    if (!currentUser) {

        /*
          Anonymous users can still play.

          Their answer is not permanently
          attached to a user account.
        */

        return;
    }


    const payload = {
        user_id: currentUser.id,
        quiz_id: quiz.id,
        selected_answer: answer.value,
        is_correct: correct
    };


    const { error } =
        await supabase
            .from(CONFIG.answerTable)
            .insert(payload);


    if (error) {

        console.error(
            "Unable to save quiz answer:",
            error
        );
    }
}


/* =========================================================
   SCORE UI
========================================================= */

function updateScoreUI() {

    const score =
        $("quizScore");

    if (score) {

        score.textContent =
            String(quizScore);
    }


    const answered =
        $("questionsAnswered");

    if (answered) {

        answered.textContent =
            String(questionsAnswered);
    }
}


/* =========================================================
   RESET
========================================================= */

function resetQuizState() {

    currentQuiz = null;
    currentQuestion = null;

    selectedAnswer = null;
    answerLocked = false;
}


/* =========================================================
   QUIZ STATUS
========================================================= */

function setQuizStatus(message) {

    const status =
        $("quizStatus");

    if (status) {

        status.textContent =
            message;
    }
}


/* =========================================================
   RESET SCORE
========================================================= */

function resetScore() {

    quizScore = 0;
    questionsAnswered = 0;

    updateScoreUI();

    loadRandomQuiz();
}


/* =========================================================
   LOAD USER SCORE
========================================================= */

async function loadUserScore() {

    if (!currentUser) {
        return;
    }


    const { data, error } =
        await supabase
            .from(CONFIG.answerTable)
            .select(
                "is_correct"
            )
            .eq(
                "user_id",
                currentUser.id
            );


    if (error) {

        console.error(
            "Unable to load score:",
            error
        );

        return;
    }


    if (!data) {
        return;
    }


    questionsAnswered =
        data.length;


    quizScore =
        data.filter(
            answer =>
                answer.is_correct === true
        ).length;


    updateScoreUI();
}


/* =========================================================
   LEADERBOARD
========================================================= */

async function loadLeaderboard() {

    const leaderboard =
        $("leaderboard");


    if (!leaderboard) {
        return;
    }


    leaderboard.innerHTML = `
        <div style="
            padding:20px;
            color:#7e8794;
        ">
            Loading leaderboard...
        </div>
    `;


    /*
      The secure long-term solution is a Supabase
      RPC/function that calculates leaderboard data.

      We intentionally don't fake rankings here.
    */

    const { data, error } =
        await supabase
            .rpc(
                "anime_quiz_leaderboard",
                {
                    result_limit:
                        CONFIG.leaderboardLimit
                }
            );


    if (error) {

        console.error(
            "Leaderboard error:",
            error
        );


        leaderboard.innerHTML = `
            <div style="
                padding:20px;
                color:#7e8794;
            ">
                Leaderboard is not configured yet.
            </div>
        `;

        return;
    }


    if (!data || data.length === 0) {

        leaderboard.innerHTML = `
            <div style="
                padding:20px;
                color:#7e8794;
            ">
                No quiz scores yet.
            </div>
        `;

        return;
    }


    leaderboard.innerHTML =
        data.map(
            (player, index) => `

                <div style="
                    display:flex;
                    align-items:center;
                    gap:12px;
                    padding:12px 0;
                    border-bottom:1px solid rgba(255,255,255,.06);
                ">

                    <div style="
                        width:30px;
                        text-align:center;
                        color:#8992a0;
                        font-weight:800;
                    ">
                        ${index + 1}
                    </div>

                    <div style="
                        flex:1;
                        color:#fff;
                        font-weight:700;
                    ">
                        ${escapeHTML(
                            player.username ||
                            "Member"
                        )}
                    </div>

                    <div style="
                        color:#63e6be;
                        font-weight:800;
                    ">
                        ${Number(
                            player.score || 0
                        ).toLocaleString()}
                    </div>

                </div>
            `
        )
        .join("");
}


/* =========================================================
   SEARCH
========================================================= */

function setupSearch() {

    const input =
        $("animeSearch");

    const button =
        $("animeSearchButton");


    if (button) {

        button.addEventListener(
            "click",
            () => {

                performSearch(
                    input?.value
                );

            }
        );
    }


    if (input) {

        input.addEventListener(
            "keydown",
            event => {

                if (
                    event.key === "Enter"
                ) {

                    performSearch(
                        input.value
                    );
                }

            }
        );
    }
}


function performSearch(value) {

    const query =
        String(value || "").trim();


    if (!query) {
        return;
    }


    window.location.href =
        "search.html?q=" +
        encodeURIComponent(query);
}


/* =========================================================
   MOBILE MENU
========================================================= */

function setupMobileMenu() {

    const button =
        $("mobileMenuButton");

    const menu =
        $("mobileNav");


    if (!button || !menu) {
        return;
    }


    button.addEventListener(
        "click",
        () => {

            menu.classList.toggle(
                "open"
            );

        }
    );
}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/* =========================================================
   PUBLIC API
========================================================= */

export {
    loadRandomQuiz,
    resetScore,
    loadUserScore,
    loadLeaderboard,
    performSearch
};


/* =========================================================
   INITIALIZATION
========================================================= */

async function initAnime() {

    await getCurrentUser();

    await updateAuthUI();

    setupSearch();

    setupMobileMenu();

    updateScoreUI();

    await loadUserScore();

    await loadRandomQuiz();

    await loadLeaderboard();
}


initAnime();