// js/anime/quiz.js
// REGENESIS — Real Anime Quiz Engine
// Requires: ../supabase.js
//
// Expected Supabase tables:
//
// anime_quizzes
//   id
//   question
//   options          -> JSON array ["A", "B", "C", "D"]
//   correct_answer   -> exact option text OR option index
//   anime_id         -> optional
//   anime_title      -> optional
//   difficulty       -> optional
//   points           -> optional
//   explanation      -> optional
//   hint             -> optional
//   created_at
//
// quiz_answers
//   id
//   quiz_id
//   user_id
//   selected_answer
//   is_correct
//   points_earned
//   created_at
//
// profiles
//   id
//   username
//   avatar_url
//
// IMPORTANT:
// Security must also be enforced with Supabase RLS.
// Client-side JavaScript must never be treated as the security layer.

import { supabase } from "../supabase.js";

const CONFIG = {
    quizzesTable: "anime_quizzes",
    answersTable: "quiz_answers",
    profilesTable: "profiles",

    questionsPerQuiz: 10,
    defaultPoints: 10,

    // Prevent accidentally loading an enormous dataset.
    maxQuestionsToLoad: 100
};

const state = {
    user: null,

    allQuestions: [],
    questions: [],
    currentIndex: 0,

    score: 0,
    correct: 0,
    answered: 0,

    selectedAnswer: null,
    answerLocked: false,

    loading: false,
    finished: false,

    filters: {
        anime: null,
        difficulty: null
    }
};


// ============================================================
// AUTH
// ============================================================

async function getCurrentUser() {
    const { data, error } = await supabase.auth.getUser();

    if (error) {
        console.error("Unable to get current user:", error);
        return null;
    }

    state.user = data?.user || null;
    return state.user;
}


// ============================================================
// LOAD REAL QUIZZES FROM SUPABASE
// ============================================================

async function loadQuizzes(filters = {}) {
    state.loading = true;

    try {
        let query = supabase
            .from(CONFIG.quizzesTable)
            .select(`
                id,
                question,
                options,
                correct_answer,
                anime_id,
                anime_title,
                difficulty,
                points,
                explanation,
                hint,
                created_at
            `)
            .limit(CONFIG.maxQuestionsToLoad);

        if (filters.anime) {
            query = query.eq("anime_id", filters.anime);
        }

        if (filters.difficulty) {
            query = query.eq("difficulty", filters.difficulty);
        }

        const { data, error } = await query;

        if (error) {
            console.error("Quiz loading error:", error);
            throw error;
        }

        state.allQuestions = Array.isArray(data)
            ? data.map(normalizeQuestion).filter(Boolean)
            : [];

        return state.allQuestions;
    } finally {
        state.loading = false;
    }
}


// ============================================================
// NORMALIZE QUESTION
// ============================================================

function normalizeQuestion(row) {
    if (!row || !row.id || !row.question) {
        return null;
    }

    let options = [];

    // JSON array stored in Supabase
    if (Array.isArray(row.options)) {
        options = row.options;
    }

    // JSON string stored in Supabase
    else if (typeof row.options === "string") {
        try {
            const parsed = JSON.parse(row.options);

            if (Array.isArray(parsed)) {
                options = parsed;
            }
        } catch {
            // Not JSON; ignore.
        }
    }

    options = options
        .filter(option => option !== null && option !== undefined)
        .map(option => String(option).trim())
        .filter(Boolean);

    // A real single-answer quiz needs at least two choices.
    if (options.length < 2) {
        return null;
    }

    return {
        id: row.id,
        question: String(row.question).trim(),

        options,

        correctAnswer: row.correct_answer,

        animeId: row.anime_id || null,
        animeTitle: row.anime_title || null,

        difficulty: row.difficulty || "normal",

        points:
            Number.isFinite(Number(row.points))
                ? Number(row.points)
                : CONFIG.defaultPoints,

        explanation: row.explanation || "",
        hint: row.hint || "",

        createdAt: row.created_at || null
    };
}


// ============================================================
// SHUFFLE
// Fisher-Yates
// ============================================================

function shuffle(array) {
    const copy = [...array];

    for (let i = copy.length - 1; i > 0; i--) {
        const randomIndex = Math.floor(Math.random() * (i + 1));

        [copy[i], copy[randomIndex]] = [
            copy[randomIndex],
            copy[i]
        ];
    }

    return copy;
}


// ============================================================
// CREATE NEW QUIZ SESSION
// ============================================================

function createQuiz(questionCount = CONFIG.questionsPerQuiz) {
    if (!state.allQuestions.length) {
        state.questions = [];
        return [];
    }

    const count = Math.min(
        Math.max(1, Number(questionCount) || CONFIG.questionsPerQuiz),
        state.allQuestions.length
    );

    state.questions = shuffle(state.allQuestions)
        .slice(0, count)
        .map(question => ({
            ...question,
            options: shuffle(question.options)
        }));

    state.currentIndex = 0;

    state.score = 0;
    state.correct = 0;
    state.answered = 0;

    state.selectedAnswer = null;
    state.answerLocked = false;

    state.finished = false;

    return state.questions;
}


// ============================================================
// START QUIZ
// ============================================================

async function startQuiz({
    questionCount = CONFIG.questionsPerQuiz,
    anime = null,
    difficulty = null
} = {}) {
    state.filters.anime = anime;
    state.filters.difficulty = difficulty;

    await loadQuizzes({
        anime,
        difficulty
    });

    if (!state.allQuestions.length) {
        throw new Error(
            "No real anime quizzes were found in Supabase."
        );
    }

    createQuiz(questionCount);

    return getCurrentQuestion();
}


// ============================================================
// CURRENT QUESTION
// ============================================================

function getCurrentQuestion() {
    if (
        !state.questions.length ||
        state.currentIndex < 0 ||
        state.currentIndex >= state.questions.length
    ) {
        return null;
    }

    return state.questions[state.currentIndex];
}


// ============================================================
// ANSWER NORMALIZATION
// ============================================================

function normalizeAnswer(answer) {
    if (answer === null || answer === undefined) {
        return null;
    }

    return String(answer)
        .trim()
        .toLowerCase();
}


// ============================================================
// CHECK ANSWER
// ============================================================

function isAnswerCorrect(question, selectedAnswer) {
    if (!question) {
        return false;
    }

    const selected = normalizeAnswer(selectedAnswer);
    const correct = question.correctAnswer;

    if (correct === null || correct === undefined) {
        return false;
    }

    // Correct answer stored as number:
    // 0 = first option
    // 1 = second option, etc.
    if (
        typeof correct === "number" &&
        Number.isInteger(correct)
    ) {
        return (
            question.options[correct] !== undefined &&
            normalizeAnswer(question.options[correct]) === selected
        );
    }

    // Correct answer stored as numeric string.
    if (
        typeof correct === "string" &&
        /^\d+$/.test(correct.trim())
    ) {
        const index = Number(correct.trim());

        if (question.options[index] !== undefined) {
            return (
                normalizeAnswer(question.options[index]) === selected
            );
        }
    }

    // Correct answer stored as exact answer text.
    return normalizeAnswer(correct) === selected;
}


// ============================================================
// SUBMIT ANSWER
// ============================================================

async function submitAnswer(answer) {
    if (state.finished) {
        return {
            success: false,
            reason: "quiz_finished"
        };
    }

    if (state.answerLocked) {
        return {
            success: false,
            reason: "already_answered"
        };
    }

    const question = getCurrentQuestion();

    if (!question) {
        return {
            success: false,
            reason: "no_question"
        };
    }

    const selected = String(answer ?? "").trim();

    if (!selected) {
        return {
            success: false,
            reason: "empty_answer"
        };
    }

    const exists = question.options.some(
        option =>
            normalizeAnswer(option) === normalizeAnswer(selected)
    );

    if (!exists) {
        return {
            success: false,
            reason: "invalid_answer"
        };
    }

    state.answerLocked = true;
    state.selectedAnswer = selected;
    state.answered++;

    const correct = isAnswerCorrect(
        question,
        selected
    );

    let pointsEarned = 0;

    if (correct) {
        state.correct++;

        pointsEarned = Number(question.points) || 0;

        state.score += pointsEarned;
    }

    // Save real attempt when authenticated.
    if (state.user) {
        await saveAnswer({
            question,
            selectedAnswer: selected,
            isCorrect: correct,
            pointsEarned
        });
    }

    return {
        success: true,

        questionId: question.id,

        selectedAnswer: selected,

        correct,

        correctAnswer: resolveCorrectAnswer(question),

        pointsEarned,

        score: state.score,

        correctCount: state.correct,

        answered: state.answered,

        totalQuestions: state.questions.length,

        explanation: question.explanation || ""
    };
}


// ============================================================
// RESOLVE CORRECT ANSWER
// ============================================================

function resolveCorrectAnswer(question) {
    const correct = question?.correctAnswer;

    if (correct === null || correct === undefined) {
        return null;
    }

    if (
        typeof correct === "number" &&
        question.options[correct] !== undefined
    ) {
        return question.options[correct];
    }

    if (
        typeof correct === "string" &&
        /^\d+$/.test(correct.trim())
    ) {
        const index = Number(correct.trim());

        if (question.options[index] !== undefined) {
            return question.options[index];
        }
    }

    return String(correct);
}


// ============================================================
// SAVE ANSWER TO SUPABASE
// ============================================================

async function saveAnswer({
    question,
    selectedAnswer,
    isCorrect,
    pointsEarned
}) {
    if (!state.user) {
        return {
            saved: false,
            reason: "not_authenticated"
        };
    }

    const payload = {
        quiz_id: question.id,
        user_id: state.user.id,
        selected_answer: selectedAnswer,
        is_correct: isCorrect,
        points_earned: pointsEarned
    };

    const { data, error } = await supabase
        .from(CONFIG.answersTable)
        .insert(payload)
        .select()
        .single();

    if (error) {
        console.error(
            "Unable to save quiz answer:",
            error
        );

        return {
            saved: false,
            error
        };
    }

    return {
        saved: true,
        data
    };
}


// ============================================================
// NEXT QUESTION
// ============================================================

function nextQuestion() {
    if (!state.questions.length) {
        return null;
    }

    if (!state.answerLocked) {
        return {
            success: false,
            reason: "answer_current_question_first",
            question: getCurrentQuestion()
        };
    }

    state.currentIndex++;

    state.selectedAnswer = null;
    state.answerLocked = false;

    if (state.currentIndex >= state.questions.length) {
        state.finished = true;

        return {
            success: true,
            finished: true,
            result: getResult()
        };
    }

    return {
        success: true,
        finished: false,
        question: getCurrentQuestion()
    };
}


// ============================================================
// PREVIOUS QUESTION
// ============================================================
//
// Previous questions are disabled after submission by default.
// This prevents changing already-recorded answers.

function previousQuestion() {
    if (state.currentIndex <= 0) {
        return null;
    }

    return state.questions[state.currentIndex - 1];
}


// ============================================================
// GET RESULT
// ============================================================

function getResult() {
    const total = state.questions.length;

    const percentage =
        total > 0
            ? Math.round((state.correct / total) * 100)
            : 0;

    return {
        score: state.score,

        correct: state.correct,

        answered: state.answered,

        total,

        percentage,

        finished: state.finished,

        userId: state.user?.id || null
    };
}


// ============================================================
// RESET QUIZ
// ============================================================

function resetQuiz() {
    state.questions = [];
    state.currentIndex = 0;

    state.score = 0;
    state.correct = 0;
    state.answered = 0;

    state.selectedAnswer = null;
    state.answerLocked = false;

    state.finished = false;
}


// ============================================================
// GET PROGRESS
// ============================================================

function getProgress() {
    const total = state.questions.length;

    if (!total) {
        return {
            current: 0,
            total: 0,
            percentage: 0
        };
    }

    const current = Math.min(
        state.currentIndex + 1,
        total
    );

    return {
        current,
        total,
        percentage: Math.round((current / total) * 100)
    };
}


// ============================================================
// GET QUESTION BY ID
// ============================================================

async function getQuizById(id) {
    if (!id) {
        return null;
    }

    const { data, error } = await supabase
        .from(CONFIG.quizzesTable)
        .select(`
            id,
            question,
            options,
            correct_answer,
            anime_id,
            anime_title,
            difficulty,
            points,
            explanation,
            hint,
            created_at
        `)
        .eq("id", id)
        .maybeSingle();

    if (error) {
        console.error(
            "Unable to load quiz:",
            error
        );

        throw error;
    }

    return normalizeQuestion(data);
}


// ============================================================
// RANDOM REAL QUIZ
// ============================================================

async function getRandomQuiz({
    anime = null,
    difficulty = null
} = {}) {
    const questions = await loadQuizzes({
        anime,
        difficulty
    });

    if (!questions.length) {
        return null;
    }

    const randomIndex =
        Math.floor(Math.random() * questions.length);

    return questions[randomIndex];
}


// ============================================================
// USER QUIZ HISTORY
// ============================================================

async function getUserQuizHistory({
    limit = 50
} = {}) {
    if (!state.user) {
        return [];
    }

    const { data, error } = await supabase
        .from(CONFIG.answersTable)
        .select(`
            id,
            quiz_id,
            selected_answer,
            is_correct,
            points_earned,
            created_at
        `)
        .eq("user_id", state.user.id)
        .order("created_at", {
            ascending: false
        })
        .limit(limit);

    if (error) {
        console.error(
            "Unable to load quiz history:",
            error
        );

        throw error;
    }

    return data || [];
}


// ============================================================
// USER QUIZ STATS
// ============================================================

async function getUserQuizStats() {
    if (!state.user) {
        return {
            totalAnswered: 0,
            totalCorrect: 0,
            totalPoints: 0,
            accuracy: 0
        };
    }

    const { data, error } = await supabase
        .from(CONFIG.answersTable)
        .select(`
            is_correct,
            points_earned
        `)
        .eq("user_id", state.user.id);

    if (error) {
        console.error(
            "Unable to load quiz statistics:",
            error
        );

        throw error;
    }

    const answers = data || [];

    const totalAnswered = answers.length;

    const totalCorrect = answers.filter(
        answer => answer.is_correct === true
    ).length;

    const totalPoints = answers.reduce(
        (total, answer) =>
            total + (Number(answer.points_earned) || 0),
        0
    );

    const accuracy =
        totalAnswered > 0
            ? Math.round(
                (totalCorrect / totalAnswered) * 100
            )
            : 0;

    return {
        totalAnswered,
        totalCorrect,
        totalPoints,
        accuracy
    };
}


// ============================================================
// LEADERBOARD
// ============================================================
//
// This expects a Supabase RPC:
//
// anime_quiz_leaderboard()
//
// The RPC should calculate leaderboard values server-side.

async function getLeaderboard(limit = 50) {
    const { data, error } = await supabase.rpc(
        "anime_quiz_leaderboard",
        {
            result_limit: limit
        }
    );

    if (error) {
        console.error(
            "Unable to load quiz leaderboard:",
            error
        );

        throw error;
    }

    return data || [];
}


// ============================================================
// HINT
// ============================================================

function getCurrentHint() {
    const question = getCurrentQuestion();

    if (!question) {
        return "";
    }

    return question.hint || "";
}


// ============================================================
// AUTH STATE
// ============================================================

supabase.auth.onAuthStateChange(
    (_event, session) => {
        state.user = session?.user || null;
    }
);


// ============================================================
// INITIALIZE
// ============================================================

async function initQuiz() {
    await getCurrentUser();

    return {
        authenticated: Boolean(state.user),
        user: state.user
    };
}


// ============================================================
// PUBLIC API
// ============================================================

export {
    initQuiz,

    getCurrentUser,

    loadQuizzes,

    createQuiz,

    startQuiz,

    getCurrentQuestion,

    submitAnswer,

    nextQuestion,

    previousQuestion,

    getResult,

    getProgress,

    resetQuiz,

    getQuizById,

    getRandomQuiz,

    getUserQuizHistory,

    getUserQuizStats,

    getLeaderboard,

    getCurrentHint,

    isAnswerCorrect
};


// ============================================================
// AUTO INITIALIZE
// ============================================================

initQuiz().catch(error => {
    console.error(
        "REGENESIS quiz initialization failed:",
        error
    );
});